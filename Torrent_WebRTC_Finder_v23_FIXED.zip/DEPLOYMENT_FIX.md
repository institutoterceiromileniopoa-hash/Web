# Implantação na Vercel — correção das rotas da API

## Causa do erro
O frontend chamava `/api/inspect/magnet`, `/api/inspect/file` e `/api/search`, mas o projeto só iniciava o Express com `app.listen()`. Esse listener funciona em um servidor Node tradicional, porém não registra automaticamente as rotas como funções serverless na Vercel. A hospedagem acabava respondendo com HTML, e o navegador tentava interpretar esse HTML como JSON.

## Correções incluídas
- Criado `api/[...path].js`, função catch-all da Vercel que encaminha `/api/*` para o Express.
- `server/index.js` agora exporta o app Express e só abre `app.listen()` no desenvolvimento local.
- CORS permite a origem do mesmo domínio publicado, além da origem local do Vite e das origens extras definidas em `FRONTEND_ORIGIN`.
- O frontend lê a resposta da API com tratamento explícito: se receber HTML/texto em vez de JSON, mostra o status HTTP e um trecho da resposta para facilitar o diagnóstico.
- Mantidos o decoder de torrent, as rotas de inspeção, o catálogo e o cliente WebTorrent/WebRTC.

## Configuração da Vercel
Configure o projeto com:
- Framework Preset: `Vite`
- Root Directory: `./` (raiz do repositório, onde está `package.json`)
- Install Command: `npm install`
- Build Command: `npm run build`
- Output Directory: `client/dist` (marque Override se necessário)

O arquivo `vercel.json` define a função serverless. Não configure o Root Directory como `client`, pois o backend e a pasta `api` ficam na raiz do projeto.

## Verificação após o deploy
Abra `https://SEU-DOMINIO.vercel.app/api/health`. A resposta esperada é um JSON semelhante a:

```json
{"ok":true,"service":"torrent-webrtc-finder","version":"0.1.0"}
```

Depois, tente analisar um magnet na página. Se houver outro erro, o diagnóstico agora deverá exibir o status HTTP e o conteúdo inicial da resposta.

## Observação
O catálogo continua armazenado em memória e pode não persistir entre execuções serverless. Para persistência real, será necessário conectar um banco de dados. A implantação da API também não garante que existam peers WebRTC disponíveis; isso depende do swarm, dos trackers WSS e da conectividade ICE.


## Correção de reprodução WebTorrent (v4)

- O pacote `webtorrent@2.5.19` é instalado como dependência e o `postinstall` copia o `sw.min.js` oficial para `client/public/sw.min.js`.
- O frontend registra e aguarda o Service Worker, inicializa `client.createServer({ controller })` e somente então chama `file.streamTo(video)`.
- O player informa eventos de carregamento, buffer, reprodução e erros de rede/decodificação.
- A API e as funções serverless existentes foram preservadas.
- Após publicar, faça um hard refresh/limpe o cache do site para atualizar o Service Worker.

## Diagnóstico adicional do Service Worker (v5)
- O frontend verifica antes do registro se `/sw.min.js` existe e se a resposta é JavaScript, não a página HTML de fallback da hospedagem.
- Aguarda a ativação do worker e informa os estados `active`, `waiting` e `installing` quando houver falha, em vez de exibir apenas uma mensagem genérica.
- O script de instalação procura `sw.min.js` em diferentes caminhos dentro do pacote oficial `webtorrent` e interrompe o deploy se o arquivo não existir.
- Depois do deploy v5, abra o domínio principal do app (não uma rota interna) e recarregue a página. Se o diagnóstico disser HTTP 404, o arquivo não foi incluído no build; se disser HTML, a Vercel está devolvendo o fallback no lugar do worker.

## v6 — navegador como peer WebRTC ativo

O cliente do navegador participa do swarm assim que `client.add()` é executado com o magnet ou torrent. O WebTorrent compartilha automaticamente com outros peers WebRTC as peças que já foram baixadas e verificadas; não é necessário chamar `client.seed()` para semear parcialmente o mesmo torrent que está sendo baixado.

A interface agora exibe estado do peer, peer ID local, conexões WebRTC, velocidade de upload e total enviado. A sessão do torrent permanece ativa enquanto a página estiver aberta. Fechar/recarregar a página ou destruir o cliente encerra o compartilhamento. Upload real só aparece quando outro peer WebRTC compatível conecta e solicita peças que este navegador possui.

Limitações: navegador não conecta a peers BitTorrent TCP/UDP convencionais; ambos os lados precisam suportar WebTorrent/WebRTC. A disponibilidade depende de trackers WebSocket funcionais, conectividade WebRTC/STUN, permissões/rede do navegador e existência de outros peers compatíveis. A interface não promete upload quando não há solicitações de outros peers.

## v7 — injeção automática de trackers WebRTC

Ao clicar em **Conectar e reproduzir vídeo**, o cliente verifica os trackers disponíveis. Trackers `wss://` existentes são preservados e usados sem duplicação. Se um `.torrent` estiver explicitamente marcado como público e não possuir tracker WSS, ou se a entrada não possuir tracker algum, são acrescentados os trackers WSS de fallback definidos em `client/src/tracker-utils.js`, por meio da opção `announce` de `client.add()`.

A proteção de privacidade impede adicionar trackers públicos a `.torrent` marcado como privado. Em magnet com trackers não-WSS e metadata ainda desconhecido, não são adicionados trackers públicos porque não é possível confirmar a flag `private`. Um magnet sem trackers recebe os fallbacks automaticamente; como o magnet não carrega a flag de privacidade, use esse comportamento apenas com torrents públicos/autorizados.

## v8 — Telemetria estável e responsividade

- Os indicadores de peer agora são atualizados em nós DOM persistentes (`textContent`), sem reconstruir o painel a cada segundo.
- Foram adicionados gráficos em canvas para download/upload e quantidade de peers WebRTC, com janela móvel de 60 segundos.
- O canvas redesenha sem substituir a estrutura da página, reduzindo piscadas e saltos de layout.
- O info hash completo permanece acessível, mas quebra dentro do próprio cartão; há ação para copiar o hash completo.
- Layout dos gráficos e cartões adaptado a telas estreitas; URLs e hashes longos não forçam rolagem horizontal.


## v9 — otimização adaptativa

A v9 mantém as rotas de API e o fluxo de Service Worker da v8. A otimização atua apenas nas prioridades de peças e na telemetria do cliente: o navegador mede o buffer de reprodução, seleciona uma janela de peças à frente do playhead e marca as peças imediatamente necessárias como críticas. O `streamTo()` permanece responsável pelo streaming e pelos pedidos de intervalo/seek.

Os gráficos recebem amostras em cadência fixa (1 s), enquanto os cartões numéricos são atualizados sem reconstruir o painel. O build Vite deve ser executado no deploy; valide `/api/health`, carregamento de `sw.min.js` e um teste com dois peers WebTorrent reais após publicar.

## Interface v10

A atualização v10 altera a organização visual para navegação por abas (Início, Buscar, Player, Telemetria, Peers e Sobre). Não exige novas variáveis de ambiente, rotas de API ou dependências. Publique os arquivos do projeto normalmente para aplicar a interface.

## Atualização v11 — telemetria

Publique a versão v11 para aplicar a amostragem por deltas de bytes, gráficos temporais de 60 segundos e taxas por peer. Não há novas variáveis de ambiente nem alterações nas rotas da API.

## v13 — telemetria e DHT WebTorrent

- A consulta `POST /api/dht/lookup` agora instancia o cliente `webtorrent` no Node.js com `dht: true`, `tracker: false` e observa peers conectados por `torrent.on("wire")`.
- Isso usa o DHT BEP-5 integrado ao WebTorrent Node.js. Não é uma implementação DHT no navegador: browsers continuam sem UDP/TCP BitTorrent e usam WebRTC com trackers WSS.
- A interface de telemetria foi redesenhada com cartões de destaque, barra de buffer, KPIs secundários e gráficos em layout responsivo.

## v12 — layout, buffer e DHT

- A telemetria do buffer passa a medir apenas os segundos contíguos disponíveis a partir do `currentTime`, sem somar segmentos separados do `video.buffered`.
- O gráfico recebe no máximo um ponto por segundo, evita amostras duplicadas no mesmo intervalo e usa um único relógio para desenhar a janela móvel.
- A API `POST /api/dht/lookup` consulta DHT através do próprio cliente `webtorrent` com `dht: true` quando executada em um servidor Node.js persistente com UDP habilitado. Configure `DHT_ENABLED=1` e permita tráfego UDP para o processo Node.js; o WebTorrent gerencia a porta DHT.
- A Vercel é serverless e não oferece um socket UDP persistente para manter a DHT ativa; nessa hospedagem, a rota informa explicitamente que a consulta está indisponível. Para usar DHT, execute o backend em VPS/servidor Node persistente e encaminhe `/api` para ele.
- Os endereços DHT são peers potenciais BitTorrent TCP/UDP. Eles não podem ser conectados diretamente pelo player do navegador, que continua limitado a peers WebTorrent/WebRTC. A DHT amplia descoberta, não converte transporte.

### Variáveis de ambiente v12
- `DHT_ENABLED=1` para habilitar no Node persistente (use `0` para desabilitar).

## Correção v17 — rota aninhada do catálogo Upstash

O endpoint de gravação é `POST /api/catalog/played`. A função `api/catalog.js` representa somente o caminho exato `/api/catalog`; ela não cria automaticamente o subcaminho `/api/catalog/played`. Quando o subcaminho não possui uma função correspondente, a Vercel responde com seu 404 `NOT_FOUND` antes de o Express receber a requisição.

Foi adicionada `api/[...path].js`, função catch-all para encaminhar os caminhos API aninhados ao mesmo app Express. O body parser automático da função fica desativado para que `express.json()` e Multer recebam o corpo da requisição corretamente.

Após publicar esta versão, valide:
- `GET /api/health` deve retornar JSON com `ok: true`.
- `GET /api/catalog` deve retornar JSON; sem credenciais Upstash, deve retornar HTTP 503 com JSON explicando a configuração ausente.
- `POST /api/catalog/played` deve deixar de retornar o 404 `NOT_FOUND`. Sem Upstash configurado, a resposta esperada é HTTP 503 JSON; com Upstash, um registro válido retorna HTTP 201 JSON.

Na Vercel, confirme que o **Root Directory** é a raiz do projeto (não `client`) e faça um novo deploy incluindo a pasta `api/` e o arquivo `api/[...path].js`. Um deploy anterior não passa a conter a nova rota automaticamente.


## Correção v18 — buffer à frente baseado em peças recebidas

O indicador principal de buffer à frente agora é calculado a partir do bitfield
do torrent: conta somente peças completas/verificadas em sequência a partir
da posição equivalente ao playhead no arquivo selecionado. Peças verificadas\depois de uma lacuna não são somadas. O tempo é uma estimativa proporcional
ao tamanho e à duração do arquivo (taxa média de bytes por segundo).

O buffer MSE do elemento de vídeo continua sendo mostrado como diagnóstico\complementar, permitindo comparar os dados aceitos pelo navegador com as\peças já recebidas e verificadas pelo WebTorrent.

## Correção v19 — função explícita para salvar na biblioteca

Além da função catch-all, foi criada `api/catalog/played.js`, que mapeia diretamente o endpoint `POST /api/catalog/played` na Vercel. Isso evita depender da resolução de rotas dinâmicas para o salvamento na biblioteca. A função desativa o body parser automático para que o Express processe o JSON da requisição.

Após publicar, confirme que o deploy inclui `api/catalog/played.js`. Teste `POST /api/catalog/played`: sem as duas variáveis Upstash, a resposta esperada é HTTP 503 em JSON (não 404 `NOT_FOUND`); com Upstash configurado e payload válido, a resposta é HTTP 201 em JSON.


## v21 — integração Stremio/Torrentio

A Vercel encaminha as rotas `/api/stremio/*` pelo catch-all `api/[...path].js`. O backend faz proxy do manifesto Torrentio e do endpoint de streams Stremio, valida o tipo e o ID e normaliza hashes/tracker sources em magnet URI. Após publicar, valide `GET /api/stremio/manifest` (deve retornar o manifesto JSON) e consulte `GET /api/stremio/stream/movie/tt1254207` para um teste de resposta. Uma lista vazia é válida quando o addon não encontrar fontes para o título.

## Correção v22 — rotas explícitas do Torrentio/Stremio

A integração Torrentio agora possui funções Vercel dedicadas para:

- `GET /api/stremio/manifest` (`api/stremio/manifest.js`)
- `GET /api/stremio/stream/:type/:id` (`api/stremio/stream/[type]/[id].js`)

Essas funções encaminham as requisições ao Express, mas não dependem exclusivamente de `api/[...path].js`. O `vercel.json` também declara as duas funções com `maxDuration: 30`.

Após publicar, valide `/api/health`, `/api/stremio/manifest` e uma consulta como `/api/stremio/stream/movie/tt1254207`. O manifesto deve retornar JSON do addon; a consulta deve retornar `{ "streams": [...] }`, mesmo quando não houver resultados.
