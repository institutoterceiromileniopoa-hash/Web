# Torrent WebRTC Finder — MVP 0.1.0

MVP para inspeção de metadados `.torrent`/magnet, classificação de trackers e teste de conectividade WebRTC real no navegador. Use somente torrents e fontes que você tenha autorização para acessar.

## Requisitos
- Node.js 20+
- npm 10+
- Navegador moderno. Para acesso remoto, publique sob HTTPS.

## Instalação
```bash
npm install
cp .env.example .env
npm run dev
```
Frontend: http://localhost:5173 · API: http://localhost:8787

Build e execução integrada:
```bash
npm run build
npm start
```

Testes:
```bash
npm test
```

## O que já funciona
- Upload e leitura de `.torrent` com decoder bencode limitado a 20 MB/64 níveis.
- Extração do info hash SHA-1 sobre os bytes originais do dicionário `info`.
- Extração de `announce`, `announce-list`, nome, arquivos e tamanhos.
- Classificação independente `wss`, `ws`, `udp`, `http(s)`; nenhuma conversão de esquema.
- Parsing de magnet v1 `btih` e trackers `tr`.
- Cliente WebTorrent 2.5.19 no browser, carregado da distribuição pré-compilada para navegador via esm.sh; o Vite não empacota o entry point Node.js.
- Exibição de conexões (`torrent.wires`), taxa de download e progresso; seleção do maior arquivo de vídeo para prévia.
- Catálogo local simples dos torrents inspecionados.
- Rate limit, limite de upload, validação básica, Helmet e CORS de origem configurável.

## Compatibilidade Vite/Vercel
- O cliente WebTorrent é carregado em runtime por `loadWebTorrent()` a partir de `https://esm.sh/webtorrent@2.5.19/dist/webtorrent.min.js`. Não importe `webtorrent` diretamente no código cliente: isso pode selecionar o entry point Node.js e puxar `torrent-discovery`, `events`, DHT/UDP e outros módulos incompatíveis com o browser.
- A dependência `webtorrent` foi removida de `dependencies` porque o browser usa o bundle oficial pré-compilado via CDN; o servidor Express não utiliza a biblioteca.
- A reprodução usa `file.streamTo(video)`, API documentada do WebTorrent.

## Limitações importantes desta versão
1. Magnet links não contêm lista de arquivos. Os metadados aparecem somente depois que o cliente obtém o metadata do swarm.
2. A confirmação WebRTC ocorre somente quando o cliente browser WebTorrent estabelece `wire` connections. Um tracker WSS ou um número de seeders anunciado não confirma peers conectáveis.
3. A lista de trackers WSS embutidos é passada ao cliente. Trackers UDP/HTTP são apenas classificados e exibidos; o browser não os converte em WebRTC.
4. A reprodução de MKV/AVI depende do suporte de codec/container do navegador. O MVP seleciona o maior arquivo de vídeo, mas ainda não faz transcodificação nem garante que as primeiras peças estejam disponíveis. A disponibilidade sequencial precisa de uma etapa de medição por peça antes de atribuir um score de prontidão.
5. O catálogo é local e volátil em memória. Não há indexadores remotos habilitados por padrão. Adicione apenas adapters de fontes autorizadas, com contratos explícitos e sem aceitar URLs arbitrárias fornecidas pelo usuário.
6. WebRTC depende de sinalização via tracker WebSocket e ICE/STUN/TURN. NAT simétrico, firewall, tracker fora do ar e falta de peers podem impedir conexão. Para redes restritivas, configure infraestrutura ICE/TURN apropriada; isso não transforma peers TCP/UDP convencionais em WebRTC.
7. CORS não é uma barreira de segurança contra SSRF. O backend não implementa fetch remoto: só recebe magnet textual e upload de metainfo. Se futuramente houver indexadores, use allowlist fixa de hosts e bloqueie IPs privados/link-local/loopback após resolução DNS, revalidando redirects.

## Próximas etapas técnicas
- Persistência SQLite/PostgreSQL e índice local pesquisável.
- Adapters plugáveis para indexadores que autorizem acesso por API.
- Métrica real de disponibilidade das peças iniciais e sequência de leitura, em vez de inferir prontidão pelo número de peers.
- Testes de integração em navegador com torrents de teste legais e peers WebRTC controlados.
- Autenticação, quotas por usuário e TURN gerenciado para deploy público.

## Injeção automática de trackers WebRTC

Ao conectar um torrent, o cliente preserva os trackers `wss://` existentes. Se um `.torrent` estiver explicitamente marcado como público e não tiver tracker WSS, ou se não houver tracker algum, o navegador acrescenta automaticamente os trackers WSS de fallback do exemplo oficial do WebTorrent. Trackers existentes não são removidos.

Por privacidade, torrents marcados como privados nunca recebem trackers públicos extras. Para magnet links que já contêm trackers não-WSS, mas cujo metadata ainda não revelou se são privados, o sistema não injeta trackers públicos: isso evita divulgar o infoHash de um torrent privado para terceiros. Nesses casos, use um magnet público ou inclua um tracker WSS autorizado no próprio magnet.


## v9 — streaming adaptativo e telemetria

- Priorização adaptativa de uma janela de peças à frente da posição de reprodução, usando `torrent.select()` e `torrent.critical()` sem substituir o fluxo `file.streamTo()` do WebTorrent.
- Meta de buffer dinâmica (aprox. 20–75 s), ajustada pelo buffer observado e pela taxa de transferência estimada. O cálculo de tempo→bytes é aproximado; o stream HTTP do WebTorrent continua responsável pelas requisições e seeks exatos.
- Limite de conexões adaptado de forma conservadora ao dispositivo (40 em mobile/baixo recurso, 60 em desktop comum, até 75 em desktop de maior capacidade). Mais conexões não garantem maior velocidade.
- Métricas de buffer, velocidade média por peer e lista das conexões com maiores taxas.
- Amostragem dos gráficos em intervalo fixo de 1 s e renderização em canvas fora da tela antes de apresentar o quadro, reduzindo oscilações visuais.
- Seleções adicionais limitadas a 10 s ou deslocamento de pelo menos 4 peças para evitar acumular seleções redundantes.

A velocidade final continua dependendo de peers WebRTC disponíveis, peças que eles possuem, rede do usuário, CPU/memória do dispositivo e compatibilidade do codec.

## v10 — interface organizada por abas

A interface foi reorganizada em seis áreas independentes: Início, Buscar, Player, Telemetria, Peers e Sobre. Os elementos existentes mantêm seus IDs para preservar a integração com o motor WebTorrent e os eventos já implementados. A navegação funciona em telas pequenas com rolagem horizontal; ao abrir Telemetria, os gráficos são redesenhados para considerar a largura visível. O status do player também é espelhado na seção Peers.

## v11 — Telemetria em tempo real corrigida

- Velocidades globais calculadas por diferenças dos contadores cumulativos de bytes recebidos/enviados, usando o intervalo real entre amostras.
- Velocidade individual dos peers calculada por diferenças dos contadores de cada conexão, removendo peers desconectados da amostragem.
- Fallback para os estimadores de velocidade do WebTorrent no primeiro ciclo ou quando um contador reinicia.
- Gráficos com eixo temporal móvel real de 60 segundos, alinhados à direita e com marcações 60s / 30s / agora.
- Indicador visível do horário da última atualização da telemetria.
- Testes automatizados para cálculo de taxas, peers e reinício de contadores.


## v13 — telemetria renovada e DHT nativa do WebTorrent

- A telemetria ganhou um painel visual novo, com KPIs de download/upload, peers WebRTC, buffer útil, progresso, totais e gráficos.
- O buffer em destaque mostra somente a faixa contínua que contém o playhead; a barra visual é limitada a 30 segundos para leitura rápida.
- A consulta DHT agora usa o próprio cliente `webtorrent` no Node.js (`dht: true`), sem instanciar `bittorrent-dht` diretamente. O backend aguarda conexões observadas pelo evento `torrent.on("wire")`.
- A consulta é executada sem trackers para isolar a descoberta DHT; os endereços observados são peers TCP/uTP do backend, não peers WebRTC do navegador.
- A Vercel continua sem DHT UDP persistente em funções serverless. Use um servidor Node.js persistente com UDP liberado para executar a consulta.

## v12 — layout, buffer e descoberta DHT
- Buffer útil medido apenas na faixa contínua que contém o playhead; faixas futuras separadas não são somadas.
- Uma amostra de telemetria por segundo, com bloqueio de duplicatas no mesmo intervalo.
- DHT via cliente WebTorrent nativo no servidor Node persistente (`dht: true`, UDP liberado para o processo Node.js).
- Em Vercel serverless a rota retorna indisponibilidade explícita: DHT requer socket UDP persistente.
- Peers DHT são endereços potenciais TCP/UDP, não peers WebRTC confirmados.

Para DHT funcionar fora da Vercel, rode `npm install` e `npm start` em um servidor Node.js persistente com conectividade UDP. O processo Node.js precisa ter conectividade UDP de saída e entrada conforme a rede permitir. Na Vercel, o botão DHT informa a limitação do ambiente em vez de simular resultados.

## Descoberta avançada de peers (integração Magnet Fisher)

A consulta manual em **Buscar → Descobrir peers via WebTorrent DHT** agora combina:

- DHT BEP-5 com nós de bootstrap explícitos;
- descoberta local BEP-14 (LSD) e troca de peers BEP-11 (PEX);
- lista de 10 trackers UDP públicos inspirada no Magnet Fisher, somente quando o torrent foi identificado explicitamente como público;
- trackers UDP/HTTP já presentes no magnet, validados por esquema e tamanho;
- limite de até 400 conexões no processo de descoberta e janela de consulta de até 27 segundos;
- contagem, fontes, quantidade de trackers e tempo decorrido no resultado.

**Importante:** os peers encontrados por DHT/trackers UDP são peers BitTorrent TCP/uTP. Eles não se tornam peers WebRTC e não podem ser conectados diretamente pelo player do navegador. A reprodução WebTorrent continua usando trackers WSS. Torrents privados não recebem trackers públicos extras. Em Vercel/serverless, a consulta DHT permanece desabilitada porque o ambiente não oferece sockets UDP persistentes; use o backend Node.js em um servidor persistente para habilitá-la.

A integração adapta as estratégias de descoberta do Magnet Fisher ao WebTorrent já usado pelo projeto. Ajustes específicos do `libtorrent` nativo (I/O direto em disco, fila de requisições por peer e parâmetros de escalonamento do libtorrent) não são aplicáveis à API WebTorrent e não foram simulados.


## v16 — biblioteca de reprodução confirmada com Upstash Redis

Configure `UPSTASH_REDIS_REST_URL` e `UPSTASH_REDIS_REST_TOKEN` no ambiente do backend. A API grava os torrents em um Redis Hash (`twf:catalog:played:v1`) usando o info hash como chave do campo, evitando duplicatas. A gravação só ocorre depois que o elemento de vídeo efetivamente reproduz pelo menos 10 segundos; apenas analisar metadados, conectar ao swarm ou clicar em play não basta. A rota `GET /api/catalog?q=` consulta a biblioteca persistente. Sem as duas variáveis, a interface informa que a biblioteca em nuvem não está configurada e não finge persistência local.

No Upstash: crie um banco Redis, copie a REST URL e o REST token e configure ambos como variáveis de ambiente no deploy (e no `.env` local). Nunca exponha o token no frontend, repositório ou `VITE_*`.

## v16 — correção definitiva do desenho da telemetria

Os gráficos agora desenham diretamente no canvas visível, limpam o quadro completo em cada atualização, usam o tamanho real do elemento e a escala de pixels do dispositivo, redesenham eixos e séries em uma única passagem e preenchem o fundo opaco. O canvas só redimensiona o buffer interno quando suas dimensões realmente mudam, evitando tanto rastros acumulados quanto cintilação por resize a cada segundo.


## v21 — integração Stremio / Torrentio

- A aba **Buscar** inclui consulta ao Torrentio por tipo (`movie`, `series`, `anime`) e identificador IMDb (`tt...`) ou Kitsu. Para episódios de séries, aceita sufixos de temporada/episódio, por exemplo `tt0944947:1:2`.
- O backend consulta `https://torrentio.strem.fun/manifest.json` e o recurso Stremio `/stream/{type}/{id}.json` por proxy server-side, evitando dependência de CORS no navegador e sem aceitar URLs arbitrárias.
- Cada resultado com `infoHash` é convertido em magnet completo com `xt`, nome e trackers `tr` fornecidos pelo addon. Resultados com URL externa são apresentados separadamente.
- **Usar magnet no player** carrega o resultado no fluxo atual de inspeção e reprodução WebTorrent; **Copiar magnet** copia a URI completa.
- Torrentio é uma fonte de descoberta, não um serviço de hospedagem. A existência de um resultado não garante peers WebRTC, seeders ativos, compatibilidade de codec ou reprodução imediata.
- Rotas novas: `GET /api/stremio/manifest` e `GET /api/stremio/stream/:type/:id`. Não requer novas variáveis de ambiente.
