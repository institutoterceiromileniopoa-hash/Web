// Catch-all para rotas aninhadas da API na Vercel.
// Necessário, por exemplo, para POST /api/catalog/played: api/catalog.js
// sozinho só cria a rota exata /api/catalog e não cobre seus subcaminhos.
import app from '../server/index.js';

export const config = { api: { bodyParser: false } };
export default app;
