// Rota explícita da Vercel para registrar um torrent após reprodução confirmada.
// Não depender exclusivamente da função catch-all para este endpoint aninhado.
import app from '../../server/index.js';

export const config = { api: { bodyParser: false } };
export default app;
