// Rota explícita da Vercel para upload/análise de arquivo .torrent.
// bodyParser:false é obrigatório para o multer receber o multipart.
import app from '../../server/index.js';

export const config = { api: { bodyParser: false } };
export default app;
