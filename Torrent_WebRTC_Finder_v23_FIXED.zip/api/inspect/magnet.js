// Rota explícita da Vercel para análise de magnet.
import app from '../../server/index.js';

export const config = { api: { bodyParser: false } };
export default app;
