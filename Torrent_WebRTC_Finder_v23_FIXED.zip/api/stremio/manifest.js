// Rota explícita da Vercel para o manifesto do addon Torrentio.
// Mantém a URL /api/stremio/manifest fora da dependência do catch-all.
import app from '../../server/index.js';

export const config = { api: { bodyParser: false } };
export default app;
