// Rota explícita da Vercel para consultas de streams Stremio/Torrentio.
// Atende /api/stremio/stream/:type/:id e encaminha para o Express.
import app from '../../../../server/index.js';

export const config = { api: { bodyParser: false } };
export default app;
