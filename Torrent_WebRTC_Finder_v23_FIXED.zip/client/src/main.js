import './style.css';
import { getWebRtcTrackerPlan, enrichMagnetWithTrackers, buildMagnetFromHash, DEFAULT_WEBRTC_TRACKERS, collectAllPublicTrackers } from './tracker-utils.js';
import { getBufferAhead, getAdaptiveWindow, getPieceRange, chooseConnectionLimit } from './stream-optimizer.js';
import { createTelemetrySampler, getPlaybackBuffer, getDownloadedBufferAhead } from './telemetry.js';
import { createRealtimeSubtitleTranslator, parseSrtToCues } from './subtitle-translator.js';

const $ = s => document.querySelector(s);
const videoExt = /\.(mp4|m4v|mkv|webm|mov|avi|mpg|mpeg|m4v|ts)$/i;
const app = $('#app');
app.innerHTML = `
<div class="wrap">
 <header class="top"><div class="logo">⌁</div><div><h1>Torrent WebRTC Finder</h1><div class="muted small">Busca, inspeção de trackers e streaming WebRTC adaptativo</div></div></header>
 <nav class="tabbar" role="tablist" aria-label="Seções do aplicativo">
  <button class="tab active" type="button" role="tab" aria-selected="true" data-tab="home">⌂ Início</button>
  <button class="tab" type="button" role="tab" aria-selected="false" data-tab="search">⌕ Buscar</button>
  <button class="tab" type="button" role="tab" aria-selected="false" data-tab="player">▶ Player</button>
  <button class="tab" type="button" role="tab" aria-selected="false" data-tab="telemetry">▥ Telemetria</button>
  <button class="tab" type="button" role="tab" aria-selected="false" data-tab="peers">⇄ Peers</button>
  <button class="tab" type="button" role="tab" aria-selected="false" data-tab="settings">⚙ Sobre</button>
 </nav>
 <main>
  <section class="tab-view active" id="view-home" role="tabpanel">
   <div class="welcome panel"><div class="eyebrow">PAINEL PRINCIPAL</div><h2>Central de streaming WebTorrent</h2><p class="muted">Adicione um magnet ou arquivo .torrent na aba <b>Buscar</b>, confira os arquivos e depois abra o Player para iniciar a reprodução.</p><div class="home-actions"><button type="button" data-go-tab="search">Adicionar torrent</button><button type="button" class="secondary" data-go-tab="telemetry">Ver telemetria</button></div></div>
   <section class="panel"><h2>Status da sessão</h2><div id="status" class="status">Aguardando um magnet link ou arquivo .torrent.</div><div id="overview" class="cards" style="margin-top:12px"></div></section>
   <section class="panel"><h2>Etapas rápidas</h2><ol class="steps"><li>Adicione um magnet link ou arquivo .torrent em <b>Buscar</b>.</li><li>Analise o conteúdo e selecione o vídeo desejado.</li><li>Abra <b>Player</b> e toque em Conectar e reproduzir.</li><li>Acompanhe buffer, velocidades e conexões nas abas de telemetria e peers.</li></ol></section>
  </section>
  <section class="tab-view" id="view-search" role="tabpanel" hidden>
   <section class="panel add-torrent-panel"><div class="eyebrow">ORIGEM MANUAL</div><div class="section-head"><div><h2>Adicionar torrent</h2><p class="muted small">Cole magnet/hash ou escolha um .torrent e use <b>Analisar origem</b> (serve para os dois).</p></div></div><label for="magnet">Magnet link ou info hash</label><div class="magnet-row"><div class="grow"><input id="magnet" type="text" inputmode="url" autocomplete="off" spellcheck="false" placeholder="magnet:?xt=urn:btih:… ou hash de 40 caracteres"></div><button id="inspectMagnet" type="button">Analisar origem</button></div><div class="drop" id="torrentDrop"><label class="drop-label" for="torrentFile"><strong>Arquivo .torrent</strong><span class="muted small" id="torrentFileName">Toque para escolher ou arraste o arquivo aqui</span></label><input id="torrentFile" type="file" accept=".torrent,application/x-bittorrent"></div><div class="muted small" style="margin-top:10px">Dica: magnets do Torrentio já vêm com trackers WSS compatíveis com o player WebRTC.</div></section>
   <section class="panel torrentio-panel"><div class="eyebrow">FONTE STREMIO</div><div class="section-head"><div><h2>Descobrir via Torrentio</h2><p class="muted small">Consulte streams por ID IMDb ou Kitsu. Filtros de idioma e episódio no cliente.</p></div><span class="pill">Torrentio</span></div>
<div class="torrentio-form">
 <div class="grow"><label for="torrentioType">Tipo</label><select id="torrentioType"><option value="movie">Filme</option><option value="series">Série</option><option value="anime">Anime</option></select></div>
 <div class="grow"><label for="torrentioId">ID IMDb / Kitsu</label><input id="torrentioId" placeholder="tt10872600" autocomplete="off"></div>
 <div class="grow series-only" id="torrentioSeasonWrap" hidden><label for="torrentioSeason">Temporada</label><input id="torrentioSeason" type="number" min="1" max="99" placeholder="1" inputmode="numeric"></div>
 <div class="grow series-only" id="torrentioEpisodeWrap" hidden><label for="torrentioEpisode">Episódio</label><input id="torrentioEpisode" type="number" min="1" max="999" placeholder="1" inputmode="numeric"></div>
 <div class="grow"><label for="torrentioLang">Idioma</label><select id="torrentioLang"><option value="all">Todos</option><option value="pt">Português</option><option value="en">Inglês</option><option value="es">Espanhol</option><option value="fr">Francês</option><option value="de">Alemão</option><option value="it">Italiano</option><option value="ja">Japonês</option><option value="ko">Coreano</option><option value="ru">Russo</option><option value="multi">Multi / Dual</option></select></div>
 <button id="torrentioSearch" type="button">Buscar streams</button>
</div>
<div id="torrentioStatus" class="status" aria-live="polite">Pronto para consultar o Torrentio.</div>
<div class="torrentio-toolbar" id="torrentioToolbar" hidden>
 <span class="muted small" id="torrentioCount">0 resultados</span>
 <div class="torrentio-filters">
  <select id="torrentioLangFilter" class="torrentio-lang-filter" title="Filtrar idioma"><option value="all">Idioma: todos</option></select>
  <select id="torrentioWebrtcFilter" class="torrentio-webrtc-filter" title="Filtrar trackers WebRTC">
   <option value="all">Trackers: todos</option>
   <option value="webrtc">Só com WebRTC (WSS)</option>
   <option value="no-webrtc">Sem WebRTC embutido</option>
  </select>
 </div>
</div>
<div id="torrentioResults" class="torrentio-results torrentio-scroll" role="list"></div>
</section>
   <section class="panel yts-panel">
<div class="eyebrow">FONTE YTS</div>
<div class="section-head"><div><h2>Buscar filmes (YTS)</h2><p class="muted small">API movies-api.accel.li — magnets montados com trackers WSS e UDP.</p></div><span class="pill">YTS</span></div>
<div class="yts-form">
 <div class="grow"><label for="ytsQuery">Busca</label><input id="ytsQuery" placeholder="Título, IMDb tt… ou ator" autocomplete="off"></div>
 <div class="grow"><label for="ytsQuality">Qualidade</label><select id="ytsQuality"><option value="">Todas</option><option value="720p">720p</option><option value="1080p">1080p</option><option value="1080p.x265">1080p x265</option><option value="2160p">2160p</option><option value="3D">3D</option></select></div>
 <div class="grow"><label for="ytsSort">Ordenar</label><select id="ytsSort"><option value="seeds">Seeds</option><option value="date_added">Mais recentes</option><option value="rating">Nota</option><option value="download_count">Downloads</option><option value="title">Título</option></select></div>
 <div class="grow"><label for="ytsRating">Nota mín.</label><select id="ytsRating"><option value="0">Qualquer</option><option value="6">6+</option><option value="7">7+</option><option value="8">8+</option><option value="9">9+</option></select></div>
 <button id="ytsSearch" type="button">Buscar YTS</button>
</div>
<div id="ytsStatus" class="status" aria-live="polite">Pronto para buscar na YTS.</div>
<div class="yts-toolbar" id="ytsToolbar" hidden>
 <span class="muted small" id="ytsCount">0 filmes</span>
 <button type="button" class="secondary" id="ytsPrev" hidden>Anterior</button>
 <button type="button" class="secondary" id="ytsNext" hidden>Próxima</button>
</div>
<div id="ytsResults" class="yts-results catalog-scroll" role="list"></div>
</section>
   <section class="panel"><div class="section-head"><h2>Trackers e arquivos encontrados</h2><button id="dhtLookup" class="secondary" type="button">Descobrir peers via WebTorrent DHT</button></div><div id="dhtStatus" class="status dht-status">DHT ainda não consultada.</div><div id="dhtPeers" class="dht-peers"></div><div id="trackers" style="margin-top:12px"></div><div id="files"></div><div class="small muted">Selecione um arquivo de vídeo na lista para habilitar a reprodução.</div><button type="button" class="secondary" data-go-tab="player">Ir para o Player</button></section>
   <section class="panel catalog-panel"><div class="section-head"><div><h2>Biblioteca de reproduzidos</h2><p class="muted small">Torrents salvos no Upstash Redis somente após reprodução confirmada.</p></div><button id="searchBtn" class="secondary" type="button">Atualizar</button></div><div class="row catalog-search-row"><div class="grow"><input id="search" placeholder="Filtrar por nome ou info hash"></div></div><div id="catalog" class="catalog-scroll small muted" role="list">Carregando biblioteca…</div></section>
  </section>
  <section class="tab-view" id="view-player" role="tabpanel" hidden>
   <section class="panel"><div class="section-head"><div><div class="eyebrow">REPRODUÇÃO</div><h2>Player WebTorrent</h2></div><span class="pill">WebRTC</span></div><div id="peerStatus" class="status">Nenhuma conexão iniciada.</div><button id="connect" class="connect-button" disabled>Conectar e reproduzir vídeo</button><video id="preview" class="video" controls playsinline crossorigin="anonymous" hidden><track id="ptbrTrack" kind="subtitles" srclang="pt" label="Português (PT-BR)" default></video><p class="muted small">A reprodução progressiva depende de peers WebTorrent/WebRTC disponíveis, velocidade de upload deles e compatibilidade do codec com o navegador.</p></section>
   <section class="panel translator-panel" id="translatorPanel">
    <div class="section-head">
     <div><div class="eyebrow">LEGENDAS</div><h2>Tradutor SRT → PT-BR (tempo real)</h2><p class="muted small">Prioriza frases próximas ao playhead enquanto o vídeo está em reprodução.</p></div>
     <span class="pill" id="translatorBadge">Aguardando SRT</span>
    </div>
    <div class="translator-grid">
     <div class="metric"><span class="metric-label">Idioma origem</span><strong id="detectedLangInfo">—</strong></div>
     <div class="metric"><span class="metric-label">Alvo</span><strong>pt-BR</strong></div>
     <div class="metric"><span class="metric-label">Modo</span><strong id="translationSyncMode">—</strong></div>
     <div class="metric"><span class="metric-label">Cadência</span><strong id="translationRateInfo">0 frases/s</strong></div>
    </div>
    <div class="translator-progress-wrap">
     <div class="translator-progress-labels"><span id="translationProgressLabel">Frases traduzidas: 0 / 0</span><span id="translationPercentLabel">0%</span></div>
     <div class="buffer-track"><i id="translationProgressBar"></i></div>
    </div>
    <div class="status" id="liveTranslatedCuePreview">As falas traduzidas em PT-BR aparecem aqui durante a reprodução.</div>
    <div class="translator-actions">
     <label class="drop translator-drop" id="srtDrop">
      <span class="drop-label"><strong>Carregar .srt / .vtt local</strong><span class="muted small" id="srtFileLabel">Enquanto assiste, envie a legenda para traduzir ao vivo</span></span>
      <input id="srtFileInput" type="file" accept=".srt,.vtt,text/vtt,application/x-subrip">
     </label>
     <button type="button" class="secondary" id="srtFromTorrent" disabled>Usar .srt do torrent</button>
    </div>
    <div id="srtTorrentList" class="srt-torrent-list muted small"></div>
   </section>
  </section>
  <section class="tab-view" id="view-telemetry" role="tabpanel" hidden>
   <section class="panel telemetry-shell">
    <div class="telemetry-top">
     <div>
      <div class="eyebrow">SESSÃO AO VIVO</div>
      <h2>Telemetria de desempenho</h2>
      <p class="muted small">Métricas da sessão WebTorrent · atualização a cada 1 s</p>
     </div>
     <div class="telemetry-top-right">
      <div class="health-badge" id="sessionHealth">IDLE</div>
      <div class="live-indicator"><i></i><span id="telemetryUpdated">Aguardando sessão…</span></div>
     </div>
    </div>
   <div class="gauge-row" id="speedGauges">
    <div class="gauge-card gauge-download">
      <canvas id="downloadGauge" width="200" height="110" aria-label="Velocímetro de download"></canvas>
      <div class="gauge-readout"><strong id="downloadSpeedValue">0 KB/s</strong><span>Download</span></div>
    </div>
    <div class="gauge-card gauge-upload">
      <canvas id="uploadGauge" width="200" height="110" aria-label="Velocímetro de upload"></canvas>
      <div class="gauge-readout"><strong id="uploadSpeedValue">0 KB/s</strong><span>Upload</span></div>
    </div>
   </div>
   <canvas id="bufferGaugeDial" width="1" height="1" hidden aria-hidden="true"></canvas>
   <div class="telemetry-hero" id="peerMetrics">
    <div class="metric metric-peers"><span class="metric-label">Peers WebRTC</span><strong id="peerCountValue">0</strong><span class="metric-foot" id="peerStateValue">Aguardando conexão</span><div class="metric-icon">⇄</div></div>
    <div class="metric metric-buffer buffer-primary"><span class="metric-label">Buffer à frente</span><strong id="bufferAheadValue">—</strong><span class="metric-foot" id="bufferStateValue">Aguardando</span><div class="buffer-track"><i id="bufferGauge"></i></div></div>
    <div class="metric"><span class="metric-label">Progresso</span><strong id="progressValueHero">0%</strong><span class="metric-foot" id="bufferBarLabel">0% da meta</span></div>
    <div class="metric"><span class="metric-label">Saúde</span><strong id="healthValueHero">IDLE</strong><span class="metric-foot">Sessão atual</span></div>
   </div>
   <div class="telemetry-details">
    <div class="metric"><span class="metric-label">Baixado</span><strong id="downloadedValue">0 MB</strong></div>
    <div class="metric"><span class="metric-label">Enviado</span><strong id="uploadedValue">0 MB</strong></div>
    <div class="metric"><span class="metric-label">Progresso</span><strong id="progressValue">0%</strong></div>
    <div class="metric"><span class="metric-label">Média / peer</span><strong id="peerAvgSpeedValue">0 KB/s</strong></div>
    <div class="metric"><span class="metric-label">Modo adaptativo</span><strong id="bufferModeValue">AGUARDANDO</strong></div>
    <div class="metric"><span class="metric-label">Meta de buffer</span><strong id="bufferTargetValue">—</strong></div>
    <div class="metric"><span class="metric-label">Razão U/D</span><strong id="ratioValue">—</strong></div>
    <div class="metric"><span class="metric-label">Tempo de sessão</span><strong id="sessionTimeValue">00:00</strong></div>
   </div>
   <div class="charts-grid" id="telemetryCharts">
    <div class="chart-panel"><div class="chart-heading"><b>Velocidade de transferência</b><span class="muted small">Últimos 60 segundos · KB/s</span></div><canvas id="speedChart" height="180" aria-label="Gráfico de download e upload"></canvas><div class="chart-legend"><span><i class="legend-dot download"></i>Download</span><span><i class="legend-dot upload"></i>Upload</span></div></div>
    <div class="chart-panel"><div class="chart-heading"><b>Peers conectados</b><span class="muted small">Últimos 60 segundos</span></div><canvas id="peerChart" height="180" aria-label="Gráfico de peers WebRTC conectados"></canvas><div class="chart-legend"><span><i class="legend-dot peers"></i>Peers WebRTC</span></div></div>
    <div class="chart-panel"><div class="chart-heading"><b>Buffer de reprodução</b><span class="muted small">Uma amostra por segundo · faixa contínua</span></div><canvas id="bufferChart" height="180" aria-label="Gráfico do buffer de reprodução"></canvas><div class="chart-legend"><span><i class="legend-dot buffer"></i>Buffer à frente</span></div></div>
   </div></section>
  </section>
  <section class="tab-view" id="view-peers" role="tabpanel" hidden>
   <section class="panel"><div class="eyebrow">SWARM WEBRTC</div><h2>Peers e conexões</h2><div class="peer-summary" id="peerStatusMirror">As conexões aparecerão aqui quando o torrent for iniciado.</div><div class="peer-panel"><div class="chart-heading"><b>Desempenho por peer</b><span class="muted small">Conexões WebRTC ativas</span></div><div id="peerDetails" class="peer-details"><span class="muted small">Aguardando conexões…</span></div></div><p class="muted small">Este navegador compartilha automaticamente as peças verificadas que já recebeu. Para continuar sendo peer, mantenha esta página aberta; o compartilhamento termina quando a sessão é encerrada.</p></section>
  </section>
  <section class="tab-view" id="view-settings" role="tabpanel" hidden>
   <section class="panel"><div class="eyebrow">INFORMAÇÕES</div><h2>Sobre o Torrent WebRTC Finder</h2><p class="muted">O aplicativo usa WebTorrent no navegador para conectar a peers compatíveis com WebRTC, analisar metadados e reproduzir arquivos de vídeo progressivamente.</p><h3>Limitações importantes</h3><ul class="steps"><li>O navegador só estabelece conexões com peers que suportam transporte WebTorrent/WebRTC.</li><li>Um tracker WSS ativo não garante que existam peers ou peças disponíveis.</li><li>Não existe conversão automática de peers BitTorrent TCP/UDP para WebRTC.</li><li>A velocidade depende do swarm, dos peers, da rede, do dispositivo e dos codecs suportados.</li></ul><p class="muted small">Nenhuma fonte externa ou catálogo de indexadores é consultado automaticamente.</p></section>
  </section>
 </main>
</div>`;

// Navegação entre áreas: mantém os elementos e seus IDs no DOM para preservar os listeners do motor.
function activateTab(name) {
 const valid = ['home','search','player','telemetry','peers','settings'];
 if (!valid.includes(name)) return;
 document.querySelectorAll('.tab').forEach(button => {
  const active = button.dataset.tab === name;
  button.classList.toggle('active', active);
  button.setAttribute('aria-selected', String(active));
 });
 document.querySelectorAll('.tab-view').forEach(view => {
  const active = view.id === `view-${name}`;
  view.classList.toggle('active', active);
  view.hidden = !active;
 });
 if (name === 'telemetry') {
  requestAnimationFrame(() => {
   drawTelemetryCharts();
   drawTelemetryGauges(lastGaugeDownload * 1024, lastGaugeUpload * 1024, lastGaugeBuffer, 60);
  });
 }
}

document.querySelectorAll('[data-tab]').forEach(button => button.addEventListener('click', () => activateTab(button.dataset.tab)));
document.querySelectorAll('[data-go-tab]').forEach(button => button.addEventListener('click', () => activateTab(button.dataset.goTab)));


let current = null;
let activeClient = null;
let WebTorrentCtor = null;

// Carrega a distribuição de navegador diretamente do CDN oficial.
// Isso impede que o Vite resolva o entry point Node.js (torrent-discovery,
// DHT/UDP, EventEmitter etc.) dentro do bundle do navegador.
async function loadWebTorrent() {
 if (WebTorrentCtor) return WebTorrentCtor;
 const mod = await import('https://esm.sh/webtorrent@2.5.19/dist/webtorrent.min.js');
 const ctor = mod.default || mod.WebTorrent || mod;
 if (typeof ctor !== 'function') throw new Error('A distribuição WebTorrent para navegador não carregou corretamente.');
 if (ctor.WEBRTC_SUPPORT === false) throw new Error('Este navegador não oferece suporte WebRTC.');
 WebTorrentCtor = ctor;
 return WebTorrentCtor;
}
let activeTorrent = null;
let torrentFileObject = null;
let torrentFileBuffer = null; // cópia dos bytes do .torrent para o player
let lastMagnetUri = null;     // magnet normalizado da última análise
let serviceWorkerRegistration = null;
let streamServerReady = false;
let playbackEventsBound = false;
let telemetryTimer = null;
let telemetryRaf = null;
let telemetryRunning = false;
let subtitleTranslator = null;
let activeSrtFileIndex = null;
let selectedVideoFile = null;
let lastCriticalPiece = -1;
let lastAdaptiveWindow = null;
let telemetrySampler = createTelemetrySampler();
const status = msg => $('#status').textContent = msg;
const peerStatus = msg => { $('#peerStatus').textContent = msg; const mirror = $('#peerStatusMirror'); if (mirror) mirror.textContent = msg; };
const pretty = n => n == null ? '—' : `${(n / 1024 / 1024).toFixed(2)} MB`;
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const telemetry = { download: [], upload: [], peers: [], buffer: [], times: [] };
let lastTelemetryStamp = 0;
const chartWindow = 60;
const formatRate = n => n >= 1024*1024 ? `${(n/1024/1024).toFixed(2)} MB/s` : `${(n/1024).toFixed(1)} KB/s`;

/** Velocímetro estilo moto: arco semicircular com ponteiro e marcas. */
function drawSpeedometer(canvas, valueKBs, { maxKBs = 8192, color = '#3dd6a5', label = '' } = {}) {
  if (!canvas) return;
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.max(1, Math.min(2.5, window.devicePixelRatio || 1));
  // Quando a aba está hidden, getBoundingClientRect() pode ser 0 — usa fallback.
  const cssW = Math.max(140, rect.width || canvas.clientWidth || 180);
  const cssH = Math.max(88, rect.height || canvas.clientHeight || 105);
  const w = Math.round(cssW * dpr);
  const h = Math.round(cssH * dpr);
  if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssW, cssH);

  const cx = cssW / 2;
  const cy = cssH * 0.72;
  const radius = Math.min(cssW * 0.42, cssH * 0.58);
  const start = Math.PI * 0.85; // ~153°
  const end = Math.PI * 0.15 + Math.PI * 2; // wrap
  // Use start= Math.PI * 1.0 (180°) to Math.PI * 2 (0°? wait)
  // Motorcycle gauge: left low, right high. Arc from 180° to 0° going clockwise through bottom? Classic is π to 0 via -π/2 is wrong.
  // Classic speedometer: from 135° (SW) to 45° (SE) going through 90° bottom? Actually from π*0.75 to π*0.25 clockwise.
  const a0 = Math.PI * 0.75; // 135deg
  const a1 = Math.PI * 0.25; // 45deg
  // Sweep going clockwise from a0 to a1 means we go a0 -> π -> ... no, canvas arcs are clockwise when counterclockwise=false? 
  // arc(x,y,r,start,end,false) goes clockwise from start to end in standard math? In canvas, angles increase clockwise.
  // Math angles: 0=east, PI/2=south. Canvas same with y-down.
  // From 135° (NW-ish in screen: actually 135 is SW) to 45° clockwise = through south (good for semi gauge).

  // Background plate
  ctx.beginPath();
  ctx.arc(cx, cy, radius + 8, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(8,14,24,0.55)';
  ctx.fill();

  // Track (dark arc)
  ctx.beginPath();
  ctx.arc(cx, cy, radius, a0, a1, false);
  ctx.strokeStyle = '#1a2a3f';
  ctx.lineWidth = 12;
  ctx.lineCap = 'round';
  ctx.stroke();

  // Value arc
  const ratio = Math.max(0, Math.min(1, (Number(valueKBs) || 0) / maxKBs));
  const aVal = a0 + (a1 - a0 + (a1 < a0 ? Math.PI * 2 : 0)) * ratio;
  // Correct sweep: from a0 clockwise to a1 is (a1 - a0 + 2π) % 2π if a1<a0
  const sweep = ((a1 - a0) + Math.PI * 2) % (Math.PI * 2);
  const aNeedle = a0 + sweep * ratio;

  if (ratio > 0.001) {
    ctx.beginPath();
    ctx.arc(cx, cy, radius, a0, aNeedle, false);
    const grad = ctx.createLinearGradient(cx - radius, cy, cx + radius, cy);
    grad.addColorStop(0, color + '99');
    grad.addColorStop(1, color);
    ctx.strokeStyle = grad;
    ctx.lineWidth = 12;
    ctx.lineCap = 'round';
    ctx.stroke();
  }

  // Tick marks
  const ticks = 8;
  for (let i = 0; i <= ticks; i++) {
    const t = i / ticks;
    const ang = a0 + sweep * t;
    const inner = radius - 16;
    const outer = radius - 6;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(ang) * inner, cy + Math.sin(ang) * inner);
    ctx.lineTo(cx + Math.cos(ang) * outer, cy + Math.sin(ang) * outer);
    ctx.strokeStyle = i % 2 === 0 ? '#6b829e' : '#3a4f68';
    ctx.lineWidth = i % 2 === 0 ? 2 : 1.2;
    ctx.stroke();
  }

  // Needle
  const needleLen = radius - 20;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(aNeedle);
  ctx.beginPath();
  ctx.moveTo(-4, 0);
  ctx.lineTo(needleLen, 0);
  ctx.lineTo(-4, 0);
  ctx.strokeStyle = color;
  ctx.lineWidth = 2.5;
  ctx.lineCap = 'round';
  ctx.stroke();
  // tip triangle
  ctx.beginPath();
  ctx.moveTo(needleLen + 2, 0);
  ctx.lineTo(needleLen - 10, -4);
  ctx.lineTo(needleLen - 10, 4);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
  ctx.restore();

  // Hub
  ctx.beginPath();
  ctx.arc(cx, cy, 7, 0, Math.PI * 2);
  ctx.fillStyle = '#0c1522';
  ctx.fill();
  ctx.beginPath();
  ctx.arc(cx, cy, 4, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();

  // Red zone near max
  ctx.beginPath();
  ctx.arc(cx, cy, radius, a0 + sweep * 0.85, a1, false);
  ctx.strokeStyle = 'rgba(240,113,120,0.55)';
  ctx.lineWidth = 4;
  ctx.lineCap = 'round';
  ctx.stroke();
}

let lastGaugeDownload = 0;
let lastGaugeUpload = 0;
let lastGaugeBuffer = 0;

function drawTelemetryGauges(downloadBps = 0, uploadBps = 0, bufferSec = 0, targetBuffer = 60) {
  // Suavização leve do ponteiro (estilo instrumento)
  lastGaugeDownload = lastGaugeDownload * 0.55 + (downloadBps / 1024) * 0.45;
  lastGaugeUpload = lastGaugeUpload * 0.55 + (uploadBps / 1024) * 0.45;
  lastGaugeBuffer = lastGaugeBuffer * 0.5 + (Number.isFinite(bufferSec) ? bufferSec : 0) * 0.5;
  const maxDown = Math.max(2048, lastGaugeDownload * 1.4, 512);
  const maxUp = Math.max(1024, lastGaugeUpload * 1.4, 256);
  drawSpeedometer($('#downloadGauge'), lastGaugeDownload, { maxKBs: maxDown, color: '#4f9cff' });
  drawSpeedometer($('#uploadGauge'), lastGaugeUpload, { maxKBs: maxUp, color: '#3dd6a5' });
  drawSpeedometer($('#bufferGaugeDial'), lastGaugeBuffer, { maxKBs: Math.max(targetBuffer || 60, 10), color: '#f0b45a' });
}

function stopRealtimeTelemetry() {
  telemetryRunning = false;
  if (telemetryTimer) { clearInterval(telemetryTimer); telemetryTimer = null; }
  if (telemetryRaf) { cancelAnimationFrame(telemetryRaf); telemetryRaf = null; }
}
function resetTelemetry() {
  stopRealtimeTelemetry();

  for (const key of Object.keys(telemetry)) telemetry[key].length = 0;
  lastTelemetryStamp = 0;
  telemetrySampler = createTelemetrySampler();
  lastGaugeDownload = lastGaugeUpload = lastGaugeBuffer = 0;
  const stamp = $('#telemetryUpdated');
  if (stamp) stamp.textContent = 'Aguardando amostras…';
  drawTelemetryCharts();
  drawTelemetryGauges(0, 0, 0, 60);
  const healthHero = $('#healthValueHero');
  if (healthHero) healthHero.textContent = 'IDLE';
  const prog = $('#progressValueHero');
  if (prog) prog.textContent = '0%';
}
function pushTelemetry(download, upload, peers, bufferAhead, timestamp=Date.now()) {
 // Evita duplicar pontos quando eventos e timer coincidem no mesmo segundo.
 const slot = Math.floor(timestamp / 1000); if (slot <= lastTelemetryStamp) return; lastTelemetryStamp = slot;
 telemetry.download.push(download/1024); telemetry.upload.push(upload/1024); telemetry.peers.push(peers); telemetry.buffer.push(Number.isFinite(bufferAhead) ? bufferAhead : null); telemetry.times.push(timestamp);
 const cutoff=timestamp-chartWindow*1000;
 while(telemetry.times.length && (telemetry.times.length>chartWindow || telemetry.times[0]<cutoff)){for(const key of Object.keys(telemetry))telemetry[key].shift();}
 drawTelemetryCharts();
}
function drawLineChart(canvas, series, suffix='') {
 if (!canvas) return;
 const rect = canvas.getBoundingClientRect();
 if (rect.width < 2 || rect.height < 2) return;
 const dpr = Math.max(1, Math.min(3, window.devicePixelRatio || 1));
 const width = Math.max(1, Math.round(rect.width * dpr));
 const height = Math.max(1, Math.round(rect.height * dpr));
 // Resize somente quando necessário; limpar o quadro inteiro em TODA renderização
 // impede rastros, anti-aliasing acumulado e eixos borrados.
 if (canvas.width !== width) canvas.width = width;
 if (canvas.height !== height) canvas.height = height;
 const ctx = canvas.getContext('2d'); if (!ctx) return;
 ctx.setTransform(1, 0, 0, 1, 0, 0);
 ctx.clearRect(0, 0, width, height);
 ctx.fillStyle = '#070d16'; ctx.fillRect(0, 0, width, height);
 const pad={l:42*dpr,r:12*dpr,t:14*dpr,b:25*dpr};
 const plotW=Math.max(1,width-pad.l-pad.r), plotH=Math.max(1,height-pad.t-pad.b);
 const allValues=series.flatMap(item=>item.values).filter(Number.isFinite).map(v=>Math.max(0,v));
 const maxRaw=Math.max(1,...allValues);
 const max=maxRaw <= 5 ? Math.ceil(maxRaw) || 1 : Math.ceil(maxRaw / 5) * 5;
 const now=Date.now();
 ctx.font=`${10*dpr}px system-ui`; ctx.textAlign='right'; ctx.textBaseline='middle';
 ctx.fillStyle='#8494aa'; ctx.strokeStyle='rgba(130,150,175,.18)'; ctx.lineWidth=Math.max(1,dpr);
 for(let i=0;i<=4;i++){
  const y=pad.t+plotH*i/4;
  ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(width-pad.r,y);ctx.stroke();
  ctx.fillText(`${Number((max*(4-i)/4).toFixed(max<10?1:0))}${suffix}`,pad.l-7*dpr,y);
 }
 series.forEach(item=>{
  if(!item.values.length)return;
  ctx.beginPath();ctx.strokeStyle=item.color;ctx.lineWidth=2*dpr;ctx.lineJoin='round';ctx.lineCap='round';
  let drawing=false;
  item.values.forEach((value,index)=>{
   if(!Number.isFinite(value)){drawing=false;return;}
   const stamp=telemetry.times[index]??now;
   const x=pad.l+plotW*Math.max(0,Math.min(1,(stamp-(now-chartWindow*1000))/(chartWindow*1000)));
   const y=pad.t+plotH-(Math.max(0,value)/max)*plotH;
   if(!drawing){ctx.moveTo(x,y);drawing=true;}else ctx.lineTo(x,y);
  });
  ctx.stroke();
 });
 ctx.fillStyle='#8494aa';ctx.textBaseline='alphabetic';ctx.textAlign='left';ctx.fillText('60s',pad.l,height-7*dpr);
 ctx.textAlign='center';ctx.fillText('30s',pad.l+plotW/2,height-7*dpr);
 ctx.textAlign='right';ctx.fillText('agora',pad.l+plotW,height-7*dpr);
}
function drawTelemetryCharts(){
 drawLineChart($('#speedChart'),[{values:telemetry.download,color:'#58a6ff'},{values:telemetry.upload,color:'#55ddb0'}]);
 drawLineChart($('#peerChart'),[{values:telemetry.peers,color:'#c49bff'}]);
 drawLineChart($('#bufferChart'),[{values:telemetry.buffer,color:'#f5b95f'}],'s');
}
if ('ResizeObserver' in window) { const ro = new ResizeObserver(drawTelemetryCharts); const charts=$('#telemetryCharts'); if(charts) ro.observe(charts); }
window.addEventListener('resize', () => {
  drawTelemetryCharts();
  drawTelemetryGauges(lastGaugeDownload * 1024, lastGaugeUpload * 1024, lastGaugeBuffer, 60);
}, {passive:true});


// Lê a resposta como texto antes de interpretar JSON. Assim, páginas HTML
// de erro/roteamento da hospedagem geram uma mensagem útil no diagnóstico.
async function readApiResponse(response) {
 const raw = await response.text();
 let data;
 try { data = raw ? JSON.parse(raw) : {}; }
 catch {
  const preview = raw.replace(/\s+/g, ' ').slice(0, 110);
  throw new Error(`A API retornou conteúdo que não é JSON (HTTP ${response.status}). Verifique a rota /api na hospedagem. Resposta: ${preview || '(vazia)'}`);
 }
 if (!response.ok) throw new Error(data.error || `Erro HTTP ${response.status}`);
 return data;
}

function render(data) {
 current = data;
 const hash = data.infoHash || 'Pendente';
 $('#overview').innerHTML = `<div class="metric hash-metric"><strong class="hash-value" title="${esc(hash)}">${esc(hash)}</strong><span class="muted small">Info hash</span>${data.infoHash ? '<button type="button" class="hash-copy secondary" id="copyInfoHash">Copiar hash completo</button>' : ''}</div><div class="metric"><strong>${data.trackers?.length || 0}</strong><span class="muted small">Trackers embutidos</span></div><div class="metric"><strong>${data.files?.length || 0}</strong><span class="muted small">Arquivos identificados</span></div><div class="metric"><strong>${pretty(data.totalLength)}</strong><span class="muted small">Tamanho total</span></div>`;
 const copyHash = $('#copyInfoHash');
 if (copyHash) copyHash.addEventListener('click', async () => { try { await navigator.clipboard.writeText(hash); copyHash.textContent = 'Copiado'; } catch { copyHash.textContent = 'Cópia indisponível'; } });
 const trackers = data.trackers || [];
 $('#trackers').innerHTML = `<h2>Trackers detectados</h2>${trackers.length ? trackers.map(t=>`<div class="tracker"><span class="pill ${t.type==='websocket'?'':'warn'}">${esc(t.type)}</span> ${esc(t.url)}</div>`).join('') : '<p class="muted small">Nenhum tracker embutido. DHT ou trackers adicionados pelo cliente podem ser necessários.</p>'}`;
 const files = data.files || [];
 const vids = files.filter(f=>videoExt.test(f.name));
 $('#files').innerHTML = `<h2 style="margin-top:16px">Arquivos de vídeo (${vids.length})</h2>${vids.length ? vids.map(f=>`<div class="tracker">${esc(f.name)} <span class="muted">— ${pretty(f.length)}</span></div>`).join('') : '<p class="muted small">Em magnet sem metadados, a lista aparece depois que o cliente obtiver o metadata do swarm.</p>'}`;
 $('#connect').disabled = false;
}


function setAddFeedback(state, message) {
  const panel = document.querySelector('.add-torrent-panel');
  if (panel) {
    panel.classList.remove('feedback-ok', 'feedback-err', 'feedback-loading');
    if (state) panel.classList.add(`feedback-${state}`);
  }
  const statusEl = $('#status');
  if (message && statusEl) {
    statusEl.textContent = message;
    statusEl.classList.remove('status-ok', 'status-err', 'status-loading');
    if (state === 'ok') statusEl.classList.add('status-ok');
    if (state === 'err') statusEl.classList.add('status-err');
    if (state === 'loading') statusEl.classList.add('status-loading');
  } else if (message) {
    status(message);
  }
  const magnet = $('#magnet');
  if (magnet) {
    magnet.classList.remove('input-ok', 'input-err', 'input-loading');
    if (state === 'ok') magnet.classList.add('input-ok');
    if (state === 'err') magnet.classList.add('input-err');
    if (state === 'loading') magnet.classList.add('input-loading');
  }
  const drop = $('#torrentDrop');
  if (drop) {
    drop.classList.remove('feedback-ok', 'feedback-err', 'feedback-loading');
    if (state) drop.classList.add(`feedback-${state}`);
  }
  const btn = $('#inspectMagnet');
  if (btn && state === 'loading') {
    btn.dataset.prevLabel = btn.textContent;
    btn.textContent = 'Analisando…';
    btn.disabled = true;
  } else if (btn && btn.dataset.prevLabel) {
    btn.textContent = btn.dataset.prevLabel;
    btn.disabled = false;
    delete btn.dataset.prevLabel;
  }
}

function normalizeMagnetInput(raw) {
 const value = String(raw || '').trim();
 if (!value) return null;
 if (/^magnet:\?/i.test(value)) return value;
 if (/^[a-f0-9]{40}$/i.test(value)) return `magnet:?xt=urn:btih:${value.toLowerCase()}`;
 if (/^[a-z2-7]{32}$/i.test(value)) return `magnet:?xt=urn:btih:${value.toUpperCase()}`;
 if (/^xt=urn:btih:/i.test(value)) return `magnet:?${value}`;
 return value;
}

function buildMagnetFromInfoHash(infoHash, name, trackers = []) {
 const hash = String(infoHash || '').toLowerCase();
 if (!/^[a-f0-9]{40}$/.test(hash)) return null;
 const dn = name ? `&dn=${encodeURIComponent(name)}` : '';
 const tr = (trackers || [])
  .map(t => typeof t === 'string' ? t : t?.url)
  .filter(Boolean)
  .map(url => `&tr=${encodeURIComponent(url)}`)
  .join('');
 return `magnet:?xt=urn:btih:${hash}${dn}${tr}`;
}

/** Resolve a origem para WebTorrent.add de forma estável.
 * Prefere infoHash (hex) + announce, depois File, depois magnet limpo.
 * Magnets longos com trackers inválidos costumam gerar "Invalid torrent identifier".
 */
function resolvePlayableSource() {
 const hashFromCurrent = current?.infoHash && /^[a-f0-9]{40}$/i.test(current.infoHash)
  ? current.infoHash.toLowerCase()
  : null;

 // 1) Arquivo .torrent (File/Blob) — formato nativo aceito pelo WebTorrent no browser
 if (torrentFileObject instanceof Blob && torrentFileObject.size > 0) {
  return { kind: 'file', value: torrentFileObject, infoHash: hashFromCurrent };
 }
 // 2) Bytes do .torrent já lidos
 if (torrentFileBuffer instanceof Uint8Array && torrentFileBuffer.byteLength > 0) {
  // Cópia isolada: evita SharedArrayBuffer / views parciais que o parse-torrent rejeita
  const copy = torrentFileBuffer.slice();
  return { kind: 'buffer', value: copy, infoHash: hashFromCurrent };
 }

 // 3) Info hash conhecido da análise (mais estável que magnet enorme)
 if (hashFromCurrent) {
  return { kind: 'infoHash', value: hashFromCurrent, infoHash: hashFromCurrent };
 }

 // 4) Magnet do campo / última análise — sanitizado
 const candidates = [
  $('#magnet')?.value?.trim(),
  lastMagnetUri,
  current?.magnetURI
 ].filter(Boolean);

 for (const raw of candidates) {
  const normalized = normalizeMagnetInput(raw);
  if (!normalized || !/^magnet:\?/i.test(normalized)) continue;
  // Extrai infoHash do magnet; se possível, usa só o hash
  try {
   const url = new URL(normalized);
   const xt = url.searchParams.getAll('xt').find(v => /^urn:btih:/i.test(v));
   if (xt) {
    const rawHash = xt.replace(/^urn:btih:/i, '');
    if (/^[a-f0-9]{40}$/i.test(rawHash)) {
     return { kind: 'infoHash', value: rawHash.toLowerCase(), infoHash: rawHash.toLowerCase(), magnet: normalized };
    }
   }
  } catch {}
  // Magnet simples sem trackers extras (parse-torrent é mais tolerante)
  try {
   const url = new URL(normalized);
   const xt = url.searchParams.get('xt');
   const dn = url.searchParams.get('dn');
   if (xt) {
    let simple = `magnet:?xt=${encodeURIComponent(xt)}`;
    if (dn) simple += `&dn=${encodeURIComponent(dn)}`;
    return { kind: 'magnet', value: simple, infoHash: hashFromCurrent, magnet: simple };
   }
  } catch {}
  return { kind: 'magnet', value: normalized, infoHash: hashFromCurrent, magnet: normalized };
 }

 return null;
}

async function inspectMagnet() {
 const raw = $('#magnet').value.trim();
 if (!raw) return status('Cole um magnet link ou um info hash.');
 const magnet = normalizeMagnetInput(raw);
 if (!magnet || !/^magnet:\?/i.test(magnet)) {
  return status('Informe um magnet link válido (magnet:?…) ou um info hash de 40 caracteres hex.');
 }
 if (magnet !== raw) $('#magnet').value = magnet;
 torrentFileObject = null;
 torrentFileBuffer = null;
 lastMagnetUri = magnet;
 const nameEl = $('#torrentFileName');
 if (nameEl) nameEl.textContent = 'Toque para escolher ou arraste o arquivo aqui';
 setAddFeedback('loading', 'Analisando magnet…');
 try {
  const r = await fetch('/api/inspect/magnet', {
   method: 'POST',
   headers: { 'Content-Type': 'application/json' },
   body: JSON.stringify({ magnet })
  });
  const data = await readApiResponse(r);
  data.magnetURI = magnet;
  lastMagnetUri = magnet;
  render(data);
  const n = ensureMaxTrackersOnCurrent();
  setAddFeedback('ok', `Magnet analisado. ${n ? n + ' trackers públicos embutidos. ' : ''}Metadados completos dependem do swarm.`);
 } catch (e) {
  setAddFeedback('err', `Falha: ${e.message}`);
 }
}

async function inspectTorrentFile(file) {
 if (!file) return;
 if (!/\.torrent$/i.test(file.name) && file.type !== 'application/x-bittorrent') {
  return status('Selecione um arquivo com extensão .torrent.');
 }
 torrentFileObject = file;
 try {
  const ab = await file.arrayBuffer();
  torrentFileBuffer = new Uint8Array(ab);
 } catch {
  torrentFileBuffer = null;
 }
 lastMagnetUri = null;
 const nameEl = $('#torrentFileName');
 if (nameEl) nameEl.textContent = `${file.name} (${pretty(file.size)})`;
 $('#magnet').value = '';
 setAddFeedback('loading', 'Lendo arquivo .torrent…');
 const fd = new FormData();
 fd.append('torrent', file);
 try {
  const r = await fetch('/api/inspect/file', { method: 'POST', body: fd });
  const data = await readApiResponse(r);
  if (data.infoHash) {
   data.magnetURI = buildMagnetFromInfoHash(data.infoHash, data.name, data.trackers);
   lastMagnetUri = data.magnetURI;
  }
  render(data);
  const n = ensureMaxTrackersOnCurrent();
  setAddFeedback('ok', `Arquivo analisado. ${n ? n + ' trackers embutidos. ' : ''}Trackers e arquivos extraídos do metainfo.`);
 } catch (err) {
  status(`Falha: ${err.message}`);
 }
}

/** Botão único: prioriza arquivo selecionado; senão, magnet/hash do campo. */
async function inspectSource() {
 const fileInput = $('#torrentFile');
 const file = fileInput?.files?.[0] || torrentFileObject;
 if (file) {
  await inspectTorrentFile(file);
  return;
 }
 await inspectMagnet();
}

$('#inspectMagnet').addEventListener('click', () => { inspectSource(); });
$('#magnet').addEventListener('input', () => {
 setAddFeedback(null);
 if ($('#magnet').value.trim()) {
  torrentFileObject = null;
  torrentFileBuffer = null;
  const nameEl = $('#torrentFileName');
  if (nameEl) nameEl.textContent = 'Toque para escolher ou arraste o arquivo aqui';
  if (fileInputClearable()) {
   try { $('#torrentFile').value = ''; } catch {}
  }
 }
});
function fileInputClearable() { return Boolean($('#torrentFile')); }
$('#magnet').addEventListener('keydown', event => {
 if (event.key === 'Enter') {
  event.preventDefault();
  inspectSource();
 }
});
$('#magnet').addEventListener('paste', () => {
 setTimeout(() => {
  const v = $('#magnet').value.trim();
  if (v && (v.startsWith('magnet:?') || /^[a-f0-9]{40}$/i.test(v) || /^[a-z2-7]{32}$/i.test(v))) {
   inspectMagnet();
  }
 }, 0);
});
$('#torrentFile').addEventListener('change', async e => {
 const file = e.target.files?.[0];
 if (!file) return;
 await inspectTorrentFile(file);
});

const dropZone = $('#torrentDrop');
if (dropZone) {
 ['dragenter', 'dragover'].forEach(type => {
  dropZone.addEventListener(type, event => {
   event.preventDefault();
   event.stopPropagation();
   dropZone.classList.add('drop-active');
  });
 });
 ['dragleave', 'drop'].forEach(type => {
  dropZone.addEventListener(type, event => {
   event.preventDefault();
   event.stopPropagation();
   dropZone.classList.remove('drop-active');
  });
 });
 dropZone.addEventListener('drop', async event => {
  const file = event.dataTransfer?.files?.[0];
  if (!file) return;
  const input = $('#torrentFile');
  try {
   const dt = new DataTransfer();
   dt.items.add(file);
   input.files = dt.files;
  } catch {}
  await inspectTorrentFile(file);
 });
}

let torrentioStreamsCache = [];

function detectStreamLanguage(title = '') {
  const t = String(title).toLowerCase();
  if (/\b(multi|dual|dual.?audio|multi.?audio|m.?dual)\b/.test(t)) return 'multi';
  if (/\b(pt[- ]?br|portugu[eê]s|brazilian|legenda|dublado|nacional)\b/.test(t)) return 'pt';
  if (/\b(spa(nish)?|castellano|latino|español|espanhol)\b/.test(t)) return 'es';
  if (/\b(french|fran[cç]ais|vff|truefrench)\b/.test(t)) return 'fr';
  if (/\b(german|deutsch|ger)\b/.test(t)) return 'de';
  if (/\b(italian|ita)\b/.test(t)) return 'it';
  if (/\b(japanese|jap|nihongo)\b/.test(t)) return 'ja';
  if (/\b(korean|kor)\b/.test(t)) return 'ko';
  if (/\b(russian|rus)\b/.test(t)) return 'ru';
  if (/\b(eng(lish)?|en[- ]?us|yify|rarbg)\b/.test(t)) return 'en';
  return 'other';
}

const LANG_LABELS = {
  all: 'Todos', pt: 'Português', en: 'Inglês', es: 'Espanhol', fr: 'Francês',
  de: 'Alemão', it: 'Italiano', ja: 'Japonês', ko: 'Coreano', ru: 'Russo',
  multi: 'Multi / Dual', other: 'Outros'
};


function streamHasWebRtcTrackers(item) {
  if (!item || typeof item !== 'object') return false;
  const urls = [];
  if (typeof item.magnet === 'string') {
    try {
      const u = new URL(item.magnet);
      urls.push(...u.searchParams.getAll('tr'));
    } catch {}
  }
  if (typeof item.magnetUri === 'string') {
    try {
      const u = new URL(item.magnetUri);
      urls.push(...u.searchParams.getAll('tr'));
    } catch {}
  }
  const sources = Array.isArray(item.sources) ? item.sources : [];
  for (const s of sources) {
    const v = typeof s === 'string' ? s : s?.url;
    if (typeof v === 'string') urls.push(v.replace(/^tracker:/i, ''));
  }
  if (Array.isArray(item.trackers)) {
    for (const t of item.trackers) {
      const v = typeof t === 'string' ? t : t?.url;
      if (typeof v === 'string') urls.push(v);
    }
  }
  return urls.some(url => {
    try { return new URL(url).protocol === 'wss:'; } catch {
      return /^wss:/i.test(url);
    }
  });
}

function injectWebRtcTrackersIntoMagnet(magnet) {
  // Sempre embute o máximo de trackers públicos (WSS + UDP/HTTP) no magnet.
  const result = enrichMagnetWithTrackers(magnet, { includeUdp: true, isPrivate: false });
  if (result && typeof result === 'object' && result.magnet) {
    if (result.added > 0) {
      console.debug(`[trackers] +${result.added} trackers embutidos (total ${result.total})`);
    }
    return result.magnet;
  }
  return typeof result === 'string' ? result : magnet;
}

function ensureMaxTrackersOnCurrent() {
  if (!current) return;
  const defaults = collectAllPublicTrackers();
  const have = new Set((current.trackers || []).map(t => (typeof t === 'string' ? t : t?.url)?.toLowerCase()).filter(Boolean));
  const added = [];
  for (const url of defaults) {
    if (have.has(url.toLowerCase())) continue;
    current.trackers = [...(current.trackers || []), { url, type: url.startsWith('wss') ? 'websocket' : 'tracker', injected: true }];
    have.add(url.toLowerCase());
    added.push(url);
  }
  if (current.magnetURI) {
    current.magnetURI = injectWebRtcTrackersIntoMagnet(current.magnetURI);
    lastMagnetUri = current.magnetURI;
  } else if (current.infoHash) {
    current.magnetURI = buildMagnetFromHash(current.infoHash, current.name, defaults);
    lastMagnetUri = current.magnetURI;
  }
  current.private = current.private === true ? true : false;
  return added.length;
}

function applyTorrentioFilters(streams) {
  const lang = $('#torrentioLang')?.value || $('#torrentioLangFilter')?.value || 'all';
  const filterLang = $('#torrentioLangFilter')?.value || lang;
  const webrtcMode = $('#torrentioWebrtcFilter')?.value || 'all';
  return streams.filter(item => {
    if (filterLang !== 'all') {
      const detected = detectStreamLanguage(item.title || item.name || '');
      if (filterLang === 'multi') {
        if (!(detected === 'multi' || /dual|multi/i.test(item.title || ''))) return false;
      } else if (detected !== filterLang) {
        return false;
      }
    }
    if (webrtcMode === 'webrtc' && !streamHasWebRtcTrackers(item)) return false;
    if (webrtcMode === 'no-webrtc' && streamHasWebRtcTrackers(item)) return false;
    return true;
  });
}

function renderTorrentioResults(streams) {
  torrentioStreamsCache = Array.isArray(streams) ? streams : [];
  const host = $('#torrentioResults');
  const toolbar = $('#torrentioToolbar');
  const countEl = $('#torrentioCount');
  const langFilter = $('#torrentioLangFilter');

  // Preenche opções de idioma presentes nos resultados
  if (langFilter) {
    const present = new Set(torrentioStreamsCache.map(s => detectStreamLanguage(s.title || '')));
    const current = langFilter.value || 'all';
    const preferred = $('#torrentioLang')?.value || 'all';
    langFilter.innerHTML = '<option value="all">Idioma: todos</option>' +
      [...present].sort().map(code => `<option value="${code}">${LANG_LABELS[code] || code}</option>`).join('');
    langFilter.value = present.has(preferred) ? preferred : (present.has(current) ? current : 'all');
  }

  const filtered = applyTorrentioFilters(torrentioStreamsCache);
  if (toolbar) toolbar.hidden = torrentioStreamsCache.length === 0;
  if (countEl) countEl.textContent = `${filtered.length} de ${torrentioStreamsCache.length} resultado(s)`;

  if (!filtered.length) {
    host.innerHTML = '<p class="muted small torrentio-empty">Nenhum stream com os filtros atuais. Ajuste o idioma ou busque de novo.</p>';
    return;
  }

  host.innerHTML = filtered.map((item, index) => {
    const lang = detectStreamLanguage(item.title || '');
    const hasWss = streamHasWebRtcTrackers(item);
    return `<article class="torrentio-result ${hasWss ? 'has-webrtc' : ''}" role="listitem">
      <div class="torrentio-result-head">
        <strong>${esc(item.title || 'Stream')}</strong>
        <span class="pill">${item.infoHash ? 'Torrent' : 'HTTP'}</span>
      </div>
      <div class="torrentio-meta">
        <span class="pill">${esc(LANG_LABELS[lang] || lang)}</span>
        <span class="pill ${hasWss ? 'webrtc-yes' : 'webrtc-no'}">${hasWss ? 'WebRTC WSS' : 'Sem WSS'}</span>
        ${item.infoHash ? `<span class="torrentio-hash" title="${esc(item.infoHash)}">${esc(item.infoHash.slice(0, 12))}…</span>` : ''}
      </div>
      <div class="torrentio-actions">
        ${item.magnet
          ? `<button type="button" data-torrentio-use="${index}">Reproduzir</button>
             <button type="button" class="secondary" data-torrentio-copy="${index}">Copiar magnet</button>`
          : `<a class="torrentio-external" href="${esc(item.url)}" target="_blank" rel="noopener noreferrer">Abrir link</a>`}
      </div>
    </article>`;
  }).join('');

  host.querySelectorAll('[data-torrentio-use]').forEach(button => button.addEventListener('click', async () => {
    const item = filtered[Number(button.dataset.torrentioUse)];
    if (!item?.magnet) return;
    button.disabled = true;
    button.textContent = 'Injetando trackers…';
    const magnetWithWss = injectWebRtcTrackersIntoMagnet(item.magnet);
    $('#magnet').value = magnetWithWss;
    torrentFileObject = null;
    torrentFileBuffer = null;
    lastMagnetUri = magnetWithWss;
    const nameEl = $('#torrentFileName');
    if (nameEl) nameEl.textContent = 'Toque para escolher ou arraste o arquivo aqui';
    try { $('#torrentFile').value = ''; } catch {}
    setAddFeedback('loading', 'Carregando magnet com trackers WebRTC…');
    await inspectMagnet();
    // Força trackers WSS no objeto current para o player
    if (current) {
      const plan = getWebRtcTrackerPlan(current.trackers || [], false);
      const injected = plan.announce.length ? plan.announce : ['wss://tracker.btorrent.xyz', 'wss://tracker.fastcast.nz', 'wss://tracker.openwebtorrent.com'];
      const have = new Set((current.trackers || []).map(t => (typeof t === 'string' ? t : t?.url)));
      for (const url of injected) {
        if (!have.has(url)) {
          current.trackers = [...(current.trackers || []), { url, type: 'websocket', injected: true }];
          have.add(url);
        }
      }
      current.private = false;
      current.magnetURI = magnetWithWss;
      lastMagnetUri = magnetWithWss;
    }
    ensureMaxTrackersOnCurrent();
    setAddFeedback('ok', 'Magnet pronto com trackers WebRTC embutidos. Abrindo player…');
    status('Magnet Torrentio carregado com trackers WSS. Conecte no Player.');
    activateTab('player');
    $('#connect').disabled = false;
    button.disabled = false;
    button.textContent = 'Reproduzir';
  }));

  host.querySelectorAll('[data-torrentio-copy]').forEach(button => button.addEventListener('click', async () => {
    const item = filtered[Number(button.dataset.torrentioCopy)];
    const magnet = injectWebRtcTrackersIntoMagnet(item.magnet);
    try { await navigator.clipboard.writeText(magnet); button.textContent = 'Copiado'; } catch { button.textContent = 'Falha'; }
  }));
}

$('#torrentioLangFilter')?.addEventListener('change', () => renderTorrentioResults(torrentioStreamsCache));


let torrentioManifestCache = null;
async function ensureTorrentioManifest() {
 if (torrentioManifestCache) return torrentioManifestCache;
 const response = await fetch('/api/stremio/manifest');
 const manifest = await readApiResponse(response);
 if (!Array.isArray(manifest.resources)) throw new Error('Manifesto Torrentio sem recursos reconhecidos.');
 const streamResource = manifest.resources.find(resource => resource === 'stream' || resource?.name === 'stream');
 const types = typeof streamResource === 'object' && Array.isArray(streamResource.types) ? streamResource.types : manifest.types || [];
 torrentioManifestCache = { ...manifest, streamTypes: types };
 const select = $('#torrentioType');
 const available = types.filter(type => ['movie', 'series', 'anime'].includes(type));
 if (available.length) {
  const previous = select.value;
  select.innerHTML = available.map(type => `<option value="${esc(type)}">${type === 'movie' ? 'Filme' : type === 'series' ? 'Série' : 'Anime'}</option>`).join('');
  if (available.includes(previous)) select.value = previous;
 }
 return torrentioManifestCache;
}

$('#torrentioSearch').addEventListener('click', async () => {
 const type = $('#torrentioType').value;
 let id = $('#torrentioId').value.trim();
 if (!id) { $('#torrentioStatus').textContent = 'Informe um ID IMDb ou Kitsu.'; return; }
 // Séries/anime: anexa temporada:episódio se preenchidos (formato Stremio tt…:S:E)
 if (type === 'series' || type === 'anime') {
  const season = $('#torrentioSeason')?.value?.trim();
  const episode = $('#torrentioEpisode')?.value?.trim();
  // Remove sufixo antigo se o usuário já digitou
  id = id.replace(/(:\d+){1,2}$/, '');
  if (season && episode) id = `${id}:${Number(season)}:${Number(episode)}`;
  else if (season) id = `${id}:${Number(season)}:1`;
 }
 const button = $('#torrentioSearch');
 button.disabled = true; button.textContent = 'Consultando…';
 $('#torrentioStatus').textContent = 'Validando manifesto e consultando Torrentio…';
 $('#torrentioResults').innerHTML = '<div class="torrentio-loading">Buscando streams…</div>';
 try {
  await ensureTorrentioManifest();
  const response = await fetch(`/api/stremio/stream/${encodeURIComponent(type)}/${encodeURIComponent(id)}`);
  const data = await readApiResponse(response);
  // Preferência de idioma do formulário principal
  const preferred = $('#torrentioLang')?.value || 'all';
  if ($('#torrentioLangFilter')) $('#torrentioLangFilter').value = preferred;
  renderTorrentioResults(data.streams || []);
  const n = (data.streams || []).length;
  $('#torrentioStatus').textContent = data.error || `${n} stream(s) recebidos do Torrentio${preferred !== 'all' ? ' · filtro de idioma ativo' : ''}.`;
 } catch (error) {
  $('#torrentioStatus').textContent = `Falha na consulta: ${error.message}`;
  $('#torrentioResults').innerHTML = '';
  const toolbar = $('#torrentioToolbar'); if (toolbar) toolbar.hidden = true;
 } finally {
  button.disabled = false; button.textContent = 'Buscar streams';
 }
});

function syncSeriesFields() {
  const type = $('#torrentioType')?.value;
  const show = type === 'series' || type === 'anime';
  ['torrentioSeasonWrap', 'torrentioEpisodeWrap'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.hidden = !show;
  });
}
$('#torrentioType')?.addEventListener('change', syncSeriesFields);
syncSeriesFields();

$('#torrentioId').addEventListener('keydown', event => { if (event.key === 'Enter') $('#torrentioSearch').click(); });

async function initializeStreamingServer() {
 if (!('serviceWorker' in navigator)) throw new Error('Este navegador não oferece suporte a Service Worker. Abra o app no Chrome atualizado usando HTTPS.');
 if (location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') throw new Error('O streaming WebTorrent exige HTTPS ou localhost.');
 if (streamServerReady && serviceWorkerRegistration?.active?.state === 'activated') return serviceWorkerRegistration;

 // Use URLs absolutas a partir da pasta publicada. Isso evita registrar o worker
 // em um caminho relativo incorreto quando a aplicação é aberta em uma rota.
 const appBase = new URL('./', location.href);
 const workerUrl = new URL('sw.min.js', appBase);
 const scope = appBase.pathname;
 let response;
 try {
  response = await fetch(workerUrl.href, { cache: 'no-store' });
 } catch (e) {
  throw new Error(`Não foi possível acessar ${workerUrl.pathname}: ${e.message}. Verifique se sw.min.js foi publicado em client/public.`);
 }
 if (!response.ok) throw new Error(`O arquivo do Service Worker não foi publicado: ${workerUrl.pathname} retornou HTTP ${response.status}.`);
 const workerSource = await response.clone().text();
 if (!workerSource || /<\s*!doctype|<\s*html/i.test(workerSource.slice(0, 300))) throw new Error(`A rota ${workerUrl.pathname} retornou HTML em vez do JavaScript sw.min.js. Confira o build/deploy da Vercel.`);

 try {
  serviceWorkerRegistration = await navigator.serviceWorker.register(workerUrl.href, { scope, updateViaCache: 'none' });
  // ready pode resolver com a registration controladora da página; preserve a
  // registration explicitamente retornada pelo register quando possível.
  const readyRegistration = await navigator.serviceWorker.ready;
  if (!serviceWorkerRegistration.active && readyRegistration?.scope === serviceWorkerRegistration.scope) serviceWorkerRegistration = readyRegistration;
 } catch (e) {
  throw new Error(`Falha ao registrar ${workerUrl.pathname}: ${e.message}`);
 }

 let worker = serviceWorkerRegistration.active || serviceWorkerRegistration.waiting || serviceWorkerRegistration.installing;
 if (worker && worker.state !== 'activated') {
  await new Promise((resolve, reject) => {
   const timeout = setTimeout(() => reject(new Error(`O worker ficou em estado "${worker.state}" após 20 segundos. Verifique se outra versão antiga está controlando a página e recarregue o site.`)), 20000);
   const check = () => {
    if (worker.state === 'activated') { clearTimeout(timeout); resolve(); }
    else if (worker.state === 'redundant') { clearTimeout(timeout); reject(new Error('O navegador marcou sw.min.js como redundante. Limpe os dados do site e publique novamente o arquivo.')); }
   };
   worker.addEventListener('statechange', check);
   check();
  });
 }
 worker = serviceWorkerRegistration.active;
 if (!worker || worker.state !== 'activated') {
  const states = `active=${serviceWorkerRegistration.active?.state || 'ausente'}, waiting=${serviceWorkerRegistration.waiting?.state || 'ausente'}, installing=${serviceWorkerRegistration.installing?.state || 'ausente'}`;
  throw new Error(`Service Worker não ativado (${states}). Arquivo: ${workerUrl.pathname}; escopo: ${scope}.`);
 }
 streamServerReady = true;
 return serviceWorkerRegistration;
}

function updateAdaptivePriorities(torrent, file, video) {
 if (!torrent || !file || !Number.isFinite(video.duration) || video.duration <= 0 || !torrent.pieceLength) return null;
 const bufferAhead = getBufferAhead(video);
 const window = getAdaptiveWindow({
  bufferAhead,
  downloadSpeed: torrent.downloadSpeed || 0,
  fileLength: file.length || 0,
  duration: video.duration,
  currentTime: video.currentTime || 0,
  paused: video.paused
 });
 const fileOffset = Number.isFinite(file.offset) ? file.offset : torrent.files.slice(0, torrent.files.indexOf(file)).reduce((n, f) => n + (f.length || 0), 0);
 const range = getPieceRange({
  fileOffset,
  fileLength: file.length || 0,
  pieceLength: torrent.pieceLength,
  startSeconds: window.startSeconds,
  endSeconds: window.endSeconds,
  duration: video.duration
 });
 const now = Date.now();
 const shouldReselect = range && (!lastAdaptiveWindow || Math.abs(range.start - lastAdaptiveWindow.start) >= 4 || Math.abs(range.end - lastAdaptiveWindow.end) >= 4 || now - lastAdaptiveWindow.at >= 10000);
 if (shouldReselect) {
  try {
   // Atualiza a janela no máximo a cada 10 s ou quando ela avança 4 peças.
   // Isso evita criar seleções redundantes a cada amostra de telemetria.
   torrent.select(range.start, range.end, 5);
   lastAdaptiveWindow = { ...range, at: now };
  } catch (e) { /* versões diferentes podem limitar ajustes dinâmicos */ }
 }
 if (range) {
  const critical = Math.max(range.start, Math.min(range.end, Math.floor((fileOffset + (window.currentBytes || 0)) / torrent.pieceLength))); 
  if (critical !== lastCriticalPiece) {
   try { torrent.critical(critical, Math.min(range.end, critical + 1)); lastCriticalPiece = critical; } catch (e) {}
  }
 }
 return { bufferAhead, targetBuffer: window.targetBuffer, mode: window.mode, window: range };
}

function renderPeerDetails(wires, peerRates = new Map()) {
 const target = $('#peerDetails'); if (!target) return;
 const peers = wires.map((wire,index)=>{const id=String(wire.peerId||wire.remoteAddress||`peer-${index+1}`);const rate=peerRates.get(id)||{};return {id,downloadSpeed:rate.downloadSpeed||0,uploadSpeed:rate.uploadSpeed||0};}).sort((a,b)=>b.downloadSpeed-a.downloadSpeed);
 const active = peers.filter(peer=>peer.downloadSpeed>0);
 const average = active.length ? active.reduce((sum,peer)=>sum+peer.downloadSpeed,0)/active.length : 0;
 const rows = peers.slice(0,8).map(peer => `<div class="peer-row"><span class="peer-id" title="${esc(peer.id)}">${esc(peer.id)}</span><span>${formatRate(peer.downloadSpeed)} ↓</span><span>${formatRate(peer.uploadSpeed)} ↑</span></div>`).join('');
 const nextHtml = rows || '<span class="muted small">Nenhum peer WebRTC conectado neste momento.</span>';
 if (target.innerHTML !== nextHtml) target.innerHTML = nextHtml;
 const avg = $('#peerAvgSpeedValue'); if (avg) avg.textContent = formatRate(average);
}

function bindPlaybackDiagnostics(video) {
 if (playbackEventsBound) return;
 playbackEventsBound = true;
 video.addEventListener('loadedmetadata', () => peerStatus(`Fonte de streaming conectada. Duração: ${Number.isFinite(video.duration) ? Math.round(video.duration) + ' s' : 'desconhecida'}. Pressione reproduzir se o navegador não iniciar automaticamente.`));
 video.addEventListener('canplay', () => peerStatus('Vídeo recebeu dados suficientes para iniciar. Toque em reproduzir.'));
 let playedSeconds = 0;
 let lastPlaybackTime = null;
 let savedHash = null;
 let savingHash = null;
 video.addEventListener('playing', () => {
  const hash = activeTorrent?.infoHash || null;
  if (hash && savedHash !== hash && savingHash !== hash) playedSeconds = 0;
  lastPlaybackTime = video.currentTime;
  peerStatus('REPRODUZINDO — dados recebidos progressivamente pelo WebTorrent.');
 });
 video.addEventListener('timeupdate', async () => {
  const torrent = activeTorrent;
  if (!torrent || !selectedVideoFile || video.paused || lastPlaybackTime == null) return;
  const delta = video.currentTime - lastPlaybackTime;
  lastPlaybackTime = video.currentTime;
  // Ignora seeks e saltos do relógio; soma somente tempo efetivamente reproduzido.
  if (delta > 0 && delta <= 2) playedSeconds += delta;
  const hash = torrent.infoHash;
  if (playedSeconds < 10 || savedHash === hash || savingHash === hash) return;
  savingHash = hash;
  const item = {
   infoHash: hash, name: torrent.name,
   magnetURI: torrent.magnetURI || lastMagnetUri || resolved?.magnet || (resolved?.kind === 'magnet' ? resolved.value : null) || `magnet:?xt=urn:btih:${hash}&dn=${encodeURIComponent(torrent.name || 'Torrent')}${(torrent.announce || []).map(url => `&tr=${encodeURIComponent(url)}`).join('')}`,
   fileName: selectedVideoFile.name, fileLength: selectedVideoFile.length,
   totalLength: torrent.length,
   files: torrent.files.map(file => ({ name: file.name, length: file.length }))
  };
  try {
   const response = await fetch('/api/catalog/played', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(item) });
   const result = await readApiResponse(response);
   savedHash = hash;
   peerStatus(`Reprodução confirmada e salva na biblioteca Upstash Redis: ${result.item.name}.`);
   if ($('#view-search').classList.contains('active')) searchCatalog();
  } catch (error) {
   peerStatus(`Vídeo reproduzido, mas não foi possível salvar na biblioteca em nuvem: ${error.message}`);
  } finally { savingHash = null; }
 });
 video.addEventListener('waiting', () => { lastPlaybackTime = null; peerStatus('Buffer aguardando novos blocos do swarm…'); });
 video.addEventListener('stalled', () => peerStatus('O navegador parou de receber dados temporariamente. Verifique peers e velocidade.'));
 video.addEventListener('seeking', () => { lastCriticalPiece = -1; lastAdaptiveWindow = null; lastPlaybackTime = null; });
 video.addEventListener('seeked', () => { if (!video.paused) lastPlaybackTime = video.currentTime; });
 video.addEventListener('error', () => {
  const e = video.error;
  const messages = {1:'reprodução cancelada',2:'falha de rede ao buscar os blocos',3:'erro ao decodificar o vídeo ou codec incompatível',4:'formato ou MIME não suportado pelo navegador'};
  peerStatus(`Falha no elemento de vídeo: ${messages[e?.code] || 'erro desconhecido'} (código ${e?.code || '—'}).`);
 });
}


// ——— Tradutor SRT → PT-BR em tempo real (somente durante reprodução) ———
function updateTranslatorUi({ badge, lang, mode, rate, label, percent, preview } = {}) {
  if (badge != null) { const el = $('#translatorBadge'); if (el) el.textContent = badge; }
  if (lang != null) { const el = $('#detectedLangInfo'); if (el) el.textContent = lang; }
  if (mode != null) { const el = $('#translationSyncMode'); if (el) el.textContent = mode; }
  if (rate != null) { const el = $('#translationRateInfo'); if (el) el.textContent = rate; }
  if (label != null) { const el = $('#translationProgressLabel'); if (el) el.textContent = label; }
  if (percent != null) {
    const p = $('#translationPercentLabel'); if (p) p.textContent = `${percent}%`;
    const bar = $('#translationProgressBar'); if (bar) bar.style.width = `${Math.max(0, Math.min(100, percent))}%`;
  }
  if (preview != null) { const el = $('#liveTranslatedCuePreview'); if (el) el.textContent = `"${preview}"`; }
}

function ensureSubtitleTranslator() {
  const video = $('#preview');
  const track = $('#ptbrTrack');
  if (!video || !track) return null;
  if (subtitleTranslator) return subtitleTranslator;
  subtitleTranslator = createRealtimeSubtitleTranslator({
    video,
    trackElement: track,
    getDownloadSpeed: () => activeTorrent?.downloadSpeed || 0,
    onStatus: (msg) => updateTranslatorUi({ badge: msg }),
    onProgress: (data) => updateTranslatorUi({
      badge: data.percent >= 100 ? 'PT-BR pronto' : 'Traduzindo ao vivo…',
      lang: data.language,
      mode: data.mode,
      rate: `${(data.rate || 0).toFixed(1)} frases/s`,
      label: `Frases traduzidas: ${data.completed} / ${data.total}`,
      percent: data.percent
    }),
    onPreview: (text) => updateTranslatorUi({ preview: text })
  });
  return subtitleTranslator;
}

async function startTranslationFromText(raw, fileName) {
  const video = $('#preview');
  if (!video || video.hidden) {
    updateTranslatorUi({ badge: 'Inicie a reprodução antes', preview: 'Conecte e reproduza o vídeo, depois carregue o SRT.' });
    return;
  }
  const tr = ensureSubtitleTranslator();
  if (!tr) return;
  updateTranslatorUi({ badge: 'Analisando SRT…', percent: 0, label: 'Frases traduzidas: 0 / 0' });
  video.hidden = false;
  try {
    // mostra track
    if (video.textTracks?.length) video.textTracks[0].mode = 'showing';
  } catch {}
  await tr.startFromSrtText(raw, fileName);
}

async function handleLocalSrtFile(file) {
  if (!file) return;
  const nameEl = $('#srtFileLabel');
  if (nameEl) nameEl.textContent = file.name;
  const text = await file.text();
  await startTranslationFromText(text, file.name);
}

$('#srtFileInput')?.addEventListener('change', async (e) => {
  const file = e.target.files?.[0];
  if (file) await handleLocalSrtFile(file);
});

function listSrtFilesFromTorrent(torrent) {
  const host = $('#srtTorrentList');
  const btn = $('#srtFromTorrent');
  if (!host) return;
  if (!torrent?.files?.length) {
    host.innerHTML = '';
    if (btn) btn.disabled = true;
    return;
  }
  const srts = torrent.files
    .map((f, index) => ({ f, index }))
    .filter(({ f }) => /\.(srt|vtt)$/i.test(f.name));
  if (!srts.length) {
    host.innerHTML = '<span class="muted small">Nenhum .srt/.vtt encontrado neste torrent.</span>';
    if (btn) btn.disabled = true;
    return;
  }
  if (btn) btn.disabled = false;
  host.innerHTML = srts.map(({ f, index }) =>
    `<button type="button" class="secondary srt-pick" data-srt-index="${index}">${esc(f.name)}</button>`
  ).join(' ');
  host.querySelectorAll('[data-srt-index]').forEach(button => {
    button.addEventListener('click', async () => {
      const idx = Number(button.dataset.srtIndex);
      const file = torrent.files[idx];
      if (!file) return;
      button.disabled = true;
      button.textContent = 'Baixando legenda…';
      updateTranslatorUi({ badge: 'Baixando SRT do swarm…' });
      try {
        // Prioriza o arquivo de legenda
        try { file.select?.(); } catch {}
        const blob = await new Promise((resolve, reject) => {
          if (typeof file.blob === 'function') {
            file.blob((err, b) => err ? reject(err) : resolve(b));
          } else if (typeof file.getBlob === 'function') {
            file.getBlob((err, b) => err ? reject(err) : resolve(b));
          } else {
            reject(new Error('API de blob indisponível neste WebTorrent'));
          }
        });
        const text = await blob.text();
        await startTranslationFromText(text, file.name.split('/').pop());
      } catch (err) {
        updateTranslatorUi({ badge: 'Falha ao ler SRT', preview: err.message });
      } finally {
        button.disabled = false;
        button.textContent = file.name.split('/').pop();
      }
    });
  });
}

$('#srtFromTorrent')?.addEventListener('click', () => {
  if (activeTorrent) listSrtFilesFromTorrent(activeTorrent);
});


$('#connect').addEventListener('click', async () => {
 if(!current) return;
 resetTelemetry();
 window.__sessionStartedAt = Date.now();
 const video = $('#preview');
 if(activeClient) { stopRealtimeTelemetry(); try { subtitleTranslator?.stop?.(); } catch {} try { await activeClient.destroy(); } catch {} activeClient = null; activeTorrent = null; }
 video.pause(); video.removeAttribute('src'); video.load(); video.hidden = true;
 peerStatus('Preparando Service Worker e servidor de streaming WebTorrent…');
 const resolved = resolvePlayableSource();
 if(!resolved) return peerStatus('A origem do torrent não está mais disponível. Analise um magnet/hash ou reenvie o arquivo .torrent.');
 // Sempre injeta trackers WebRTC WSS ao reproduzir (exceto torrent privado confirmado).
 const trackerPlan = getWebRtcTrackerPlan(current.trackers || [], current.private === true ? true : false);
 // Mescla trackers existentes WSS + defaults
 const defaults = ['wss://tracker.btorrent.xyz', 'wss://tracker.fastcast.nz', 'wss://tracker.openwebtorrent.com', 'wss://tracker.webtorrent.dev'];
 const wss = current.private === true
  ? trackerPlan.announce
  : [...new Set([...(trackerPlan.announce || []), ...defaults])];
 if (current.private !== true) trackerPlan.injected = true;
 if (trackerPlan.injected) {
  current.trackers = [...(current.trackers || []), ...wss.map(url => ({ url, type: 'websocket', injected: true }))];
  const list = $('#trackers');
  if (list) list.innerHTML = `<h2>Trackers detectados</h2>${current.trackers.map(t=>`<div class="tracker"><span class="pill">${esc(t.injected ? 'WSS automático' : t.type || 'tracker')}</span> ${esc(t.url)}</div>`).join('')}<p class="muted small">Trackers WebRTC WSS adicionados automaticamente porque o torrent público não continha trackers.</p>`;
  status('Trackers WebRTC WSS adicionados automaticamente. Iniciando conexão…');
 } else if (trackerPlan.reason === 'private') {
  peerStatus('Torrent marcado como privado: não foram adicionados trackers públicos para preservar a privacidade.');
 } else if (trackerPlan.reason === 'privacy-unknown') {
  peerStatus('Não foi possível confirmar se o magnet é público ou privado. Como já contém trackers não-WSS, trackers públicos extras não foram injetados para evitar exposição do infoHash.');
 }
 try {
  const WebTorrent = await loadWebTorrent();
  const controller = await initializeStreamingServer();
  activeClient = new WebTorrent(); activeTorrent = null;
  activeClient.on('error', e => peerStatus(`Erro do cliente WebTorrent: ${e.message || e}`));
  // streamTo() só funciona depois de createServer({ controller }) no navegador.
  activeClient.createServer({ controller });
  peerStatus(`Servidor de streaming inicializado. Trackers WebRTC WSS: ${wss.length}${trackerPlan.injected ? ' (adicionados automaticamente)' : ''}. Aguardando metadados e peers WebRTC…`);
  const maxConns = chooseConnectionLimit({ mobile: matchMedia('(max-width: 680px)').matches, hardwareConcurrency: navigator.hardwareConcurrency || 4, deviceMemory: navigator.deviceMemory || 4 });
  const addOpts = { ...(wss.length ? { announce: wss } : {}), strategy: 'sequential', maxConns };
  // kind: file | buffer | infoHash | magnet
  let addSource = resolved.value;
  if (resolved.kind === 'buffer' && addSource instanceof Uint8Array) {
    // WebTorrent/parse-torrent no browser aceita Uint8Array do metainfo
    addSource = addSource;
  }
  const sourceKind = resolved.kind === 'file' ? `arquivo .torrent (${resolved.value.size} bytes)`
    : resolved.kind === 'buffer' ? `metainfo (${resolved.value.byteLength} bytes)`
    : resolved.kind === 'infoHash' ? `infoHash ${resolved.value.slice(0, 8)}…`
    : resolved.kind === 'magnet' ? 'magnet sanitizado'
    : resolved.kind;
  peerStatus(`Adicionando torrent (${sourceKind})…`);

  const onTorrentReady = (torrent) => {
   const videos = torrent.files.filter(f=>videoExt.test(f.name)).sort((a,b)=>b.length-a.length);
   const chosen = videos[0];
   selectedVideoFile = chosen || null; lastCriticalPiece = -1; lastAdaptiveWindow = null;
   if (!chosen) { peerStatus(`Metadados recebidos, mas nenhum arquivo com extensão de vídeo reconhecida foi encontrado. Arquivos: ${torrent.files.map(f=>f.name).join(', ')}`); return; }
   video.hidden = false;
   bindPlaybackDiagnostics(video);
   try {
    chosen.streamTo(video);
    video.load();
    peerStatus(`Streaming configurado para: ${chosen.name}. Aguardando os primeiros blocos e peers WebRTC…`);
   listSrtFilesFromTorrent(torrent);
   const srtBtn = $('#srtFromTorrent'); if (srtBtn) srtBtn.disabled = false;
    video.play().catch(() => peerStatus('O streaming foi configurado. Toque no botão ▶ do vídeo para iniciar; o navegador bloqueou o autoplay.'));
   } catch(err) { peerStatus(`Arquivo encontrado, mas falha ao configurar streamTo: ${err.message}`); }
   const setMetric = (id, value) => { const el = $('#'+id); if (el && el.textContent !== String(value)) el.textContent = String(value); };
   let lastChartPush = 0;
   let lastPeerRender = 0;
   let frameCount = 0;

   const tickTelemetry = (reason = 'raf') => {
    if (!activeTorrent || activeTorrent !== torrent) return;
    const now = (typeof performance !== 'undefined' ? performance.now() : Date.now());
    const wires = (torrent.wires || []).filter(wire => !wire.type || wire.type === 'webrtc');
    const peers = wires.length;
    const rates = telemetrySampler(torrent, wires, now);

    // Velocidades reais do swarm (delta de bytes) + fallback WT
    const downBps = Math.max(rates.downloadSpeed, Number(torrent.downloadSpeed) || 0);
    const upBps = Math.max(rates.uploadSpeed, Number(torrent.uploadSpeed) || 0);
    const downSmooth = rates.downloadSpeedSmooth ?? downBps;
    const upSmooth = rates.uploadSpeedSmooth ?? upBps;

    const mediaBuffer = getPlaybackBuffer(video);
    const downloadedBuffer = getDownloadedBufferAhead(torrent, chosen, video);
    const bufferAhead = downloadedBuffer.valid ? downloadedBuffer.ahead : (mediaBuffer.valid ? mediaBuffer.ahead : null);
    const adaptive = updateAdaptivePriorities(torrent, chosen, video);

    // Métricas numéricas — a cada frame
    setMetric('peerStateValue', peers ? 'Conectado ao swarm' : 'Procurando peers');
    setMetric('peerCountValue', peers);
    setMetric('uploadedValue', pretty(torrent.uploaded || 0));
    setMetric('downloadedValue', pretty(torrent.downloaded || 0));
    setMetric('progressValue', `${((torrent.progress || 0) * 100).toFixed(1)}%`);
    setMetric('progressValueHero', `${((torrent.progress || 0) * 100).toFixed(1)}%`);
    setMetric('uploadSpeedValue', formatRate(upSmooth || upBps));
    setMetric('downloadSpeedValue', formatRate(downSmooth || downBps));

    setMetric('bufferStateValue', `${downloadedBuffer.state || '—'} · MSE: ${mediaBuffer.valid ? mediaBuffer.ahead.toFixed(1) + ' s' : '—'}`);
    setMetric('bufferAheadValue', Number.isFinite(bufferAhead) ? `${bufferAhead.toFixed(1)} s` : '—');
    const gauge = $('#bufferGauge');
    const bufferScale = adaptive?.targetBuffer || 60;
    if (gauge) gauge.style.width = Number.isFinite(bufferAhead) ? `${Math.max(0, Math.min(100, (bufferAhead / bufferScale) * 100))}%` : '0%';
    setMetric('bufferBarLabel', Number.isFinite(bufferAhead) && adaptive?.targetBuffer
      ? `${Math.min(100, Math.round((bufferAhead / adaptive.targetBuffer) * 100))}% da meta`
      : '—');

    const activeRates = [...rates.peers.values()].map(peer => peer.downloadSpeed).filter(rate => rate > 0);
    setMetric('peerAvgSpeedValue', formatRate(activeRates.length ? activeRates.reduce((sum, rate) => sum + rate, 0) / activeRates.length : 0));
    if (adaptive) {
      setMetric('bufferModeValue', adaptive.mode);
      setMetric('bufferTargetValue', `${adaptive.targetBuffer} s`);
    }

    const down = torrent.downloaded || 0;
    const up = torrent.uploaded || 0;
    setMetric('ratioValue', down > 0 ? (up / down).toFixed(2) : (up > 0 ? '∞' : '—'));
    if (!window.__sessionStartedAt) window.__sessionStartedAt = Date.now();
    const elapsedMs = Math.max(0, Date.now() - window.__sessionStartedAt);
    const mm = String(Math.floor(elapsedMs / 60000)).padStart(2, '0');
    const ss = String(Math.floor((elapsedMs % 60000) / 1000)).padStart(2, '0');
    const ms = String(elapsedMs % 1000).padStart(3, '0');
    setMetric('sessionTimeValue', `${mm}:${ss}.${ms}`);

    // Gauges a cada frame (ponteiro fluido)
    drawTelemetryGauges(downSmooth || downBps, upSmooth || upBps, bufferAhead || 0, adaptive?.targetBuffer || 60);

    // Saúde
    const health = $('#sessionHealth');
    if (health) {
      let label = 'IDLE', cls = 'health-idle';
      if (peers > 0 && downBps > 50 * 1024) { label = 'EXCELENTE'; cls = 'health-good'; }
      else if (peers > 0 && downBps > 0) { label = 'ATIVO'; cls = 'health-ok'; }
      else if (peers > 0) { label = 'CONECTADO'; cls = 'health-warn'; }
      else if (torrent.numPeers != null) { label = 'BUSCANDO'; cls = 'health-warn'; }
      health.textContent = label;
      health.className = `health-badge ${cls}`;
      const healthHero = $('#healthValueHero');
      if (healthHero) healthHero.textContent = label;
    }

    // Gráfico: 1 ponto/s para não saturar
    if (now - lastChartPush >= 1000) {
      lastChartPush = now;
      pushTelemetry(downBps, upBps, peers, bufferAhead, Date.now());
    }

    // Lista de peers: no máx. ~4x/s
    if (now - lastPeerRender >= 250) {
      lastPeerRender = now;
      renderPeerDetails(wires, rates.peers);
    }

    frameCount += 1;
    const stamp = $('#telemetryUpdated');
    if (stamp) {
      const wall = new Date();
      stamp.textContent = `Ao vivo · ${wall.toLocaleTimeString()}.${String(wall.getMilliseconds()).padStart(3, '0')} · frame ${frameCount} · ${reason}`;
    }
   };

   const startRealtimeTelemetry = () => {
    stopRealtimeTelemetry();
    telemetryRunning = true;
    telemetrySampler = createTelemetrySampler();
    lastChartPush = 0;
    lastPeerRender = 0;
    frameCount = 0;

    const loop = () => {
      if (!telemetryRunning || activeTorrent !== torrent) return;
      tickTelemetry('raf');
      telemetryRaf = requestAnimationFrame(loop);
    };
    telemetryRaf = requestAnimationFrame(loop);

    // Eventos do swarm forçam tick imediato com dados reais
    const onSwarm = () => tickTelemetry('swarm');
    torrent.on('download', onSwarm);
    torrent.on('upload', onSwarm);
    torrent.on('done', onSwarm);
    torrent.on('wire', wire => {
      tickTelemetry('wire');
      try {
        wire.on?.('download', onSwarm);
        wire.on?.('upload', onSwarm);
        wire.on?.('close', onSwarm);
      } catch {}
    });
    // Peers já conectados
    for (const wire of (torrent.wires || [])) {
      try {
        wire.on?.('download', onSwarm);
        wire.on?.('upload', onSwarm);
        wire.on?.('close', onSwarm);
      } catch {}
    }

    // Fallback de segurança a cada 250ms (caso rAF pause em aba oculta)
    telemetryTimer = setInterval(() => {
      if (document.hidden) tickTelemetry('interval');
    }, 250);

    tickTelemetry('start');
   };

   startRealtimeTelemetry();
   peerStatus(`Peer WebRTC ativo nesta sessão. Info hash: ${torrent.infoHash}. ID local: ${activeClient?.peerId ? String(activeClient.peerId) : 'inicializando'}. Telemetria em tempo real ligada ao swarm.`);
   torrent.on('warning', e => peerStatus(`Aviso do torrent: ${e.message || e}`));
   torrent.on('noPeers', announceType => {
    tickTelemetry('noPeers');
    if (!(torrent.wires || []).length) {
      peerStatus(`Este navegador já entrou no swarm, mas ainda não encontrou peers WebRTC compatíveis (descoberta: ${announceType || 'tracker'}). O compartilhamento começará assim que outro peer conectar.`);
    }
   });
  };

  // Fallback: se a origem principal falhar, tenta alternativa.
  let fallbackSource = null;
  let fallbackLabel = '';
  if (resolved.kind === 'infoHash' && resolved.magnet) {
    fallbackSource = resolved.magnet;
    fallbackLabel = 'magnet sanitizado';
  } else if (resolved.infoHash && resolved.kind !== 'infoHash') {
    fallbackSource = resolved.infoHash;
    fallbackLabel = `infoHash ${resolved.infoHash.slice(0, 8)}…`;
  } else if (resolved.infoHash) {
    fallbackSource = `magnet:?xt=urn:btih:${resolved.infoHash}`;
    fallbackLabel = 'magnet mínimo';
  } else if (lastMagnetUri) {
    fallbackSource = lastMagnetUri;
    fallbackLabel = 'último magnet analisado';
  }

  let addAttempts = 0;
  const tryAdd = (payload, label) => {
    addAttempts += 1;
    peerStatus(`Adicionando torrent (${label})…`);
    const t = activeClient.add(payload, addOpts, onTorrentReady);
    t.on('error', e => {
      const msg = e?.message || String(e);
      if (/invalid torrent identifier/i.test(msg) && fallbackSource && addAttempts < 3) {
        const next = fallbackSource;
        const nextLabel = fallbackLabel;
        fallbackSource = null; // evita loop
        peerStatus(`Falha com ${label}. Tentando origem alternativa (${nextLabel})…`);
        try { t.destroy(); } catch {}
        activeTorrent = tryAdd(next, nextLabel);
        return;
      }
      if (/invalid torrent identifier/i.test(msg)) {
        peerStatus('Identificador de torrent inválido. Use Analisar origem de novo e confirme o magnet/arquivo. Info hash deve ter 40 caracteres hex.');
      } else {
        peerStatus(`Erro no torrent: ${msg}`);
      }
    });
    return t;
  };

  activeTorrent = tryAdd(addSource, sourceKind);
 } catch(e) {
  const msg = e?.message || String(e);
  if (/invalid torrent identifier/i.test(msg)) {
   peerStatus('Identificador de torrent inválido. Use Analisar origem com magnet ou arquivo .torrent antes de conectar.');
  } else {
   peerStatus(`Não foi possível iniciar reprodução WebTorrent: ${msg}`);
  }
 }
});

async function lookupDhtPeers() {
 const hash = current?.infoHash || ($('#magnet').value.match(/btih:([a-f0-9]{40})/i)?.[1]);
 const statusEl = $('#dhtStatus'), peersEl = $('#dhtPeers');
 if (!hash) { statusEl.textContent = 'Analise primeiro um magnet ou arquivo .torrent para obter o info hash.'; return; }
 statusEl.textContent = 'Consultando DHT do WebTorrent no servidor…'; peersEl.innerHTML = '';
 try {
  const response = await fetch('/api/dht/lookup', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ infoHash:hash, trackers:current?.trackers || [], isPrivate:current?.private }) });
  const data = await readApiResponse(response);
  statusEl.textContent = data.available ? `${data.count} peers BitTorrent encontrados · ${data.elapsedMs || 0} ms · ${data.trackerCount || 0} trackers. Fontes: ${(data.sources || ['DHT']).join(' + ')}. ${data.note || ''}` : (data.note || 'DHT indisponível neste ambiente.');
  peersEl.innerHTML = (data.peers || []).map(peer => `<div class="tracker">${esc(peer.host)}:${Number(peer.port)||0} <span class="pill">TCP/uTP · não WebRTC</span></div>`).join('');
 } catch (error) { statusEl.textContent = `Falha na consulta DHT: ${error.message}`; }
}
$('#dhtLookup')?.addEventListener('click', lookupDhtPeers);


let ytsPage = 1;
let ytsLastQuery = '';

function renderYtsResults(payload) {
  const host = $('#ytsResults');
  const toolbar = $('#ytsToolbar');
  const countEl = $('#ytsCount');
  const movies = payload?.movies || [];
  if (toolbar) toolbar.hidden = false;
  if (countEl) countEl.textContent = `${movies.length} nesta página · ${payload.movieCount || 0} no total`;
  const prev = $('#ytsPrev'); const next = $('#ytsNext');
  if (prev) { prev.hidden = ytsPage <= 1; }
  if (next) { next.hidden = (ytsPage * (payload.limit || 20)) >= (payload.movieCount || 0); }

  if (!movies.length) {
    host.innerHTML = '<div class="catalog-empty">Nenhum filme encontrado na YTS.</div>';
    return;
  }

  host.innerHTML = movies.map((movie, mi) => {
    const torrents = (movie.torrents || []).map((t, ti) => `
      <div class="yts-torrent">
        <div class="yts-torrent-info">
          <span class="pill">${esc(t.quality || '?')}</span>
          <span class="pill webrtc-yes">WebRTC+</span>
          <span class="muted small">${esc(t.size || '')} · 🌱 ${t.seeds ?? '—'} · 👥 ${t.peers ?? '—'}</span>
        </div>
        <div class="yts-torrent-actions">
          <button type="button" data-yts-play="${mi}:${ti}">Reproduzir</button>
          <button type="button" class="secondary" data-yts-copy="${mi}:${ti}">Copiar magnet</button>
        </div>
      </div>`).join('');
    return `<article class="yts-movie catalog-item result" role="listitem">
      <div class="yts-movie-main">
        ${movie.cover ? `<img class="yts-cover" src="${esc(movie.cover)}" alt="" loading="lazy" width="60" height="90">` : ''}
        <div class="yts-movie-body">
          <div class="catalog-item-head"><b>${esc(movie.title)}</b><span class="pill">${movie.rating != null ? '★ ' + movie.rating : 'YTS'}</span></div>
          <div class="muted small">${esc((movie.genres || []).join(' · '))} ${movie.language ? '· ' + esc(movie.language) : ''} ${movie.runtime ? '· ' + movie.runtime + ' min' : ''}</div>
          <div class="muted small yts-summary">${esc((movie.summary || '').slice(0, 160))}${(movie.summary || '').length > 160 ? '…' : ''}</div>
        </div>
      </div>
      <div class="yts-torrents">${torrents || '<span class="muted small">Sem torrents listados.</span>'}</div>
    </article>`;
  }).join('');

  const list = movies;
  host.querySelectorAll('[data-yts-play]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const [mi, ti] = btn.dataset.ytsPlay.split(':').map(Number);
      const t = list[mi]?.torrents?.[ti];
      if (!t?.magnet) return;
      btn.disabled = true; btn.textContent = 'Preparando…';
      const magnet = injectWebRtcTrackersIntoMagnet(t.magnet);
      $('#magnet').value = magnet;
      torrentFileObject = null; torrentFileBuffer = null; lastMagnetUri = magnet;
      setAddFeedback('loading', 'Carregando magnet YTS com trackers embutidos…');
      await inspectMagnet();
      ensureMaxTrackersOnCurrent();
      setAddFeedback('ok', 'Magnet YTS pronto (trackers WSS+UDP embutidos). Abrindo player…');
      activateTab('player');
      $('#connect').disabled = false;
      btn.disabled = false; btn.textContent = 'Reproduzir';
    });
  });
  host.querySelectorAll('[data-yts-copy]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const [mi, ti] = btn.dataset.ytsCopy.split(':').map(Number);
      const t = list[mi]?.torrents?.[ti];
      if (!t?.magnet) return;
      const magnet = injectWebRtcTrackersIntoMagnet(t.magnet);
      try { await navigator.clipboard.writeText(magnet); btn.textContent = 'Copiado'; }
      catch { btn.textContent = 'Falha'; }
    });
  });
}

async function searchYts(page = 1) {
  const q = $('#ytsQuery')?.value?.trim() || '';
  ytsPage = page;
  ytsLastQuery = q;
  const button = $('#ytsSearch');
  if (button) { button.disabled = true; button.textContent = 'Buscando…'; }
  $('#ytsStatus').textContent = 'Consultando movies-api.accel.li…';
  $('#ytsResults').innerHTML = '<div class="catalog-loading">Buscando filmes na YTS…</div>';
  try {
    const params = new URLSearchParams({
      q,
      page: String(page),
      limit: '20',
      sort_by: $('#ytsSort')?.value || 'seeds',
      order_by: 'desc',
      quality: $('#ytsQuality')?.value || '',
      minimum_rating: $('#ytsRating')?.value || '0'
    });
    const response = await fetch(`/api/yts/movies?${params}`);
    const data = await readApiResponse(response);
    renderYtsResults(data);
    $('#ytsStatus').textContent = data.error
      ? data.error
      : `${data.movieCount || 0} filme(s) · página ${data.page || page}. Magnets já incluem trackers WebRTC.`;
  } catch (error) {
    $('#ytsStatus').textContent = `Falha YTS: ${error.message}`;
    $('#ytsResults').innerHTML = '';
    const tb = $('#ytsToolbar'); if (tb) tb.hidden = true;
  } finally {
    if (button) { button.disabled = false; button.textContent = 'Buscar YTS'; }
  }
}

$('#ytsSearch')?.addEventListener('click', () => searchYts(1));
$('#ytsQuery')?.addEventListener('keydown', e => { if (e.key === 'Enter') searchYts(1); });
$('#ytsPrev')?.addEventListener('click', () => { if (ytsPage > 1) searchYts(ytsPage - 1); });
$('#ytsNext')?.addEventListener('click', () => searchYts(ytsPage + 1));

async function searchCatalog(){
 const q=encodeURIComponent($('#search').value.trim());
 const target=$('#catalog');
 target.classList.add('catalog-scroll');
 target.innerHTML='<div class="catalog-loading">Consultando biblioteca Upstash Redis…</div>';
 try{
  const response=await fetch(`/api/catalog?q=${q}`);
  const data=await readApiResponse(response);
  if (!data.results?.length) {
    target.innerHTML='<div class="catalog-empty">Nenhum torrent com reprodução confirmada foi encontrado.</div>';
    return;
  }
  target.innerHTML=data.results.map((item,index)=>`<article class="catalog-item result" role="listitem">
    <div class="catalog-item-head"><b>${esc(item.name)}</b><span class="pill">REPRODUZIDO</span></div>
    <div class="muted hash-inline" title="${esc(item.infoHash)}">Info hash: ${esc(item.infoHash)}</div>
    <div class="muted small">Arquivo: ${esc(item.fileName||'—')} · ${pretty(item.fileLength)} · ${item.playedAt?new Date(item.playedAt).toLocaleString():''}</div>
    ${item.magnetURI
      ? `<div class="muted small magnet-record" title="${esc(item.magnetURI)}">Magnet salvo · ${esc(item.magnetURI.slice(0,90))}${item.magnetURI.length>90?'…':''}</div>
         <div class="catalog-item-actions">
           <button type="button" class="secondary" data-magnet="${index}">Copiar magnet</button>
           <button type="button" data-play-catalog="${index}">Reproduzir</button>
         </div>`
      : '<div class="muted small">Registro antigo: magnet completo não disponível.</div>'}
  </article>`).join('');
  target.querySelectorAll('button[data-magnet]').forEach(button=>{
    button.onclick=async()=>{
      try { await navigator.clipboard.writeText(data.results[Number(button.dataset.magnet)].magnetURI); button.textContent='Copiado'; }
      catch { button.textContent='Falha'; }
    };
  });
  target.querySelectorAll('button[data-play-catalog]').forEach(button=>{
    button.onclick=async()=>{
      const item=data.results[Number(button.dataset.playCatalog)];
      if (!item?.magnetURI) return;
      const magnet=injectWebRtcTrackersIntoMagnet(item.magnetURI);
      $('#magnet').value=magnet;
      torrentFileObject=null; torrentFileBuffer=null; lastMagnetUri=magnet;
      setAddFeedback('loading','Carregando da biblioteca…');
      await inspectMagnet();
      if (current) {
        current.private=false;
        const defaults=['wss://tracker.btorrent.xyz','wss://tracker.fastcast.nz','wss://tracker.openwebtorrent.com','wss://tracker.webtorrent.dev'];
        const have=new Set((current.trackers||[]).map(t=>typeof t==='string'?t:t?.url));
        for (const url of defaults) if (!have.has(url)) current.trackers=[...(current.trackers||[]),{url,type:'websocket',injected:true}];
      }
      setAddFeedback('ok','Magnet da biblioteca pronto. Abrindo player…');
      activateTab('player');
      $('#connect').disabled=false;
    };
  });
 } catch(error) {
  target.innerHTML=`<div class="catalog-empty">Biblioteca em nuvem indisponível: ${esc(error.message)}</div>`;
 }
}
$('#searchBtn').addEventListener('click',searchCatalog);
searchCatalog();
