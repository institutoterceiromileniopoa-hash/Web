// Pure helpers for adaptive WebTorrent streaming. They do not create peers or
// guarantee throughput; they tune piece priority using playback telemetry.
export function getBufferAhead(video) {
  if (!video || !Number.isFinite(video.currentTime)) return 0;
  let ranges;
  try { ranges = video.buffered; } catch { return 0; }
  if (!ranges) return 0;
  const time = Math.max(0, video.currentTime);
  for (let i = 0; i < ranges.length; i++) {
    try {
      const start = ranges.start(i), end = ranges.end(i);
      if (Number.isFinite(start) && Number.isFinite(end) && end >= start && time >= start - 0.30 && time <= end + 0.30) {
        return Math.max(0, end - time);
      }
    } catch { /* TimeRanges pode mudar durante a leitura */ }
  }
  return 0;
}

export function getAdaptiveWindow({ bufferAhead = 0, downloadSpeed = 0, fileLength = 0, duration = 0, currentTime = 0, paused = false } = {}) {
  const bitrate = duration > 0 ? fileLength / duration : 0;
  const throughputRatio = bitrate > 0 ? downloadSpeed / bitrate : 0;
  let targetBuffer = bufferAhead < 8 ? 75 : bufferAhead < 18 ? 55 : bufferAhead < 35 ? 40 : 25;
  if (paused) targetBuffer = Math.max(targetBuffer, 60);
  if (throughputRatio > 2 && bufferAhead > 35) targetBuffer = 20;
  const startSeconds = Math.max(0, currentTime - 1);
  const endSeconds = Math.min(duration || currentTime + targetBuffer, currentTime + targetBuffer);
  const mode = bufferAhead < 8 ? 'RECUPERAR BUFFER' : bufferAhead < 20 ? 'PRIORIDADE ALTA' : bufferAhead < 40 ? 'EQUILIBRADO' : 'BUFFER PROTEGIDO';
  return { startSeconds, endSeconds, targetBuffer, bitrate, throughputRatio, mode, currentBytes: duration > 0 ? (currentTime / duration) * fileLength : 0 };
}

export function getPieceRange({ fileOffset = 0, fileLength = 0, pieceLength = 0, startSeconds = 0, endSeconds = 0, duration = 0 } = {}) {
  if (!(pieceLength > 0) || !(fileLength > 0) || !(duration > 0)) return null;
  const startByte = Math.max(0, Math.min(fileLength - 1, (startSeconds / duration) * fileLength));
  const endByte = Math.max(startByte, Math.min(fileLength - 1, (endSeconds / duration) * fileLength));
  return {
    start: Math.floor((fileOffset + startByte) / pieceLength),
    end: Math.floor((fileOffset + endByte) / pieceLength)
  };
}

export function getPeerStats(wires = []) {
  const peers = wires.map((wire, index) => ({
    id: String(wire.peerId || wire.remoteAddress || `peer-${index + 1}`).slice(0, 18),
    type: wire.type || 'webrtc',
    downloadSpeed: Math.max(0, Number(wire.downloadSpeed) || 0),
    uploadSpeed: Math.max(0, Number(wire.uploadSpeed) || 0),
    downloaded: Math.max(0, Number(wire.downloaded) || 0)
  })).sort((a, b) => b.downloadSpeed - a.downloadSpeed);
  const active = peers.filter(peer => peer.downloadSpeed > 0);
  return {
    peers,
    activeDownloadPeers: active.length,
    averageDownloadSpeed: active.length ? active.reduce((sum, peer) => sum + peer.downloadSpeed, 0) / active.length : 0
  };
}

export function chooseConnectionLimit({ mobile = false, hardwareConcurrency = 4, deviceMemory = 4 } = {}) {
  // More sockets are not always faster; keep mobile devices conservative.
  const cores = Math.max(2, Number(hardwareConcurrency) || 4);
  const memory = Math.max(1, Number(deviceMemory) || 4);
  if (mobile || memory <= 2 || cores <= 4) return 40;
  if (memory >= 8 && cores >= 8) return 75;
  return 60;
}
