/**
 * Tradutor SRT → PT-BR em tempo real (prioridade pelo playhead).
 * Adaptado do pipeline do BitTorrent Swarm Client.
 * APIs: Google Translate (gtx) com fallback MyMemory.
 */

function parseTimestampToSeconds(ts) {
  const parts = String(ts).replace(',', '.').split(':');
  if (parts.length !== 3) return 0;
  const hours = parseFloat(parts[0]) || 0;
  const minutes = parseFloat(parts[1]) || 0;
  const seconds = parseFloat(parts[2]) || 0;
  return hours * 3600 + minutes * 60 + seconds;
}

export function parseSrtToCues(srtText) {
  const cues = [];
  const normalized = String(srtText || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
  const blocks = normalized.split(/\n\s*\n/);

  for (const block of blocks) {
    const lines = block.trim().split('\n');
    if (lines.length < 2) continue;

    let timeIdx = 0;
    if (/^\d+$/.test(lines[0].trim())) timeIdx = 1;
    if (timeIdx >= lines.length) continue;

    const timeMatch = lines[timeIdx].match(
      /(\d{2}:\d{2}:\d{2}[,.]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[,.]\d{3})/
    );
    if (!timeMatch) continue;

    const start = timeMatch[1].replace(',', '.');
    const end = timeMatch[2].replace(',', '.');
    const text = lines.slice(timeIdx + 1).join('\n').replace(/<[^>]*>/g, '').trim();
    if (text) {
      cues.push({
        start,
        end,
        startSec: parseTimestampToSeconds(start),
        endSec: parseTimestampToSeconds(end),
        text,
        translated: false
      });
    }
  }
  return cues;
}

export function cuesToWebVtt(cues) {
  let vtt = 'WEBVTT\n\n';
  cues.forEach((cue, index) => {
    vtt += `${index + 1}\n${cue.start} --> ${cue.end}\n${cue.text}\n\n`;
  });
  return vtt;
}

export function detectSourceLanguage(cues) {
  const sample = (cues || []).slice(0, 25).map(c => c.text).join(' ');
  const lower = sample.toLowerCase();

  if (/[\u3040-\u309F\u30A0-\u30FF]/.test(sample)) return { code: 'ja', label: 'Japonês (JA)' };
  if (/[\uAC00-\uD7AF\u1100-\u11FF]/.test(sample)) return { code: 'ko', label: 'Coreano (KO)' };
  if (/[\u4E00-\u9FFF]/.test(sample)) return { code: 'zh-CN', label: 'Chinês (ZH)' };
  if (/[\u0400-\u04FF]/.test(sample)) return { code: 'ru', label: 'Russo (RU)' };
  if (/[\u0600-\u06FF]/.test(sample)) return { code: 'ar', label: 'Árabe (AR)' };
  if (/\b(the|and|you|that|was|for|are|with|this|have|from|not|but|they|what|there)\b/.test(lower)) {
    return { code: 'en', label: 'Inglês (EN)' };
  }
  if (/\b(que|los|las|por|para|una|con|como|pero|más|está|todo|donde|quien)\b/.test(lower)) {
    return { code: 'es', label: 'Espanhol (ES)' };
  }
  if (/\b(les|des|est|que|pour|dans|pas|plus|avec|sur|une|nous|vous|cette)\b/.test(lower)) {
    return { code: 'fr', label: 'Francês (FR)' };
  }
  if (/\b(der|die|und|in|den|von|zu|das|mit|sich|des|nicht|auch|ein)\b/.test(lower)) {
    return { code: 'de', label: 'Alemão (DE)' };
  }
  if (/\b(non|che|di|un|il|la|per|una|del|le|con|sono|questo|anche)\b/.test(lower)) {
    return { code: 'it', label: 'Italiano (IT)' };
  }
  if (/\b(não|você|para|com|uma|mais|como|isso|está|será|também)\b/.test(lower)) {
    return { code: 'pt', label: 'Português (PT)' };
  }
  return { code: 'auto', label: 'Auto-detectado' };
}

export async function translatePhraseToPtBr(text, sourceLangCode) {
  if (!text || !text.trim()) return text;
  if (sourceLangCode === 'pt') return text;

  const cleanQuery = text.substring(0, 480);

  try {
    const sl = sourceLangCode === 'auto' ? 'auto' : sourceLangCode;
    const gUrl =
      `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(sl)}` +
      `&tl=pt-BR&dt=t&q=${encodeURIComponent(cleanQuery)}`;
    const gRes = await fetch(gUrl);
    if (gRes.ok) {
      const gData = await gRes.json();
      if (Array.isArray(gData) && Array.isArray(gData[0])) {
        const combined = gData[0].map(part => part[0] || '').join('').trim();
        if (combined) return combined;
      }
    }
  } catch {}

  try {
    const mmLang = sourceLangCode === 'auto' ? 'en' : sourceLangCode;
    const url =
      `https://api.mymemory.translated.net/get?q=${encodeURIComponent(cleanQuery)}` +
      `&langpair=${encodeURIComponent(mmLang)}|pt-BR`;
    const response = await fetch(url);
    if (response.ok) {
      const data = await response.json();
      const translated = data?.responseData?.translatedText;
      if (translated && typeof translated === 'string' && translated.trim()) {
        return translated.trim();
      }
    }
  } catch {}

  return text;
}

function getAdaptiveTranslationProfile(downloadSpeedBps = 0) {
  if (downloadSpeedBps > 400 * 1024) {
    return { batchSize: 6, delayMs: 120, label: 'Rápido • Lote 6x' };
  }
  if (downloadSpeedBps > 80 * 1024) {
    return { batchSize: 3, delayMs: 280, label: 'Equilibrado • Lote 3x' };
  }
  return { batchSize: 2, delayMs: 450, label: 'Econômico • Lote 2x' };
}

function pickNextPrioritizedBatch(liveCues, batchSize, currentTime) {
  const pendingIndices = [];
  for (let i = 0; i < liveCues.length; i++) {
    if (!liveCues[i].translated) pendingIndices.push(i);
  }
  if (!pendingIndices.length) return [];

  pendingIndices.sort((a, b) => {
    const diffA = liveCues[a].startSec - (currentTime - 2);
    const diffB = liveCues[b].startSec - (currentTime - 2);
    const scoreA = diffA >= 0 ? diffA : Math.abs(diffA) + 100000;
    const scoreB = diffB >= 0 ? diffB : Math.abs(diffB) + 100000;
    return scoreA - scoreB;
  });

  return pendingIndices.slice(0, batchSize);
}

/**
 * Controlador de tradução em tempo real vinculado a um <video>.
 */
export function createRealtimeSubtitleTranslator({
  video,
  trackElement,
  onStatus,
  onProgress,
  onPreview,
  getDownloadSpeed = () => 0
} = {}) {
  let abort = false;
  let running = false;
  let blobUrl = null;
  let cues = [];

  const emitStatus = (msg) => { if (typeof onStatus === 'function') onStatus(msg); };
  const emitProgress = (data) => { if (typeof onProgress === 'function') onProgress(data); };
  const emitPreview = (text) => { if (typeof onPreview === 'function') onPreview(text); };

  function applyVttToPlayer(vttText) {
    if (!trackElement || !video) return;
    const nextUrl = URL.createObjectURL(new Blob([vttText], { type: 'text/vtt;charset=utf-8' }));
    if (blobUrl) {
      try { URL.revokeObjectURL(blobUrl); } catch {}
    }
    blobUrl = nextUrl;
    trackElement.src = blobUrl;
    trackElement.default = true;
    trackElement.kind = 'subtitles';
    trackElement.srclang = 'pt';
    trackElement.label = 'Português (PT-BR)';
    // Force show
    try {
      if (video.textTracks && video.textTracks.length) {
        for (let i = 0; i < video.textTracks.length; i++) {
          video.textTracks[i].mode = 'showing';
        }
      }
    } catch {}
  }

  async function startFromSrtText(rawSrtContent, fileName = 'legenda.srt') {
    abort = true;
    await new Promise(r => setTimeout(r, 50));
    abort = false;
    running = true;

    cues = parseSrtToCues(rawSrtContent);
    if (!cues.length) {
      emitStatus('SRT inválido ou vazio');
      running = false;
      return { ok: false, reason: 'empty' };
    }

    const detected = detectSourceLanguage(cues);
    emitStatus(`Origem: ${detected.label} → PT-BR`);
    emitProgress({
      completed: 0,
      total: cues.length,
      percent: 0,
      rate: 0,
      mode: detected.code === 'pt' ? 'Nativo PT-BR' : 'Traduzindo ao vivo…',
      language: detected.label,
      fileName
    });

    const liveCues = cues.map(c => ({ ...c, translated: detected.code === 'pt' }));
    applyVttToPlayer(cuesToWebVtt(liveCues));

    if (detected.code === 'pt') {
      emitProgress({
        completed: liveCues.length,
        total: liveCues.length,
        percent: 100,
        rate: 0,
        mode: 'Nativo PT-BR • 100%',
        language: detected.label,
        fileName
      });
      emitPreview(liveCues[0]?.text || '');
      running = false;
      return { ok: true, native: true, cues: liveCues };
    }

    let completedCount = liveCues.filter(c => c.translated).length;
    const startTimeMs = performance.now();

    while (completedCount < liveCues.length && !abort) {
      const currentTime = video && Number.isFinite(video.currentTime) ? video.currentTime : 0;
      const profile = getAdaptiveTranslationProfile(getDownloadSpeed());
      const batchIndices = pickNextPrioritizedBatch(liveCues, profile.batchSize, currentTime);
      if (!batchIndices.length) break;

      let lastText = '';
      await Promise.all(batchIndices.map(async (idx) => {
        if (abort) return;
        const translatedText = await translatePhraseToPtBr(liveCues[idx].text, detected.code);
        liveCues[idx].text = translatedText;
        liveCues[idx].translated = true;
        completedCount += 1;
        lastText = translatedText;
      }));

      if (abort) break;

      applyVttToPlayer(cuesToWebVtt(liveCues));

      const elapsedSec = Math.max(0.2, (performance.now() - startTimeMs) / 1000);
      const rate = completedCount / elapsedSec;
      const percent = Math.min(100, Math.round((completedCount / liveCues.length) * 100));

      emitProgress({
        completed: completedCount,
        total: liveCues.length,
        percent,
        rate,
        mode: profile.label,
        language: detected.label,
        fileName
      });
      if (lastText) emitPreview(lastText);

      await new Promise(r => setTimeout(r, profile.delayMs));
    }

    running = false;
    if (!abort) {
      emitStatus('PT-BR concluído');
      emitProgress({
        completed: liveCues.length,
        total: liveCues.length,
        percent: 100,
        rate: 0,
        mode: 'Concluído • 100% PT-BR',
        language: detected.label,
        fileName
      });
    }
    cues = liveCues;
    return { ok: true, native: false, cues: liveCues, aborted: abort };
  }

  function stop() {
    abort = true;
    running = false;
  }

  function destroy() {
    stop();
    if (blobUrl) {
      try { URL.revokeObjectURL(blobUrl); } catch {}
      blobUrl = null;
    }
  }

  return {
    startFromSrtText,
    stop,
    destroy,
    isRunning: () => running,
    getCues: () => cues
  };
}
