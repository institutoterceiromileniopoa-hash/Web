// Telemetria em tempo real a partir dos contadores cumulativos do WebTorrent.
// Calcula throughput por delta de bytes (swarm real), não por estimativa solta.

const finiteCounter = value => {
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 ? n : null;
};

const rateFromDelta = (current, previous, seconds, fallback = 0) => {
  if (current == null || previous == null || !(seconds > 0)) {
    return Math.max(0, Number(fallback) || 0);
  }
  // Contador resetou / reconectou
  if (current < previous) return Math.max(0, Number(fallback) || 0);
  return Math.max(0, (current - previous) / seconds);
};

/**
 * Sampler de alta frequência. Aceita intervalos a partir de ~16 ms (1 frame).
 * Mantém estado interno de bytes para derivar KB/s reais do swarm.
 */
export function createTelemetrySampler() {
  let previousAt = null;
  let previousDownloaded = null;
  let previousUploaded = null;
  const previousPeers = new Map();
  // EMA suave para o ponteiro dos gauges (sem atrasar demais a leitura)
  let emaDown = 0;
  let emaUp = 0;

  return function sample(torrent, wires = [], now = (typeof performance !== 'undefined' ? performance.now() : Date.now())) {
    const rawSeconds = previousAt == null ? 0 : (now - previousAt) / 1000;
    // Para rAF (~16ms) usamos o delta real; mínimo evita divisão explosiva no 1º tick
    const seconds = previousAt == null ? 0 : Math.max(0.001, rawSeconds);

    const downloaded = finiteCounter(torrent?.downloaded);
    const uploaded = finiteCounter(torrent?.uploaded);

    // Prefere delta de bytes do swarm; cai no downloadSpeed do WT se ainda não há histórico
    let downloadSpeed = rateFromDelta(downloaded, previousDownloaded, seconds, torrent?.downloadSpeed);
    let uploadSpeed = rateFromDelta(uploaded, previousUploaded, seconds, torrent?.uploadSpeed);

    // No primeiro tick (sem delta), use a taxa interna do WebTorrent se existir
    if (previousAt == null) {
      downloadSpeed = Math.max(0, Number(torrent?.downloadSpeed) || 0);
      uploadSpeed = Math.max(0, Number(torrent?.uploadSpeed) || 0);
    }

    const peers = new Map();
    const alive = new Set();

    for (let index = 0; index < wires.length; index++) {
      const wire = wires[index];
      if (!wire) continue;
      const id = String(wire.peerId || wire.remoteAddress || `peer-${index + 1}`);
      alive.add(id);
      const currentDown = finiteCounter(wire.downloaded);
      const currentUp = finiteCounter(wire.uploaded);
      const previous = previousPeers.get(id);
      peers.set(id, {
        downloadSpeed: rateFromDelta(currentDown, previous?.downloaded ?? null, seconds, wire.downloadSpeed),
        uploadSpeed: rateFromDelta(currentUp, previous?.uploaded ?? null, seconds, wire.uploadSpeed),
        downloaded: currentDown ?? 0,
        uploaded: currentUp ?? 0
      });
      previousPeers.set(id, { downloaded: currentDown, uploaded: currentUp });
    }
    for (const id of [...previousPeers.keys()]) {
      if (!alive.has(id)) previousPeers.delete(id);
    }

    // Suavização leve (α alto = mais responsivo)
    const alpha = seconds > 0 && seconds < 0.05 ? 0.45 : 0.3;
    emaDown = emaDown * (1 - alpha) + downloadSpeed * alpha;
    emaUp = emaUp * (1 - alpha) + uploadSpeed * alpha;

    previousAt = now;
    previousDownloaded = downloaded;
    previousUploaded = uploaded;

    return {
      downloadSpeed,
      uploadSpeed,
      downloadSpeedSmooth: emaDown,
      uploadSpeedSmooth: emaUp,
      downloaded: downloaded ?? 0,
      uploaded: uploaded ?? 0,
      peers,
      sampledAt: now
    };
  };
}

// Estima o buffer à frente a partir das peças já verificadas do arquivo de vídeo.
// Diferente de video.buffered (MSE), esta leitura acompanha os bytes que o
// WebTorrent efetivamente recebeu e validou no bitfield do torrent.
export function getDownloadedBufferAhead(torrent, file, video) {
  const unavailable = { ahead: null, bytesAhead: 0, piecesAhead: 0, valid: false, state: 'indisponível' };
  if (!torrent || !file || !video || !Number.isFinite(video.duration) || video.duration <= 0) return unavailable;
  if (!torrent.pieceLength || !file.length) return unavailable;
  if (!torrent.bitfield || typeof torrent.bitfield.get !== 'function') return unavailable;

  const fileOffset = Number.isFinite(file.offset)
    ? file.offset
    : torrent.files.slice(0, torrent.files.indexOf(file)).reduce((n, f) => n + (f.length || 0), 0);

  const ratio = Math.min(1, Math.max(0, (video.currentTime || 0) / video.duration));
  const fileByte = ratio * file.length;
  const absoluteByte = fileOffset + fileByte;
  const pieceLength = torrent.pieceLength;
  const firstPiece = Math.floor(absoluteByte / pieceLength);
  const fileEnd = fileOffset + file.length;
  const lastPiece = Math.ceil(fileEnd / pieceLength) - 1;
  let piecesAhead = 0;
  let contiguousEnd = absoluteByte;

  for (let piece = firstPiece; piece <= lastPiece; piece++) {
    let verified = false;
    try { verified = torrent.bitfield.get(piece) === true; } catch { break; }
    if (!verified) break;
    piecesAhead++;
    contiguousEnd = Math.min(fileEnd, (piece + 1) * pieceLength);
  }

  const bytesAhead = Math.max(0, contiguousEnd - absoluteByte);
  const secondsPerByte = video.duration / file.length;
  const ahead = bytesAhead * secondsPerByte;
  return {
    ahead, bytesAhead, piecesAhead, valid: true,
    state: piecesAhead ? `${piecesAhead} peça(s) verificadas à frente` : 'nenhuma peça completa à frente'
  };
}

// Mede apenas o intervalo contínuo que contém o playhead.
export function getPlaybackBuffer(video) {
  const unavailable = { ahead: null, ranges: 0, valid: false, state: 'indisponível' };
  if (!video || !Number.isFinite(video.currentTime)) return unavailable;

  let ranges;
  try { ranges = video.buffered; } catch { return unavailable; }
  if (!ranges || !Number.isInteger(ranges.length) || ranges.length < 0) return unavailable;

  const time = Math.max(0, video.currentTime);
  const epsilon = 0.30;
  let count = 0;

  for (let i = 0; i < ranges.length; i++) {
    let start, end;
    try { start = ranges.start(i); end = ranges.end(i); } catch { continue; }
    if (!Number.isFinite(start) || !Number.isFinite(end) || end < start) continue;
    count++;

    if (time < start && start - time <= epsilon) {
      return { ahead: Math.max(0, end - start), ranges: ranges.length, valid: true, state: 'sincronizando faixa' };
    }
    if (time >= start && time <= end + epsilon) {
      const ahead = Math.max(0, end - time);
      return { ahead, ranges: ranges.length, valid: true, state: ahead > 0.15 ? 'buffer contínuo' : 'buffer baixo' };
    }
  }

  return { ahead: null, ranges: ranges.length, valid: false, state: count ? 'playhead fora do buffer' : 'aguardando dados' };
}
