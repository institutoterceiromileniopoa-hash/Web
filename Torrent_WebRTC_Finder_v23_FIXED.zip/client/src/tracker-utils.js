// Trackers WSS (WebTorrent / browser WebRTC)
export const DEFAULT_WEBRTC_TRACKERS = Object.freeze([
  'wss://tracker.btorrent.xyz',
  'wss://tracker.fastcast.nz',
  'wss://tracker.openwebtorrent.com',
  'wss://tracker.webtorrent.dev',
  'wss://tracker.files.fm:7073/announce',
  'wss://spacetradersapi-chatbox.herokuapp.com:443/announce'
]);

// Trackers UDP/HTTP recomendados (YTS docs + públicos estáveis) — úteis no backend/DHT;
// no browser só WSS conecta via WebRTC, mas embutir no magnet amplia descoberta.
export const DEFAULT_BITTORRENT_TRACKERS = Object.freeze([
  'udp://tracker.opentrackr.org:1337/announce',
  'udp://tracker.torrent.eu.org:451/announce',
  'udp://open.stealth.si:80/announce',
  'udp://open.demonii.com:1337/announce',
  'udp://tracker.dler.org:6969/announce',
  'udp://open.dstud.io:6969/announce',
  'udp://tracker.srv00.com:6969/announce',
  'udp://tracker.openbittorrent.com:6969/announce',
  'udp://exodus.desync.com:6969/announce',
  'udp://tracker.moeking.me:6969/announce',
  'udp://tracker1.bt.moack.co.kr:80/announce',
  'udp://tracker.tiny-vps.com:6969/announce',
  'udp://tracker.cyberia.is:6969/announce',
  'https://tracker.moeblog.cn:443/announce',
  'https://tracker.zhuqiy.com:443/announce',
  'https://tracker.pmman.tech:443/announce'
]);

export function collectAllPublicTrackers() {
  return [...new Set([...DEFAULT_WEBRTC_TRACKERS, ...DEFAULT_BITTORRENT_TRACKERS])];
}

/**
 * Plano de trackers WebRTC para o player no navegador.
 * Sempre garante WSS (exceto torrent privado confirmado).
 */
export function getWebRtcTrackerPlan(trackers = [], isPrivate = undefined) {
  const entries = Array.isArray(trackers) ? trackers : [];
  const valid = entries
    .map(item => typeof item === 'string' ? item : item?.url)
    .filter(value => typeof value === 'string' && value.trim())
    .map(value => value.trim());
  const unique = [...new Set(valid)];
  const webRtc = unique.filter(value => {
    try { return new URL(value).protocol === 'wss:'; } catch { return false; }
  });

  if (isPrivate === true) {
    return { announce: webRtc, injected: false, reason: 'private' };
  }

  const merged = [...new Set([...webRtc, ...DEFAULT_WEBRTC_TRACKERS])];
  const injected = merged.length > webRtc.length;
  return {
    announce: merged,
    injected,
    reason: webRtc.length ? (injected ? 'merged' : 'existing') : 'fallback'
  };
}

/**
 * Enriquece magnet com o máximo de trackers públicos (WSS + UDP/HTTP).
 * Se já houver WSS, ainda assim completa a lista para maximizar descoberta.
 */
export function enrichMagnetWithTrackers(magnet, { includeUdp = true, isPrivate = false } = {}) {
  if (!magnet || typeof magnet !== 'string' || !/^magnet:\?/i.test(magnet.trim())) {
    return magnet;
  }
  if (isPrivate === true) return magnet;

  try {
    const url = new URL(magnet.trim());
    const existing = url.searchParams.getAll('tr');
    const have = new Set(existing.map(t => t.trim().toLowerCase()));

    const pool = includeUdp
      ? collectAllPublicTrackers()
      : [...DEFAULT_WEBRTC_TRACKERS];

    let added = 0;
    for (const tr of pool) {
      const key = tr.toLowerCase();
      if (have.has(key)) continue;
      // evita duplicar por hostname+path aproximado
      const host = (() => { try { return new URL(tr).host; } catch { return tr; } })();
      if ([...have].some(e => e.includes(host))) continue;
      url.searchParams.append('tr', tr);
      have.add(key);
      added += 1;
    }
    return { magnet: url.toString(), added, total: url.searchParams.getAll('tr').length };
  } catch {
    return { magnet, added: 0, total: 0 };
  }
}

export function buildMagnetFromHash(infoHash, name = '', trackers = null) {
  const hash = String(infoHash || '').toLowerCase();
  if (!/^[a-f0-9]{40}$/.test(hash)) return null;
  const parts = [`xt=urn:btih:${hash}`];
  if (name) parts.push(`dn=${encodeURIComponent(String(name).slice(0, 180))}`);
  const list = trackers || collectAllPublicTrackers();
  for (const tr of list) parts.push(`tr=${encodeURIComponent(tr)}`);
  return `magnet:?${parts.join('&')}`;
}
