import { copyFileSync, existsSync, mkdirSync, readdirSync } from 'node:fs';
import { dirname, resolve, join } from 'node:path';

const packageRoot = resolve('node_modules/webtorrent');
const candidates = [
  resolve(packageRoot, 'sw.min.js'),
  resolve(packageRoot, 'dist/sw.min.js'),
  resolve(packageRoot, 'lib/sw.min.js')
];

// O layout do pacote pode mudar entre versões. Procura o worker pelo nome
// dentro do pacote oficial, sem copiar arquivos de outros módulos.
function findWorker(dir, depth = 0) {
  if (!existsSync(dir) || depth > 5) return null;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isFile() && entry.name === 'sw.min.js') return path;
    if (entry.isDirectory() && !['node_modules', '.git'].includes(entry.name)) {
      const found = findWorker(path, depth + 1);
      if (found) return found;
    }
  }
  return null;
}

const source = candidates.find(existsSync) || findWorker(packageRoot);
if (!source) {
  console.error('WebTorrent Service Worker sw.min.js não foi encontrado dentro de node_modules/webtorrent. O deploy foi interrompido para evitar publicar um player sem streaming.');
  process.exit(1);
}
const destination = resolve('client/public/sw.min.js');
mkdirSync(dirname(destination), { recursive: true });
copyFileSync(source, destination);
console.log(`WebTorrent Service Worker copiado de ${source} para ${destination}`);
