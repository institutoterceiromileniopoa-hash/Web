import { createHash } from 'node:crypto';

// Minimal, bounded bencode decoder retaining byte offsets for the exact info-hash.
export function decodeTorrent(buffer) {
  if (!Buffer.isBuffer(buffer)) buffer = Buffer.from(buffer);
  if (buffer.length > 20 * 1024 * 1024) throw new Error('Arquivo .torrent excede 20 MB.');
  let pos = 0;
  const read = (depth = 0) => {
    if (depth > 64 || pos >= buffer.length) throw new Error('Bencode inválido ou excessivamente profundo.');
    const start = pos;
    const c = buffer[pos];
    if (c === 0x69) { // integer: i123e
      pos++;
      const end = buffer.indexOf(0x65, pos);
      if (end < 0) throw new Error('Inteiro bencode sem terminador.');
      const raw = buffer.toString('ascii', pos, end);
      if (!/^-?(0|[1-9]\d*)$/.test(raw)) throw new Error('Inteiro bencode inválido.');
      pos = end + 1;
      return { type: 'integer', value: Number(raw), start, end: pos };
    }
    if (c === 0x6c) { // list
      pos++;
      const value = [];
      while (pos < buffer.length && buffer[pos] !== 0x65) value.push(read(depth + 1));
      if (buffer[pos++] !== 0x65) throw new Error('Lista bencode sem terminador.');
      return { type: 'list', value, start, end: pos };
    }
    if (c === 0x64) { // dictionary
      pos++;
      const value = new Map();
      while (pos < buffer.length && buffer[pos] !== 0x65) {
        const key = read(depth + 1);
        if (key.type !== 'bytes') throw new Error('Chave de dicionário inválida.');
        value.set(key.value.toString('utf8'), read(depth + 1));
      }
      if (buffer[pos++] !== 0x65) throw new Error('Dicionário bencode sem terminador.');
      return { type: 'dict', value, start, end: pos };
    }
    if (c >= 0x30 && c <= 0x39) { // byte string
      const colon = buffer.indexOf(0x3a, pos);
      if (colon < 0) throw new Error('String bencode sem tamanho.');
      const sizeRaw = buffer.toString('ascii', pos, colon);
      if (!/^(0|[1-9]\d*)$/.test(sizeRaw)) throw new Error('Tamanho bencode inválido.');
      const size = Number(sizeRaw);
      if (!Number.isSafeInteger(size) || size > buffer.length) throw new Error('String bencode muito grande.');
      pos = colon + 1;
      const end = pos + size;
      if (end > buffer.length) throw new Error('String bencode truncada.');
      const value = buffer.subarray(pos, end);
      pos = end;
      return { type: 'bytes', value, start, end: pos };
    }
    throw new Error(`Token bencode inesperado na posição ${pos}.`);
  };
  const root = read();
  if (pos !== buffer.length || root.type !== 'dict') throw new Error('Metainfo torrent inválida ou com bytes excedentes.');
  const dict = root.value;
  const info = dict.get('info');
  if (!info || info.type !== 'dict') throw new Error('Metainfo não contém o dicionário info.');
  const infoHash = createHash('sha1').update(buffer.subarray(info.start, info.end)).digest('hex');
  const getBytes = (d, key) => d.get(key)?.type === 'bytes' ? d.get(key).value : null;
  const getNum = (d, key) => d.get(key)?.type === 'integer' ? d.get(key).value : null;
  const decodeText = b => b ? b.toString('utf8') : '';
  const name = decodeText(getBytes(info.value, 'name.utf-8') || getBytes(info.value, 'name')) || 'Torrent sem nome';
  const filesNode = info.value.get('files');
  let files;
  if (filesNode?.type === 'list') {
    files = filesNode.value.map(item => {
      const partsNode = item.value.get('path.utf-8') || item.value.get('path');
      const parts = partsNode?.type === 'list' ? partsNode.value.map(x => x.value.toString('utf8')) : [];
      return { name: parts.join('/'), length: getNum(item.value, 'length') ?? 0 };
    });
  } else {
    files = [{ name, length: getNum(info.value, 'length') ?? 0 }];
  }
  const trackers = [];
  const addTracker = node => {
    if (node?.type === 'bytes') trackers.push(node.value.toString('utf8'));
    if (node?.type === 'list') node.value.forEach(addTracker);
  };
  addTracker(dict.get('announce'));
  addTracker(dict.get('announce-list'));
  const uniqueTrackers = [...new Set(trackers)].filter(Boolean);
  return {
    name, infoHash, files, totalLength: files.reduce((n, f) => n + f.length, 0),
    trackers: uniqueTrackers.map(url => ({ url, type: classifyTracker(url) })),
    private: getNum(info.value, 'private') === 1
  };
}

export function classifyTracker(value) {
  let protocol = 'unknown';
  try { protocol = new URL(value).protocol.toLowerCase(); } catch { return 'invalid'; }
  if (protocol === 'wss:') return 'websocket';
  if (protocol === 'ws:') return 'websocket-insecure';
  if (protocol === 'udp:') return 'udp';
  if (protocol === 'http:' || protocol === 'https:') return 'http';
  return 'unsupported';
}

export function parseMagnet(input) {
  if (typeof input !== 'string' || input.length > 8192) throw new Error('Magnet link inválido ou muito longo.');
  // Remove espaços/quebras colados de apps de mensagens e normaliza hashes soltos.
  let normalized = input.trim().replace(/\s+/g, '');
  if (/^[a-f0-9]{40}$/i.test(normalized)) {
    normalized = `magnet:?xt=urn:btih:${normalized.toLowerCase()}`;
  } else if (/^[a-z2-7]{32}$/i.test(normalized)) {
    normalized = `magnet:?xt=urn:btih:${normalized.toUpperCase()}`;
  } else if (/^xt=urn:btih:/i.test(normalized)) {
    normalized = `magnet:?${normalized}`;
  }
  let url;
  try { url = new URL(normalized); } catch { throw new Error('Magnet link inválido.'); }
  if (url.protocol !== 'magnet:') throw new Error('A origem precisa ser um magnet link.');
  const xt = url.searchParams.getAll('xt').find(v => /^urn:btih:/i.test(v));
  if (!xt) throw new Error('Magnet sem identificador BitTorrent v1 (btih).');
  const raw = xt.slice(9);
  let infoHash;
  if (/^[a-f0-9]{40}$/i.test(raw)) infoHash = raw.toLowerCase();
  else if (/^[a-z2-7]{32}$/i.test(raw)) {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; let bits = 0, acc = 0, hex = '';
    for (const ch of raw.toUpperCase()) { acc = (acc << 5) | alphabet.indexOf(ch); bits += 5; if (bits >= 8) { bits -= 8; hex += ((acc >> bits) & 255).toString(16).padStart(2, '0'); } }
    infoHash = hex.toLowerCase();
    if (infoHash.length !== 40) throw new Error('Info hash base32 inválido.');
  } else throw new Error('Formato de info hash não suportado.');
  const trackers = [...new Set(url.searchParams.getAll('tr'))].map(tr => ({ url: tr, type: classifyTracker(tr) }));
  return { name: url.searchParams.get('dn') || `Torrent ${infoHash.slice(0, 8)}`, infoHash, trackers, files: [], totalLength: Number(url.searchParams.get('xl')) || null, metadataPending: true };
}
