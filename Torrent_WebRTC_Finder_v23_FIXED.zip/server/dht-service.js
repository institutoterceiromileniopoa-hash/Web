// Descoberta híbrida inspirada no Magnet Fisher: DHT BEP-5 + trackers UDP/HTTP
// para recolher peers BitTorrent no backend. Esses peers NÃO são WebRTC peers;
// o player do navegador continua usando somente trackers WSS/WebTorrent.
export const MAGNET_FISHER_TRACKERS = Object.freeze([
  'udp://tracker.opentrackr.org:1337/announce',
  'udp://open.stealth.si:80/announce',
  'udp://tracker.torrent.eu.org:451/announce',
  'udp://tracker.tiny-vps.com:6969/announce',
  'udp://open.demonii.com:1337/announce',
  'udp://tracker.openbittorrent.com:6969/announce',
  'udp://exodus.desync.com:6969/announce',
  'udp://tracker.cyberia.is:6969/announce',
  'udp://tracker.moeking.me:6969/announce',
  'udp://tracker1.bt.moack.co.kr:80/announce'
]);

export function buildDiscoveryTrackers(trackers = [], isPrivate = undefined) {
  const supplied = Array.isArray(trackers) ? trackers : [];
  const safe = supplied.map(item => typeof item === 'string' ? item : item?.url)
    .filter(value => typeof value === 'string' && value.length <= 2048)
    .filter(value => {
      try { return ['udp:', 'http:', 'https:'].includes(new URL(value).protocol); }
      catch { return false; }
    });
  // Nunca injeta trackers públicos se a privacidade não foi explicitamente
  // confirmada como pública. Trackers que vieram no próprio magnet são mantidos.
  const selected = isPrivate === false ? [...safe, ...MAGNET_FISHER_TRACKERS] : safe;
  return [...new Set(selected)].slice(0, 30);
}

export async function lookupDht(infoHash, {
  timeoutMs = 25000, maxPeers = 400, trackers = [], isPrivate = undefined
} = {}) {
  if (process.env.VERCEL === '1' || process.env.DHT_ENABLED === '0') {
    return {
      available: false, count: 0, peers: [], engine: 'WebTorrent DHT + trackers',
      sources: [], elapsedMs: 0,
      note: 'A descoberta DHT/UDP precisa de sockets persistentes. Esta função serverless não oferece esse ambiente; execute o backend Node.js em um host persistente.'
    };
  }

  const hash = String(infoHash || '').toLowerCase();
  if (!/^[a-f0-9]{40}$/.test(hash)) throw new Error('Info hash inválido.');

  const WebTorrentModule = await import('webtorrent');
  const WebTorrent = WebTorrentModule.default || WebTorrentModule;
  const announce = buildDiscoveryTrackers(trackers, isPrivate);
  const peerLimit = Math.min(Math.max(Number(maxPeers) || 400, 1), 400);
  const bootstrap = [
    'router.bittorrent.com:6881', 'router.utorrent.com:6881',
    'dht.transmissionbt.com:6881', 'dht.aelitis.com:6881'
  ];
  const client = new WebTorrent({
    dht: { bootstrap },
    tracker: announce.length > 0,
    lsd: true,
    utPex: true,
    natUpnp: false,
    natPmp: false,
    maxConns: peerLimit
  });
  const peers = new Map();
  const sources = new Set(['DHT (BEP-5)']);
  if (announce.length) sources.add('trackers UDP/HTTP');
  let settled = false;
  let quietTimer = null;
  const startedAt = Date.now();

  return await new Promise(resolve => {
    const timer = setTimeout(() => finish(), Math.min(Math.max(timeoutMs, 1000), 27000));
    const addPeer = (wire, address) => {
      const addr = String(address || wire?.remoteAddress || '').trim();
      const match = addr.match(/^\[?([^\]]+)\]?:([0-9]{1,5})$/);
      if (!match) return;
      const port = Number(match[2]);
      if (!port || port > 65535 || peers.size >= peerLimit) return;
      const key = `${match[1]}:${port}`;
      peers.set(key, { host: match[1], port, transport: 'BitTorrent TCP/uTP' });
      clearTimeout(quietTimer);
      quietTimer = setTimeout(() => finish(), 2500);
    };
    const finish = async (error = null) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      clearTimeout(quietTimer);
      try { await new Promise(done => client.destroy(() => done())); } catch {}
      resolve({
        available: true, count: peers.size, peers: [...peers.values()],
        engine: 'WebTorrent DHT (BEP-5) + trackers', sources: [...sources],
        trackerCount: announce.length, elapsedMs: Date.now() - startedAt,
        error: error?.message || null,
        note: peers.size
          ? 'Peers BitTorrent encontrados no backend. Eles usam TCP/uTP e não podem ser conectados diretamente pelo player WebRTC do navegador.'
          : 'A busca consultou DHT e trackers configurados, mas nenhum peer TCP/uTP estabeleceu conexão nesta janela. Isso não prova que o swarm esteja vazio.'
      });
    };

    client.on('error', error => finish(error));
    try {
      const magnet = `magnet:?xt=urn:btih:${hash}`;
      const options = { deselect: true, paused: false, announce };
      const torrent = client.add(magnet, options);
      torrent.on('error', error => finish(error));
      torrent.on('wire', addPeer);
      torrent.on('trackerAnnounce', () => sources.add('trackers UDP/HTTP'));
      torrent.on('noPeers', () => {});
      torrent.on('ready', () => {
        if (peers.size) finish();
      });
    } catch (error) { finish(error); }
  });
}
