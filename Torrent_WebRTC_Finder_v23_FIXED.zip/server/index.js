import express from 'express';
import helmet from 'helmet';
import multer from 'multer';
import { rateLimit } from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { decodeTorrent, parseMagnet } from './bencode.js';
import { lookupDht } from './dht-service.js';
import { isUpstashConfigured, savePlayedTorrent, listPlayedTorrents } from './upstash-catalog.js';
import { validateStremioRequest, normalizeTorrentioStreams } from './stremio.js';
import { listMovies, movieDetails } from './yts.js';

const app = express();
const here = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8787);
const FRONTEND_ORIGINS = (process.env.FRONTEND_ORIGIN || 'http://localhost:5173').split(',').map(x => x.trim()).filter(Boolean);
app.disable('x-powered-by');
app.use(helmet({ crossOriginEmbedderPolicy: false, contentSecurityPolicy: false }));
app.use(express.json({ limit: '128kb' }));
app.use((req, res, next) => {
  const origin = req.headers.origin;
  // Em produção, a API e o frontend compartilham o mesmo domínio na Vercel.
  // Em desenvolvimento, também aceitamos a origem local do Vite.
  const sameOrigin = (() => { try { return new URL(origin).host === req.headers.host; } catch { return false; } })();
  const configuredOrigin = origin && FRONTEND_ORIGINS.includes(origin);
  if (origin && !sameOrigin && !configuredOrigin) return res.status(403).json({ error: 'Origem não autorizada.' });
  if (origin) { res.setHeader('Access-Control-Allow-Origin', origin); res.setHeader('Vary', 'Origin'); }
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false }));
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024, files: 1 } });

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'torrent-webrtc-finder', version: '0.24.0' }));
// Proxy YTS (movies-api.accel.li) — evita CORS e monta magnets com trackers.
app.get('/api/yts/movies', async (req, res) => {
  try {
    const result = await listMovies({
      query_term: req.query.q || req.query.query_term,
      limit: req.query.limit,
      page: req.query.page,
      quality: req.query.quality,
      minimum_rating: req.query.minimum_rating || req.query.rating,
      genre: req.query.genre,
      sort_by: req.query.sort_by || 'seeds',
      order_by: req.query.order_by || 'desc'
    });
    res.setHeader('Cache-Control', 'public, max-age=60');
    res.json(result);
  } catch (error) {
    res.status(502).json({ error: `Falha ao consultar YTS: ${error.message}`, movies: [], movieCount: 0 });
  }
});
app.get('/api/yts/movie', async (req, res) => {
  try {
    const result = await movieDetails({
      movie_id: req.query.movie_id || req.query.id,
      imdb_id: req.query.imdb_id || req.query.imdb,
      with_images: req.query.with_images !== 'false',
      with_cast: req.query.with_cast === 'true'
    });
    res.setHeader('Cache-Control', 'public, max-age=120');
    res.json(result);
  } catch (error) {
    res.status(502).json({ error: `Falha ao consultar detalhes YTS: ${error.message}` });
  }
});


// Proxy server-side do manifesto e dos streams Torrentio: evita CORS no navegador
// e mantém o domínio externo fixo, sem aceitar URLs arbitrárias do cliente.
app.get('/api/stremio/manifest', async (_req, res) => {
  try {
    const response = await fetch('https://torrentio.strem.fun/manifest.json', { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(10000) });
    if (!response.ok) return res.status(502).json({ error: `Torrentio respondeu HTTP ${response.status}.` });
    const manifest = await response.json();
    res.setHeader('Cache-Control', 'public, max-age=300');
    res.json(manifest);
  } catch (error) { res.status(502).json({ error: `Não foi possível consultar o manifesto Torrentio: ${error.message}` }); }
});
app.get('/api/stremio/stream/:type/:id', async (req, res) => {
  let query;
  try { query = validateStremioRequest(req.params.type, req.params.id); }
  catch (error) { return res.status(400).json({ error: error.message }); }
  try {
    const endpoint = `https://torrentio.strem.fun/stream/${encodeURIComponent(query.type)}/${encodeURIComponent(query.id)}.json`;
    const response = await fetch(endpoint, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(18000) });
    if (!response.ok) return res.status(response.status === 404 ? 200 : 502).json({ streams: [], error: response.status === 404 ? 'Torrentio não encontrou streams para este título.' : `Torrentio respondeu HTTP ${response.status}.` });
    const payload = await response.json();
    const streams = normalizeTorrentioStreams(payload);
    res.setHeader('Cache-Control', 'public, max-age=45');
    res.json({ streams, count: streams.length, source: 'torrentio' });
  } catch (error) { res.status(502).json({ streams: [], error: `Falha ao consultar Torrentio: ${error.message}` }); }
});
app.post('/api/dht/lookup', async (req, res) => {
  const infoHash = String(req.body?.infoHash || '').toLowerCase();
  if (!/^[a-f0-9]{40}$/.test(infoHash)) return res.status(400).json({ error: 'Info hash inválido. Informe 40 caracteres hexadecimais.' });
  const trackers = Array.isArray(req.body?.trackers) ? req.body.trackers : [];
  const isPrivate = typeof req.body?.isPrivate === 'boolean' ? req.body.isPrivate : undefined;
  try { res.json(await lookupDht(infoHash, { trackers, isPrivate })); }
  catch (error) { res.status(503).json({ error: `Falha ao iniciar DHT: ${error.message}` }); }
});
app.post('/api/inspect/magnet', (req, res) => {
  try { res.json(parseMagnet(req.body?.magnet)); }
  catch (error) { res.status(400).json({ error: error.message }); }
});
app.post('/api/inspect/file', upload.single('torrent'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Envie um arquivo .torrent.' });
    if (!req.file.originalname.toLowerCase().endsWith('.torrent')) return res.status(415).json({ error: 'Somente arquivos .torrent são aceitos.' });
    res.json(decodeTorrent(req.file.buffer));
  } catch (error) { res.status(400).json({ error: error.message }); }
});
// Biblioteca persistente de torrents cuja reprodução foi efetivamente confirmada.
app.get('/api/catalog', async (req, res) => {
  if (!isUpstashConfigured()) return res.status(503).json({ error: 'Biblioteca em nuvem indisponível: configure UPSTASH_REDIS_REST_URL e UPSTASH_REDIS_REST_TOKEN.' });
  try {
    const results = await listPlayedTorrents(req.query.q);
    res.json({ results, source: 'upstash-redis', count: results.length });
  } catch (error) { res.status(502).json({ error: `Falha ao consultar Upstash Redis: ${error.message}` }); }
});
app.post('/api/catalog/played', async (req, res) => {
  if (!isUpstashConfigured()) return res.status(503).json({ error: 'Biblioteca em nuvem indisponível: configure UPSTASH_REDIS_REST_URL e UPSTASH_REDIS_REST_TOKEN.' });
  try {
    const saved = await savePlayedTorrent(req.body);
    res.status(201).json({ saved: true, item: saved, source: 'upstash-redis' });
  } catch (error) { res.status(400).json({ error: error.message }); }
});

const clientDist = path.resolve(here, '../client/dist');
app.use(express.static(clientDist));
app.use((req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(clientDist, 'index.html'), err => { if (err) res.status(404).send('Frontend não compilado. Execute npm run build.'); });
});
// A Vercel importa o app como função serverless; localmente iniciamos o listener.
if (process.env.VERCEL !== '1' && process.env.NODE_ENV !== 'production') {
  app.listen(PORT, () => console.log(`Torrent WebRTC Finder API em http://localhost:${PORT}`));
}

export default app;
