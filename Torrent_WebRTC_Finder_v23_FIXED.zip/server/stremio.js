const HASH_RE = /^[a-f0-9]{40}$/i;
const BASE32_HASH_RE = /^[a-z2-7]{32}$/i;

const ALLOWED_TYPES = new Set([
  'movie',
  'series',
  'anime'
]);

/**
 * Valida identificadores de conteúdo do Stremio.
 */
export function validateStremioRequest(type, id) {
  const normalizedType = String(type || '').trim().toLowerCase();

  if (!ALLOWED_TYPES.has(normalizedType)) {
    throw new Error(
      'Tipo inválido. Use movie, series ou anime.'
    );
  }

  const value = String(id || '').trim();

  const validId =
    /^(?:tt\d{5,12}|kitsu:\d{1,12}|\d{1,12})(?::\d{1,4}){0,2}$/i;

  if (!validId.test(value)) {
    throw new Error(
      'ID inválido. Informe um ID IMDb (tt1234567) ou Kitsu.'
    );
  }

  return {
    type: normalizedType,
    id: value
  };
}

/**
 * Normaliza hashes hexadecimal, Base32 e Magnet URI.
 */
export function normalizeTorrentHash(value) {
  let hash = String(value || '').trim();

  if (!hash) return null;

  if (/^magnet:\?/i.test(hash)) {
    try {
      const params = new URL(hash).searchParams;

      const xt = params
        .getAll('xt')
        .find(item => /^urn:btih:/i.test(item));

      hash = xt
        ? xt.replace(/^urn:btih:/i, '')
        : '';
    } catch {
      return null;
    }
  }

  hash = hash.replace(/^urn:btih:/i, '').trim();

  if (HASH_RE.test(hash)) {
    return hash.toLowerCase();
  }

  if (BASE32_HASH_RE.test(hash)) {
    return hash.toUpperCase();
  }

  return null;
}

/**
 * Constrói Magnet URI a partir de um stream Torrentio.
 */
export function buildTorrentioMagnet(stream) {
  if (!stream || typeof stream !== 'object') {
    return null;
  }

  const hash = normalizeTorrentHash(
    stream.infoHash ||
    stream.info_hash ||
    stream.magnetUri ||
    stream.magnet ||
    (
      typeof stream.url === 'string' &&
      stream.url.startsWith('magnet:')
        ? stream.url
        : null
    )
  );

  if (!hash) return null;

  const params = new URLSearchParams();

  params.set('xt', `urn:btih:${hash}`);

  const name = String(
    stream.title ||
    stream.name ||
    ''
  )
    .replace(/[\r\n]/g, ' ')
    .slice(0, 180);

  if (name) {
    params.set('dn', name);
  }

  const sources = Array.isArray(stream.sources)
    ? stream.sources
    : [];

  const trackers = new Set();

  for (const source of sources) {
    const value = typeof source === 'string'
      ? source
      : source?.url;

    if (typeof value !== 'string') continue;

    const tracker = value.startsWith('tracker:')
      ? value.slice(8)
      : value;

    if (/^(?:wss?|udp|https?):\/\//i.test(tracker)) {
      trackers.add(tracker);
    }
  }

  for (const tracker of trackers) {
    params.append('tr', tracker);
  }

  return `magnet:?${params.toString()}`;
}

/**
 * Normaliza a lista de streams recebida do Torrentio.
 */
export function normalizeTorrentioStreams(payload) {
  if (!payload || typeof payload !== 'object') {
    return [];
  }

  const input = Array.isArray(payload)
    ? payload
    : Array.isArray(payload.streams)
      ? payload.streams
      : [];

  const result = [];

  for (const stream of input) {
    if (!stream || typeof stream !== 'object') {
      continue;
    }

    const hash = normalizeTorrentHash(
      stream.infoHash ||
      stream.info_hash ||
      stream.magnetUri ||
      stream.magnet ||
      (
        typeof stream.url === 'string' &&
        stream.url.startsWith('magnet:')
          ? stream.url
          : null
      )
    );

    const magnetUri = buildTorrentioMagnet(stream);
    const externalUrl = typeof stream.url === 'string' && !stream.url.startsWith('magnet:')
      ? stream.url
      : null;

    // Mantém apenas streams úteis: magnet/infoHash ou URL HTTP externa.
    if (!hash && !magnetUri && !externalUrl) {
      continue;
    }

    result.push({
      ...stream,

      ...(hash ? {
        infoHash: hash
      } : {}),

      ...(magnetUri ? {
        magnetUri,
        magnet: magnetUri
      } : {})
    });
  }

  return result;
}

/**
 * Extrai um identificador válido de torrent.
 */
export function extractTorrentIdentifier(identifier) {
  const hash = normalizeTorrentHash(identifier);

  if (!hash) {
    throw new Error(
      'Identificador de torrent inválido. Informe uma Magnet URI ou um info hash hexadecimal/Base32 válido.'
    );
  }

  return hash;
}
