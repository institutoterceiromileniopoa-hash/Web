const KEY = 'twf:catalog:played:v1';

function config() {
  const url = String(process.env.UPSTASH_REDIS_REST_URL || '').replace(/\/+$/, '');
  const token = process.env.UPSTASH_REDIS_REST_TOKEN || '';
  if (!url || !token) return null;
  try { const parsed = new URL(url); if (parsed.protocol !== 'https:') return null; }
  catch { return null; }
  return { url, token };
}

async function command(parts) {
  const cfg = config();
  if (!cfg) throw new Error('Upstash Redis não configurado. Defina UPSTASH_REDIS_REST_URL e UPSTASH_REDIS_REST_TOKEN.');
  const response = await fetch(cfg.url, {
    method: 'POST',
    headers: { Authorization: `Bearer ${cfg.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(parts),
    signal: AbortSignal.timeout(8000)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.error) throw new Error(payload.error || `Upstash HTTP ${response.status}`);
  return payload.result;
}

export function isUpstashConfigured() { return Boolean(config()); }

export async function savePlayedTorrent(item) {
  const hash = String(item?.infoHash || '').toLowerCase();
  if (!/^[a-f0-9]{40}$/.test(hash)) throw new Error('Info hash inválido.');
  const suppliedMagnet = String(item?.magnetURI || item?.magnet || '').trim();
  if (!suppliedMagnet.startsWith('magnet:?')) throw new Error('Magnet completo obrigatório para salvar na biblioteca.');
  let magnetHash = '';
  try {
    const parsed = new URL(suppliedMagnet);
    const xt = (parsed.searchParams.get('xt') || '').match(/^urn:btih:([a-z2-7]{32}|[a-f0-9]{40})$/i)?.[1] || '';
    if (/^[a-f0-9]{40}$/i.test(xt)) magnetHash = xt.toLowerCase();
    else if (/^[a-z2-7]{32}$/i.test(xt)) {
      const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; let bits = '';
      for (const char of xt.toUpperCase()) bits += alphabet.indexOf(char).toString(2).padStart(5, '0');
      let hex = ''; for (let i = 0; i + 8 <= bits.length; i += 8) hex += parseInt(bits.slice(i, i + 8), 2).toString(16).padStart(2, '0');
      magnetHash = hex.toLowerCase();
    }
  } catch {}
  if (magnetHash !== hash) throw new Error('O magnet informado não corresponde ao info hash do torrent.');
  const record = {
    infoHash: hash,
    magnetURI: suppliedMagnet.slice(0, 12000),
    name: String(item.name || 'Torrent sem nome').slice(0, 300),
    fileName: String(item.fileName || '').slice(0, 500),
    fileLength: Math.max(0, Number(item.fileLength) || 0),
    totalLength: Math.max(0, Number(item.totalLength) || 0),
    files: Array.isArray(item.files) ? item.files.slice(0, 200).map(f => ({ name: String(f.name || '').slice(0, 500), length: Math.max(0, Number(f.length) || 0) })) : [],
    playedAt: new Date().toISOString(),
    playbackConfirmed: true
  };
  await command(['HSET', KEY, hash, JSON.stringify(record)]);
  return record;
}

export async function listPlayedTorrents(query = '') {
  const values = await command(['HVALS', KEY]);
  const q = String(query || '').trim().toLocaleLowerCase('pt-BR').slice(0, 120);
  return (Array.isArray(values) ? values : []).map(value => {
    try { return typeof value === 'string' ? JSON.parse(value) : value; } catch { return null; }
  }).filter(item => item && (!q || `${item.name} ${item.fileName} ${item.infoHash} ${item.magnetURI || ''}`.toLocaleLowerCase('pt-BR').includes(q)))
    .sort((a, b) => String(b.playedAt).localeCompare(String(a.playedAt))).slice(0, 200);
}
