/**
 * Proxy da API YTS (movies-api.accel.li/api/v2).
 * Documentação: https://yts.gg/api
 * Base: https://movies-api.accel.li/api/v2/
 */

export const YTS_BASE = 'https://movies-api.accel.li/api/v2';

// Trackers recomendados pela própria documentação YTS + WSS para WebTorrent
export const YTS_TRACKERS = Object.freeze([
  'wss://tracker.btorrent.xyz',
  'wss://tracker.fastcast.nz',
  'wss://tracker.openwebtorrent.com',
  'wss://tracker.webtorrent.dev',
  'wss://tracker.files.fm:7073/announce',
  'udp://tracker.opentrackr.org:1337/announce',
  'udp://tracker.torrent.eu.org:451/announce',
  'udp://open.stealth.si:80/announce',
  'udp://open.demonii.com:1337/announce',
  'udp://tracker.dler.org:6969/announce',
  'udp://open.dstud.io:6969/announce',
  'udp://tracker.srv00.com:6969/announce',
  'udp://tracker.openbittorrent.com:6969/announce',
  'udp://exodus.desync.com:6969/announce',
  'https://tracker.moeblog.cn:443/announce',
  'https://tracker.zhuqiy.com:443/announce',
  'https://tracker.pmman.tech:443/announce'
]);

export function buildYtsMagnet(hash, name = '') {
  const h = String(hash || '').trim().toLowerCase();
  if (!/^[a-f0-9]{40}$/.test(h)) return null;
  const parts = [`xt=urn:btih:${h}`];
  if (name) parts.push(`dn=${encodeURIComponent(String(name).replace(/[\r\n]/g, ' ').slice(0, 180))}`);
  for (const tr of YTS_TRACKERS) parts.push(`tr=${encodeURIComponent(tr)}`);
  return `magnet:?${parts.join('&')}`;
}

function mapTorrent(t, movieTitle) {
  if (!t || typeof t !== 'object') return null;
  const hash = String(t.hash || '').toLowerCase();
  if (!/^[a-f0-9]{40}$/.test(hash)) return null;
  const label = [movieTitle, t.quality, t.type, t.video_codec].filter(Boolean).join(' · ');
  return {
    hash,
    quality: t.quality || null,
    type: t.type || null,
    size: t.size || null,
    sizeBytes: t.size_bytes || null,
    seeds: t.seeds ?? null,
    peers: t.peers ?? null,
    videoCodec: t.video_codec || null,
    audioChannels: t.audio_channels || null,
    bitDepth: t.bit_depth || null,
    url: t.url || null,
    magnet: buildYtsMagnet(hash, label),
    hasWebRtcTrackers: true
  };
}

function mapMovie(movie) {
  if (!movie || typeof movie !== 'object') return null;
  const title = movie.title_long || movie.title_english || movie.title || 'Filme';
  const torrents = Array.isArray(movie.torrents)
    ? movie.torrents.map(t => mapTorrent(t, title)).filter(Boolean)
    : [];
  return {
    id: movie.id,
    imdbCode: movie.imdb_code || null,
    title,
    titleEnglish: movie.title_english || movie.title || null,
    year: movie.year || null,
    rating: movie.rating ?? null,
    runtime: movie.runtime || null,
    genres: Array.isArray(movie.genres) ? movie.genres : [],
    language: movie.language || null,
    mpaRating: movie.mpa_rating || null,
    summary: movie.summary || movie.description_full || movie.synopsis || '',
    trailer: movie.yt_trailer_code || null,
    cover: movie.medium_cover_image || movie.small_cover_image || null,
    background: movie.background_image || null,
    torrents,
    torrentCount: torrents.length
  };
}

async function ytsFetch(path, query = {}) {
  const url = new URL(`${YTS_BASE}${path}`);
  for (const [key, value] of Object.entries(query)) {
    if (value === undefined || value === null || value === '') continue;
    url.searchParams.set(key, String(value));
  }
  const response = await fetch(url, {
    headers: { accept: 'application/json' },
    signal: AbortSignal.timeout(18000)
  });
  if (!response.ok) {
    throw new Error(`YTS respondeu HTTP ${response.status}`);
  }
  const payload = await response.json();
  if (payload.status === 'error') {
    throw new Error(payload.status_message || 'Erro na API YTS');
  }
  return payload;
}

/**
 * GET list_movies — busca/listagem.
 */
export async function listMovies({
  query_term,
  limit = 20,
  page = 1,
  quality,
  minimum_rating,
  genre,
  sort_by = 'seeds',
  order_by = 'desc',
  with_rt_ratings = false
} = {}) {
  const safeLimit = Math.min(50, Math.max(1, Number(limit) || 20));
  const safePage = Math.max(1, Number(page) || 1);
  const payload = await ytsFetch('/list_movies.json', {
    query_term: query_term || undefined,
    limit: safeLimit,
    page: safePage,
    quality: quality || undefined,
    minimum_rating: minimum_rating || undefined,
    genre: genre || undefined,
    sort_by,
    order_by,
    with_rt_ratings: with_rt_ratings ? 'true' : undefined
  });
  const data = payload.data || {};
  const movies = Array.isArray(data.movies)
    ? data.movies.map(mapMovie).filter(Boolean)
    : [];
  return {
    movieCount: data.movie_count ?? movies.length,
    limit: data.limit ?? safeLimit,
    page: data.page_number ?? safePage,
    movies,
    source: 'yts'
  };
}

/**
 * GET movie_details — detalhes + torrents.
 */
export async function movieDetails({ movie_id, imdb_id, with_images = true, with_cast = false } = {}) {
  const payload = await ytsFetch('/movie_details.json', {
    movie_id: movie_id || undefined,
    imdb_id: imdb_id || undefined,
    with_images: with_images ? 'true' : undefined,
    with_cast: with_cast ? 'true' : undefined
  });
  const movie = mapMovie(payload.data?.movie);
  if (!movie) throw new Error('Filme não encontrado na YTS.');
  return { movie, source: 'yts' };
}
