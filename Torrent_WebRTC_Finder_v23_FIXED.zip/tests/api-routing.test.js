import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const catchAllPath = new URL('../api/[...path].js', import.meta.url);

test('Vercel possui função catch-all para rotas API aninhadas', async () => {
  const source = await readFile(catchAllPath, 'utf8');
  assert.match(source, /import app from ['"]\.\.\/server\/index\.js['"]/);
  assert.match(source, /export default app/);
  assert.match(source, /bodyParser:\s*false/);
});

test('a rota de gravação do catálogo está registrada no Express', async () => {
  const source = await readFile(new URL('../server/index.js', import.meta.url), 'utf8');
  assert.match(source, /app\.post\(['"]\/api\/catalog\/played['"]/);
  assert.match(source, /app\.get\(['"]\/api\/catalog['"]/);
});


test('Vercel possui função explícita para POST /api/catalog/played', async () => {
  const route = await readFile(new URL('../api/catalog/played.js', import.meta.url), 'utf8');
  assert.match(route, /server\/index\.js/);
  assert.match(route, /bodyParser:\s*false/);
  assert.match(route, /export default app/);
});

test('Vercel possui função explícita para o manifesto Torrentio', async () => {
  const route = await readFile(new URL('../api/stremio/manifest.js', import.meta.url), 'utf8');
  assert.match(route, /server\/index\.js/);
  assert.match(route, /export default app/);
  assert.ok(route.length > 0);
});

test('Vercel possui função explícita para consulta de streams Torrentio', async () => {
  const route = await readFile(new URL('../api/stremio/stream/[type]/[id].js', import.meta.url), 'utf8');
  assert.match(route, /server\/index\.js/);
  assert.match(route, /export default app/);
  assert.ok(route.length > 0);
});

test('vercel.json declara maxDuration para funções da API', async () => {
  const config = JSON.parse(await readFile(new URL('../vercel.json', import.meta.url), 'utf8'));
  assert.equal(config.version, 2);
  assert.ok(config.functions);
  const fn = config.functions['api/**/*.js'] || Object.values(config.functions)[0];
  assert.ok(fn);
  assert.equal(fn.maxDuration, 30);
});
