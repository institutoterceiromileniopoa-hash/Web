import test from 'node:test';
import assert from 'node:assert/strict';
import { decodeTorrent, classifyTracker, parseMagnet } from '../server/bencode.js';

function bstr(s){const b=Buffer.from(s);return Buffer.concat([Buffer.from(String(b.length)+':'),b]);}
function dict(entries){return Buffer.concat([Buffer.from('d'),...entries.flatMap(([k,v])=>[bstr(k),v]),Buffer.from('e')]);}
function integer(n){return Buffer.from(`i${n}e`);}
function list(items){return Buffer.concat([Buffer.from('l'),...items,Buffer.from('e')]);}

test('classifies tracker schemes without rewriting them',()=>{
 assert.equal(classifyTracker('wss://tracker.example/announce'),'websocket');
 assert.equal(classifyTracker('udp://tracker.example:80/announce'),'udp');
 assert.equal(classifyTracker('https://tracker.example/announce'),'http');
 assert.equal(classifyTracker('ftp://tracker.example'),'unsupported');
});
test('extracts exact info hash, video files and embedded trackers',()=>{
 const info=dict([['name',bstr('demo')],['piece length',integer(16384)],['length',integer(1234)]]);
 const torrent=dict([['announce',bstr('wss://one.example/announce')],['announce-list',list([list([bstr('udp://two.example:80')])])],['info',info]]);
 const parsed=decodeTorrent(torrent);
 assert.equal(parsed.name,'demo'); assert.equal(parsed.totalLength,1234);
 assert.equal(parsed.trackers.length,2); assert.equal(parsed.trackers[0].type,'websocket'); assert.equal(parsed.trackers[1].type,'udp');
});
test('parses v1 magnet hash and tracker list',()=>{
 const hash='0123456789abcdef0123456789abcdef01234567';
 const m=parseMagnet(`magnet:?xt=urn:btih:${hash}&dn=Example&tr=wss%3A%2F%2Ftracker.example`);
 assert.equal(m.infoHash,hash); assert.equal(m.name,'Example'); assert.equal(m.trackers[0].type,'websocket');
});
test('rejects non-magnet input and malformed metainfo',()=>{
 assert.throws(()=>parseMagnet('https://example.com'),/magnet/i);
 assert.throws(()=>decodeTorrent(Buffer.from('not torrent')));
});
