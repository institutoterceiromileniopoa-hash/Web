import test from 'node:test';
import assert from 'node:assert/strict';
import { getPlaybackBuffer, getDownloadedBufferAhead } from '../client/src/telemetry.js';

function video(currentTime, ranges) {
  return { currentTime, buffered: { length:ranges.length, start:i=>ranges[i][0], end:i=>ranges[i][1] } };
}

test('mede somente a faixa contínua que contém o playhead', () => {
  assert.deepEqual(getPlaybackBuffer(video(10, [[0,18],[30,60]])), { ahead:8, ranges:2, valid:true, state:'buffer contínuo' });
});

test('não soma faixas futuras separadas e marca medição inválida', () => {
  assert.deepEqual(getPlaybackBuffer(video(20, [[0,15],[30,60]])), { ahead:null, ranges:2, valid:false, state:'playhead fora do buffer' });
});

test('tolera pequena diferença entre playhead e início da faixa no MSE', () => {
  const result = getPlaybackBuffer(video(0, [[0.18,12]]));
  assert.equal(result.valid, true);
  assert.equal(result.state, 'sincronizando faixa');
  assert.equal(result.ahead, 11.82);
});

test('não trata uma lacuna grande como buffer', () => {
  const result = getPlaybackBuffer(video(10, [[11,25]]));
  assert.equal(result.valid, false);
  assert.equal(result.ahead, null);
});

test('trata TimeRanges que muda durante a leitura', () => {
  const broken = { currentTime:3, buffered:{ get length(){return 1;}, start(){throw new Error('changed');}, end(){throw new Error('changed');} } };
  const result = getPlaybackBuffer(broken);
  assert.equal(result.valid, false);
  assert.equal(result.ahead, null);
});

test('trata elemento de vídeo indisponível', () => {
  assert.deepEqual(getPlaybackBuffer(null), { ahead:null, ranges:0, valid:false, state:'indisponível' });
});


test('buffer à frente acompanha apenas peças verificadas contíguas do arquivo', () => {
  const verified = new Set([4, 5, 6, 7]);
  const torrent = { pieceLength: 1000, bitfield: { get: index => verified.has(index) }, files: [] };
  const file = { length: 10000, offset: 2000 };
  torrent.files = [file];
  const result = getDownloadedBufferAhead(torrent, file, { currentTime: 2, duration: 10 });
  assert.equal(result.valid, true);
  assert.equal(result.piecesAhead, 4);
  assert.equal(result.bytesAhead, 4000);
  assert.equal(result.ahead, 4);
});

test('buffer à frente não soma peças distantes após uma lacuna', () => {
  const verified = new Set([2, 4, 5]);
  const torrent = { pieceLength: 1000, bitfield: { get: index => verified.has(index) }, files: [] };
  const file = { length: 10000, offset: 2000 };
  torrent.files = [file];
  const result = getDownloadedBufferAhead(torrent, file, { currentTime: 0, duration: 100 });
  assert.equal(result.piecesAhead, 1);
  assert.equal(result.bytesAhead, 1000);
  assert.equal(result.ahead, 10);
});

test('retorna indisponível quando bitfield não está disponível', () => {
  const result = getDownloadedBufferAhead({ pieceLength: 1024 }, { length: 4096, offset: 0 }, { currentTime: 0, duration: 10 });
  assert.equal(result.valid, false);
  assert.equal(result.ahead, null);
});
