import test from 'node:test';
import assert from 'node:assert/strict';
import { lookupDht } from '../server/dht-service.js';

test('informa claramente que DHT UDP persistente não está disponível em serverless', async () => {
  const previous = process.env.VERCEL;
  process.env.VERCEL = '1';
  try {
    const result = await lookupDht('0123456789abcdef0123456789abcdef01234567');
    assert.equal(result.available, false);
    assert.equal(result.count, 0);
    assert.match(result.note, /serverless/i);
  } finally {
    if (previous === undefined) delete process.env.VERCEL;
    else process.env.VERCEL = previous;
  }
});

test('inclui trackers públicos do Magnet Fisher somente quando o torrent é explicitamente público', async () => {
  const { buildDiscoveryTrackers, MAGNET_FISHER_TRACKERS } = await import('../server/dht-service.js');
  const publicTrackers = buildDiscoveryTrackers([], false);
  assert.deepEqual(publicTrackers, [...MAGNET_FISHER_TRACKERS]);
  assert.deepEqual(buildDiscoveryTrackers([], true), []);
  assert.deepEqual(buildDiscoveryTrackers([], undefined), []);
});

test('preserva trackers válidos fornecidos pelo magnet e rejeita esquemas não suportados', async () => {
  const { buildDiscoveryTrackers } = await import('../server/dht-service.js');
  assert.deepEqual(buildDiscoveryTrackers([
    'udp://tracker.example:80/announce',
    'https://tracker.example/announce',
    'file:///etc/passwd',
    'not a url'
  ], undefined), [
    'udp://tracker.example:80/announce',
    'https://tracker.example/announce'
  ]);
});
