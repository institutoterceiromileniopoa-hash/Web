import test from 'node:test';
import assert from 'node:assert/strict';
import { getBufferAhead, getAdaptiveWindow, getPieceRange, getPeerStats, chooseConnectionLimit } from '../client/src/stream-optimizer.js';

test('computes buffered seconds at the current playback position', () => {
  const video = { currentTime: 12, buffered: { length: 1, start: () => 10, end: () => 42 } };
  assert.equal(getBufferAhead(video), 30);
});

test('returns zero buffer when playback position is outside buffered ranges', () => {
  const video = { currentTime: 50, buffered: { length: 1, start: () => 10, end: () => 42 } };
  assert.equal(getBufferAhead(video), 0);
});

test('raises target buffer when buffer is critical and reduces it when safely full', () => {
  const critical = getAdaptiveWindow({ bufferAhead: 2, downloadSpeed: 500_000, fileLength: 900_000_000, duration: 3600, currentTime: 100 });
  const safe = getAdaptiveWindow({ bufferAhead: 50, downloadSpeed: 5_000_000, fileLength: 900_000_000, duration: 3600, currentTime: 100 });
  assert.equal(critical.targetBuffer, 75);
  assert.equal(critical.mode, 'RECUPERAR BUFFER');
  assert.equal(safe.targetBuffer, 20);
});

test('maps a playback time window to torrent piece indices including file offset', () => {
  const range = getPieceRange({ fileOffset: 1_000_000, fileLength: 100_000_000, pieceLength: 256_000, startSeconds: 10, endSeconds: 20, duration: 100 });
  assert.deepEqual(range, { start: 42, end: 82 });
});

test('summarizes peer download speeds and sorts fastest peers first', () => {
  const stats = getPeerStats([{ peerId: 'slow', downloadSpeed: 100 }, { peerId: 'fast', downloadSpeed: 900 }, { peerId: 'idle', downloadSpeed: 0 }]);
  assert.equal(stats.peers[0].id, 'fast');
  assert.equal(stats.activeDownloadPeers, 2);
  assert.equal(stats.averageDownloadSpeed, 500);
});

test('uses conservative connection limits for mobile and stronger desktop devices', () => {
  assert.equal(chooseConnectionLimit({ mobile: true, hardwareConcurrency: 8, deviceMemory: 8 }), 40);
  assert.equal(chooseConnectionLimit({ mobile: false, hardwareConcurrency: 8, deviceMemory: 8 }), 75);
});
