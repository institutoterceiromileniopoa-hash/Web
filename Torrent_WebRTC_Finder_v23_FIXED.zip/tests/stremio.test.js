import test from 'node:test';
import assert from 'node:assert/strict';
import { validateStremioRequest, buildTorrentioMagnet, normalizeTorrentioStreams } from '../server/stremio.js';

test('valida tipos e identificadores Stremio suportados', () => {
  assert.deepEqual(validateStremioRequest('movie', 'tt1254207'), { type: 'movie', id: 'tt1254207' });
  assert.equal(validateStremioRequest('anime', 'kitsu:1234').id, 'kitsu:1234');
  assert.throws(() => validateStremioRequest('catalog', 'tt1254207'), /Tipo inválido/);
  assert.throws(() => validateStremioRequest('movie', 'https://attacker.example'), /ID inválido/);
});

test('monta magnet completo com hash, nome e trackers Torrentio', () => {
  const hash = 'A'.repeat(40);
  const magnet = buildTorrentioMagnet({ infoHash: hash, title: 'Filme 1080p', sources: ['tracker:wss://tracker.example/announce', 'udp://tracker2.example:80/announce'] });
  const url = new URL(magnet);
  assert.equal(url.searchParams.get('xt'), `urn:btih:${hash.toLowerCase()}`);
  assert.equal(url.searchParams.get('dn'), 'Filme 1080p');
  assert.deepEqual(url.searchParams.getAll('tr'), ['wss://tracker.example/announce', 'udp://tracker2.example:80/announce']);
  assert.equal(buildTorrentioMagnet({ infoHash: 'invalid' }), null);
});

test('normaliza streams e ignora itens sem magnet nem URL', () => {
  const streams = normalizeTorrentioStreams({ streams: [
    { infoHash: 'b'.repeat(40), title: '1080p', sources: ['tracker:wss://tracker.example'] },
    { title: 'inválido' },
    { url: 'https://cdn.example/video.mp4', title: 'HTTP' }
  ] });
  assert.equal(streams.length, 2);
  assert.match(streams[0].magnet, /^magnet:\?/);
  assert.equal(streams[1].url, 'https://cdn.example/video.mp4');
});
