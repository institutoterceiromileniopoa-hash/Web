import test from 'node:test';
import assert from 'node:assert/strict';
import { createTelemetrySampler } from '../client/src/telemetry.js';

test('calcula velocidades pela diferença dos contadores cumulativos', () => {
  const sample = createTelemetrySampler();
  sample({ downloaded: 1000, uploaded: 500, downloadSpeed: 99, uploadSpeed: 99 }, [], 1000);
  const result = sample({ downloaded: 5000, uploaded: 1500 }, [], 2000);
  assert.equal(result.downloadSpeed, 4000);
  assert.equal(result.uploadSpeed, 1000);
});

test('calcula velocidades individuais e remove peers desconectados', () => {
  const sample = createTelemetrySampler();
  const wire = { peerId: 'peer-a', downloaded: 100, uploaded: 50 };
  sample({ downloaded: 100, uploaded: 50 }, [wire], 1000);
  const result = sample({ downloaded: 1100, uploaded: 550 }, [{ ...wire, downloaded: 700, uploaded: 250 }], 2000);
  assert.equal(result.peers.get('peer-a').downloadSpeed, 600);
  assert.equal(result.peers.get('peer-a').uploadSpeed, 200);
  sample({ downloaded: 1100, uploaded: 550 }, [], 3000);
  const afterDisconnect = sample({ downloaded: 1100, uploaded: 550 }, [{ ...wire, downloaded: 100, uploaded: 50 }], 4000);
  assert.equal(afterDisconnect.peers.get('peer-a').downloadSpeed, 0);
});

test('usa estimativa WebTorrent no primeiro ciclo ou quando contador reinicia', () => {
  const sample = createTelemetrySampler();
  const first = sample({ downloaded: 100, uploaded: 20, downloadSpeed: 321, uploadSpeed: 123 }, [], 1000);
  assert.equal(first.downloadSpeed, 321);
  const reset = sample({ downloaded: 5, uploaded: 2, downloadSpeed: 44, uploadSpeed: 11 }, [], 2000);
  assert.equal(reset.downloadSpeed, 44);
  assert.equal(reset.uploadSpeed, 11);
});
