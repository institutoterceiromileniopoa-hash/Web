import test from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_WEBRTC_TRACKERS,
  DEFAULT_BITTORRENT_TRACKERS,
  getWebRtcTrackerPlan,
  enrichMagnetWithTrackers,
  buildMagnetFromHash
} from '../client/src/tracker-utils.js';

test('merges existing WSS trackers with defaults for public torrents', () => {
  const plan = getWebRtcTrackerPlan([{ url: 'wss://tracker.example/announce' }], false);
  assert.ok(plan.announce.includes('wss://tracker.example/announce'));
  for (const tr of DEFAULT_WEBRTC_TRACKERS) assert.ok(plan.announce.includes(tr));
  assert.equal(plan.injected, true);
});

test('does not inject public trackers into private torrents', () => {
  const plan = getWebRtcTrackerPlan([], true);
  assert.deepEqual(plan.announce, []);
  assert.equal(plan.reason, 'private');
});

test('enrichMagnetWithTrackers adds WSS and UDP trackers', () => {
  const hash = 'a'.repeat(40);
  const base = `magnet:?xt=urn:btih:${hash}&dn=Test`;
  const { magnet, added, total } = enrichMagnetWithTrackers(base, { includeUdp: true });
  assert.ok(magnet.startsWith('magnet:?'));
  assert.ok(added > 5);
  assert.ok(total >= DEFAULT_WEBRTC_TRACKERS.length);
  assert.ok(magnet.includes('openwebtorrent') || magnet.includes('wss'));
  assert.ok(magnet.includes('opentrackr') || magnet.includes('udp'));
});

test('buildMagnetFromHash includes public trackers', () => {
  const m = buildMagnetFromHash('b'.repeat(40), 'Filme Teste');
  assert.match(m, /xt=urn%3Abtih%3Ab{40}|xt=urn:btih:b{40}/);
  assert.match(m, /dn=Filme/);
  assert.match(m, /tr=/);
});

test('DEFAULT lists are non-empty', () => {
  assert.ok(DEFAULT_WEBRTC_TRACKERS.length >= 4);
  assert.ok(DEFAULT_BITTORRENT_TRACKERS.length >= 8);
});
