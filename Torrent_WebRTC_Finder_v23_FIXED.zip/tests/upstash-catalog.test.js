import test from 'node:test';
import assert from 'node:assert/strict';
import { savePlayedTorrent, listPlayedTorrents, isUpstashConfigured } from '../server/upstash-catalog.js';

const originalFetch = globalThis.fetch;
const originalUrl = process.env.UPSTASH_REDIS_REST_URL;
const originalToken = process.env.UPSTASH_REDIS_REST_TOKEN;

test('Upstash exige URL HTTPS e token REST', () => {
  process.env.UPSTASH_REDIS_REST_URL = 'http://invalid.example';
  process.env.UPSTASH_REDIS_REST_TOKEN = 'token';
  assert.equal(isUpstashConfigured(), false);
  process.env.UPSTASH_REDIS_REST_URL = 'https://example.upstash.io';
  assert.equal(isUpstashConfigured(), true);
});

test('salva somente registro com info hash válido e lista do Redis', async () => {
  process.env.UPSTASH_REDIS_REST_URL = 'https://example.upstash.io';
  process.env.UPSTASH_REDIS_REST_TOKEN = 'test-token';
  const records = new Map();
  globalThis.fetch = async (_url, options) => {
    const command = JSON.parse(options.body);
    let result;
    if (command[0] === 'HSET') { records.set(command[2], command[3]); result = 1; }
    else if (command[0] === 'HVALS') result = [...records.values()];
    else throw new Error('Comando inesperado');
    return new Response(JSON.stringify({ result }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  };
  try {
    await assert.rejects(() => savePlayedTorrent({ infoHash: 'bad' }), /Info hash inválido/);
    await assert.rejects(() => savePlayedTorrent({ infoHash: 'a'.repeat(40) }), /Magnet completo obrigatório/);
    await assert.rejects(() => savePlayedTorrent({ infoHash: 'a'.repeat(40), magnetURI: `magnet:?xt=urn:btih:${'b'.repeat(40)}` }), /não corresponde/);
    const magnetURI = `magnet:?xt=urn:btih:${'a'.repeat(40)}&dn=Teste&tr=${encodeURIComponent('wss://tracker.example announce')}`;
    const saved = await savePlayedTorrent({ infoHash: 'a'.repeat(40), magnetURI, name: 'Teste', fileName: 'video.mp4', fileLength: 123 });
    assert.equal(saved.playbackConfirmed, true);
    assert.equal(saved.magnetURI, magnetURI);
    assert.equal(records.size, 1);
    const results = await listPlayedTorrents('video');
    assert.equal(results.length, 1);
    assert.equal(results[0].fileName, 'video.mp4');
    assert.equal(results[0].magnetURI, magnetURI);
  } finally {
    globalThis.fetch = originalFetch;
    if (originalUrl === undefined) delete process.env.UPSTASH_REDIS_REST_URL; else process.env.UPSTASH_REDIS_REST_URL = originalUrl;
    if (originalToken === undefined) delete process.env.UPSTASH_REDIS_REST_TOKEN; else process.env.UPSTASH_REDIS_REST_TOKEN = originalToken;
  }
});
