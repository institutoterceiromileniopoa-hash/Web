import { defineConfig } from 'vite';
export default defineConfig({
  root: 'client',
  server: {
    port: 5173,
    proxy: { '/api': 'http://localhost:8787' }
  },
  build: { outDir: 'dist', emptyOutDir: true }
});
